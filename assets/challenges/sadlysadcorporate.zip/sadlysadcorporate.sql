-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: sadlysadcorporate
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `000JDBLA8V`
--

DROP TABLE IF EXISTS `000JDBLA8V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `000JDBLA8V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `000JDBLA8V`
--

LOCK TABLES `000JDBLA8V` WRITE;
/*!40000 ALTER TABLE `000JDBLA8V` DISABLE KEYS */;
/*!40000 ALTER TABLE `000JDBLA8V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `05S5S3T363`
--

DROP TABLE IF EXISTS `05S5S3T363`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `05S5S3T363` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `05S5S3T363`
--

LOCK TABLES `05S5S3T363` WRITE;
/*!40000 ALTER TABLE `05S5S3T363` DISABLE KEYS */;
/*!40000 ALTER TABLE `05S5S3T363` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `05YVBMQWR3`
--

DROP TABLE IF EXISTS `05YVBMQWR3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `05YVBMQWR3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `05YVBMQWR3`
--

LOCK TABLES `05YVBMQWR3` WRITE;
/*!40000 ALTER TABLE `05YVBMQWR3` DISABLE KEYS */;
/*!40000 ALTER TABLE `05YVBMQWR3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `06KC5WQ4AG`
--

DROP TABLE IF EXISTS `06KC5WQ4AG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `06KC5WQ4AG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `06KC5WQ4AG`
--

LOCK TABLES `06KC5WQ4AG` WRITE;
/*!40000 ALTER TABLE `06KC5WQ4AG` DISABLE KEYS */;
/*!40000 ALTER TABLE `06KC5WQ4AG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `06QC5DYBLL`
--

DROP TABLE IF EXISTS `06QC5DYBLL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `06QC5DYBLL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `06QC5DYBLL`
--

LOCK TABLES `06QC5DYBLL` WRITE;
/*!40000 ALTER TABLE `06QC5DYBLL` DISABLE KEYS */;
/*!40000 ALTER TABLE `06QC5DYBLL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `07DXUKDO86`
--

DROP TABLE IF EXISTS `07DXUKDO86`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `07DXUKDO86` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `07DXUKDO86`
--

LOCK TABLES `07DXUKDO86` WRITE;
/*!40000 ALTER TABLE `07DXUKDO86` DISABLE KEYS */;
/*!40000 ALTER TABLE `07DXUKDO86` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `089DG1OBM6`
--

DROP TABLE IF EXISTS `089DG1OBM6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `089DG1OBM6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `089DG1OBM6`
--

LOCK TABLES `089DG1OBM6` WRITE;
/*!40000 ALTER TABLE `089DG1OBM6` DISABLE KEYS */;
/*!40000 ALTER TABLE `089DG1OBM6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `09P9MI7M5K`
--

DROP TABLE IF EXISTS `09P9MI7M5K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `09P9MI7M5K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `09P9MI7M5K`
--

LOCK TABLES `09P9MI7M5K` WRITE;
/*!40000 ALTER TABLE `09P9MI7M5K` DISABLE KEYS */;
/*!40000 ALTER TABLE `09P9MI7M5K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0AH4EHM26E`
--

DROP TABLE IF EXISTS `0AH4EHM26E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0AH4EHM26E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0AH4EHM26E`
--

LOCK TABLES `0AH4EHM26E` WRITE;
/*!40000 ALTER TABLE `0AH4EHM26E` DISABLE KEYS */;
/*!40000 ALTER TABLE `0AH4EHM26E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0B1DN1UF3B`
--

DROP TABLE IF EXISTS `0B1DN1UF3B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0B1DN1UF3B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0B1DN1UF3B`
--

LOCK TABLES `0B1DN1UF3B` WRITE;
/*!40000 ALTER TABLE `0B1DN1UF3B` DISABLE KEYS */;
/*!40000 ALTER TABLE `0B1DN1UF3B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0B52IUS7C5`
--

DROP TABLE IF EXISTS `0B52IUS7C5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0B52IUS7C5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0B52IUS7C5`
--

LOCK TABLES `0B52IUS7C5` WRITE;
/*!40000 ALTER TABLE `0B52IUS7C5` DISABLE KEYS */;
/*!40000 ALTER TABLE `0B52IUS7C5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0B55Y1QE0K`
--

DROP TABLE IF EXISTS `0B55Y1QE0K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0B55Y1QE0K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0B55Y1QE0K`
--

LOCK TABLES `0B55Y1QE0K` WRITE;
/*!40000 ALTER TABLE `0B55Y1QE0K` DISABLE KEYS */;
/*!40000 ALTER TABLE `0B55Y1QE0K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0BIZ4OHH4Z`
--

DROP TABLE IF EXISTS `0BIZ4OHH4Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0BIZ4OHH4Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0BIZ4OHH4Z`
--

LOCK TABLES `0BIZ4OHH4Z` WRITE;
/*!40000 ALTER TABLE `0BIZ4OHH4Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `0BIZ4OHH4Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0D62K3WAAH`
--

DROP TABLE IF EXISTS `0D62K3WAAH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0D62K3WAAH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0D62K3WAAH`
--

LOCK TABLES `0D62K3WAAH` WRITE;
/*!40000 ALTER TABLE `0D62K3WAAH` DISABLE KEYS */;
/*!40000 ALTER TABLE `0D62K3WAAH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0E385DV3YD`
--

DROP TABLE IF EXISTS `0E385DV3YD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0E385DV3YD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0E385DV3YD`
--

LOCK TABLES `0E385DV3YD` WRITE;
/*!40000 ALTER TABLE `0E385DV3YD` DISABLE KEYS */;
/*!40000 ALTER TABLE `0E385DV3YD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0FLS2GFIR8`
--

DROP TABLE IF EXISTS `0FLS2GFIR8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0FLS2GFIR8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0FLS2GFIR8`
--

LOCK TABLES `0FLS2GFIR8` WRITE;
/*!40000 ALTER TABLE `0FLS2GFIR8` DISABLE KEYS */;
/*!40000 ALTER TABLE `0FLS2GFIR8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0IUJH1CV1F`
--

DROP TABLE IF EXISTS `0IUJH1CV1F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0IUJH1CV1F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0IUJH1CV1F`
--

LOCK TABLES `0IUJH1CV1F` WRITE;
/*!40000 ALTER TABLE `0IUJH1CV1F` DISABLE KEYS */;
/*!40000 ALTER TABLE `0IUJH1CV1F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0KFRZJ048M`
--

DROP TABLE IF EXISTS `0KFRZJ048M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0KFRZJ048M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0KFRZJ048M`
--

LOCK TABLES `0KFRZJ048M` WRITE;
/*!40000 ALTER TABLE `0KFRZJ048M` DISABLE KEYS */;
/*!40000 ALTER TABLE `0KFRZJ048M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0LK77090HJ`
--

DROP TABLE IF EXISTS `0LK77090HJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0LK77090HJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0LK77090HJ`
--

LOCK TABLES `0LK77090HJ` WRITE;
/*!40000 ALTER TABLE `0LK77090HJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `0LK77090HJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0PTC7XYYXE`
--

DROP TABLE IF EXISTS `0PTC7XYYXE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0PTC7XYYXE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0PTC7XYYXE`
--

LOCK TABLES `0PTC7XYYXE` WRITE;
/*!40000 ALTER TABLE `0PTC7XYYXE` DISABLE KEYS */;
/*!40000 ALTER TABLE `0PTC7XYYXE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0QPEDDWZXF`
--

DROP TABLE IF EXISTS `0QPEDDWZXF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0QPEDDWZXF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0QPEDDWZXF`
--

LOCK TABLES `0QPEDDWZXF` WRITE;
/*!40000 ALTER TABLE `0QPEDDWZXF` DISABLE KEYS */;
/*!40000 ALTER TABLE `0QPEDDWZXF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0R6WILFVNE`
--

DROP TABLE IF EXISTS `0R6WILFVNE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0R6WILFVNE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0R6WILFVNE`
--

LOCK TABLES `0R6WILFVNE` WRITE;
/*!40000 ALTER TABLE `0R6WILFVNE` DISABLE KEYS */;
/*!40000 ALTER TABLE `0R6WILFVNE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0TRX7NOZRB`
--

DROP TABLE IF EXISTS `0TRX7NOZRB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0TRX7NOZRB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0TRX7NOZRB`
--

LOCK TABLES `0TRX7NOZRB` WRITE;
/*!40000 ALTER TABLE `0TRX7NOZRB` DISABLE KEYS */;
/*!40000 ALTER TABLE `0TRX7NOZRB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0U0WGWCOIX`
--

DROP TABLE IF EXISTS `0U0WGWCOIX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0U0WGWCOIX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0U0WGWCOIX`
--

LOCK TABLES `0U0WGWCOIX` WRITE;
/*!40000 ALTER TABLE `0U0WGWCOIX` DISABLE KEYS */;
/*!40000 ALTER TABLE `0U0WGWCOIX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0VO3AF28CU`
--

DROP TABLE IF EXISTS `0VO3AF28CU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0VO3AF28CU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0VO3AF28CU`
--

LOCK TABLES `0VO3AF28CU` WRITE;
/*!40000 ALTER TABLE `0VO3AF28CU` DISABLE KEYS */;
/*!40000 ALTER TABLE `0VO3AF28CU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0WCBS7PZNO`
--

DROP TABLE IF EXISTS `0WCBS7PZNO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0WCBS7PZNO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0WCBS7PZNO`
--

LOCK TABLES `0WCBS7PZNO` WRITE;
/*!40000 ALTER TABLE `0WCBS7PZNO` DISABLE KEYS */;
/*!40000 ALTER TABLE `0WCBS7PZNO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0WLECJ6NSS`
--

DROP TABLE IF EXISTS `0WLECJ6NSS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0WLECJ6NSS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0WLECJ6NSS`
--

LOCK TABLES `0WLECJ6NSS` WRITE;
/*!40000 ALTER TABLE `0WLECJ6NSS` DISABLE KEYS */;
/*!40000 ALTER TABLE `0WLECJ6NSS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0YT3ZWS7SB`
--

DROP TABLE IF EXISTS `0YT3ZWS7SB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0YT3ZWS7SB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0YT3ZWS7SB`
--

LOCK TABLES `0YT3ZWS7SB` WRITE;
/*!40000 ALTER TABLE `0YT3ZWS7SB` DISABLE KEYS */;
/*!40000 ALTER TABLE `0YT3ZWS7SB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `0YV6ROXGH2`
--

DROP TABLE IF EXISTS `0YV6ROXGH2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `0YV6ROXGH2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `0YV6ROXGH2`
--

LOCK TABLES `0YV6ROXGH2` WRITE;
/*!40000 ALTER TABLE `0YV6ROXGH2` DISABLE KEYS */;
/*!40000 ALTER TABLE `0YV6ROXGH2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `106ESVP2KL`
--

DROP TABLE IF EXISTS `106ESVP2KL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `106ESVP2KL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `106ESVP2KL`
--

LOCK TABLES `106ESVP2KL` WRITE;
/*!40000 ALTER TABLE `106ESVP2KL` DISABLE KEYS */;
/*!40000 ALTER TABLE `106ESVP2KL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `11X7CRBYJL`
--

DROP TABLE IF EXISTS `11X7CRBYJL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `11X7CRBYJL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `11X7CRBYJL`
--

LOCK TABLES `11X7CRBYJL` WRITE;
/*!40000 ALTER TABLE `11X7CRBYJL` DISABLE KEYS */;
/*!40000 ALTER TABLE `11X7CRBYJL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `153VMJFL5Z`
--

DROP TABLE IF EXISTS `153VMJFL5Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `153VMJFL5Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `153VMJFL5Z`
--

LOCK TABLES `153VMJFL5Z` WRITE;
/*!40000 ALTER TABLE `153VMJFL5Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `153VMJFL5Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1841VXAX87`
--

DROP TABLE IF EXISTS `1841VXAX87`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1841VXAX87` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1841VXAX87`
--

LOCK TABLES `1841VXAX87` WRITE;
/*!40000 ALTER TABLE `1841VXAX87` DISABLE KEYS */;
/*!40000 ALTER TABLE `1841VXAX87` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1A2Z1J6RLW`
--

DROP TABLE IF EXISTS `1A2Z1J6RLW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1A2Z1J6RLW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1A2Z1J6RLW`
--

LOCK TABLES `1A2Z1J6RLW` WRITE;
/*!40000 ALTER TABLE `1A2Z1J6RLW` DISABLE KEYS */;
/*!40000 ALTER TABLE `1A2Z1J6RLW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1A4R344G6V`
--

DROP TABLE IF EXISTS `1A4R344G6V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1A4R344G6V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1A4R344G6V`
--

LOCK TABLES `1A4R344G6V` WRITE;
/*!40000 ALTER TABLE `1A4R344G6V` DISABLE KEYS */;
/*!40000 ALTER TABLE `1A4R344G6V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1B1O7KQTKK`
--

DROP TABLE IF EXISTS `1B1O7KQTKK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1B1O7KQTKK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1B1O7KQTKK`
--

LOCK TABLES `1B1O7KQTKK` WRITE;
/*!40000 ALTER TABLE `1B1O7KQTKK` DISABLE KEYS */;
/*!40000 ALTER TABLE `1B1O7KQTKK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1CEATKJXBX`
--

DROP TABLE IF EXISTS `1CEATKJXBX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1CEATKJXBX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1CEATKJXBX`
--

LOCK TABLES `1CEATKJXBX` WRITE;
/*!40000 ALTER TABLE `1CEATKJXBX` DISABLE KEYS */;
/*!40000 ALTER TABLE `1CEATKJXBX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1CHMM47LPH`
--

DROP TABLE IF EXISTS `1CHMM47LPH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1CHMM47LPH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1CHMM47LPH`
--

LOCK TABLES `1CHMM47LPH` WRITE;
/*!40000 ALTER TABLE `1CHMM47LPH` DISABLE KEYS */;
/*!40000 ALTER TABLE `1CHMM47LPH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1FIDDJEH0K`
--

DROP TABLE IF EXISTS `1FIDDJEH0K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1FIDDJEH0K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1FIDDJEH0K`
--

LOCK TABLES `1FIDDJEH0K` WRITE;
/*!40000 ALTER TABLE `1FIDDJEH0K` DISABLE KEYS */;
/*!40000 ALTER TABLE `1FIDDJEH0K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1G87ZI2KVO`
--

DROP TABLE IF EXISTS `1G87ZI2KVO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1G87ZI2KVO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1G87ZI2KVO`
--

LOCK TABLES `1G87ZI2KVO` WRITE;
/*!40000 ALTER TABLE `1G87ZI2KVO` DISABLE KEYS */;
/*!40000 ALTER TABLE `1G87ZI2KVO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1HWZPPJ25J`
--

DROP TABLE IF EXISTS `1HWZPPJ25J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1HWZPPJ25J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1HWZPPJ25J`
--

LOCK TABLES `1HWZPPJ25J` WRITE;
/*!40000 ALTER TABLE `1HWZPPJ25J` DISABLE KEYS */;
/*!40000 ALTER TABLE `1HWZPPJ25J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1JRBF98WV4`
--

DROP TABLE IF EXISTS `1JRBF98WV4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1JRBF98WV4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1JRBF98WV4`
--

LOCK TABLES `1JRBF98WV4` WRITE;
/*!40000 ALTER TABLE `1JRBF98WV4` DISABLE KEYS */;
/*!40000 ALTER TABLE `1JRBF98WV4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1KGLFDNZ2C`
--

DROP TABLE IF EXISTS `1KGLFDNZ2C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1KGLFDNZ2C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1KGLFDNZ2C`
--

LOCK TABLES `1KGLFDNZ2C` WRITE;
/*!40000 ALTER TABLE `1KGLFDNZ2C` DISABLE KEYS */;
/*!40000 ALTER TABLE `1KGLFDNZ2C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1KZ889QSDS`
--

DROP TABLE IF EXISTS `1KZ889QSDS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1KZ889QSDS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1KZ889QSDS`
--

LOCK TABLES `1KZ889QSDS` WRITE;
/*!40000 ALTER TABLE `1KZ889QSDS` DISABLE KEYS */;
/*!40000 ALTER TABLE `1KZ889QSDS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1LOWCNKERM`
--

DROP TABLE IF EXISTS `1LOWCNKERM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1LOWCNKERM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1LOWCNKERM`
--

LOCK TABLES `1LOWCNKERM` WRITE;
/*!40000 ALTER TABLE `1LOWCNKERM` DISABLE KEYS */;
/*!40000 ALTER TABLE `1LOWCNKERM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1MWWL3R9XD`
--

DROP TABLE IF EXISTS `1MWWL3R9XD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1MWWL3R9XD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1MWWL3R9XD`
--

LOCK TABLES `1MWWL3R9XD` WRITE;
/*!40000 ALTER TABLE `1MWWL3R9XD` DISABLE KEYS */;
/*!40000 ALTER TABLE `1MWWL3R9XD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1NZBHUPKQ9`
--

DROP TABLE IF EXISTS `1NZBHUPKQ9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1NZBHUPKQ9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1NZBHUPKQ9`
--

LOCK TABLES `1NZBHUPKQ9` WRITE;
/*!40000 ALTER TABLE `1NZBHUPKQ9` DISABLE KEYS */;
/*!40000 ALTER TABLE `1NZBHUPKQ9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1PUDVINNNC`
--

DROP TABLE IF EXISTS `1PUDVINNNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1PUDVINNNC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1PUDVINNNC`
--

LOCK TABLES `1PUDVINNNC` WRITE;
/*!40000 ALTER TABLE `1PUDVINNNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `1PUDVINNNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1QIQWCG9TP`
--

DROP TABLE IF EXISTS `1QIQWCG9TP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1QIQWCG9TP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1QIQWCG9TP`
--

LOCK TABLES `1QIQWCG9TP` WRITE;
/*!40000 ALTER TABLE `1QIQWCG9TP` DISABLE KEYS */;
/*!40000 ALTER TABLE `1QIQWCG9TP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1QMSVIG6HL`
--

DROP TABLE IF EXISTS `1QMSVIG6HL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1QMSVIG6HL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1QMSVIG6HL`
--

LOCK TABLES `1QMSVIG6HL` WRITE;
/*!40000 ALTER TABLE `1QMSVIG6HL` DISABLE KEYS */;
/*!40000 ALTER TABLE `1QMSVIG6HL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1RW80TU1Q7`
--

DROP TABLE IF EXISTS `1RW80TU1Q7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1RW80TU1Q7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1RW80TU1Q7`
--

LOCK TABLES `1RW80TU1Q7` WRITE;
/*!40000 ALTER TABLE `1RW80TU1Q7` DISABLE KEYS */;
/*!40000 ALTER TABLE `1RW80TU1Q7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1T0WL49TOH`
--

DROP TABLE IF EXISTS `1T0WL49TOH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1T0WL49TOH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1T0WL49TOH`
--

LOCK TABLES `1T0WL49TOH` WRITE;
/*!40000 ALTER TABLE `1T0WL49TOH` DISABLE KEYS */;
/*!40000 ALTER TABLE `1T0WL49TOH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1VZAMDVI1Z`
--

DROP TABLE IF EXISTS `1VZAMDVI1Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1VZAMDVI1Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1VZAMDVI1Z`
--

LOCK TABLES `1VZAMDVI1Z` WRITE;
/*!40000 ALTER TABLE `1VZAMDVI1Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `1VZAMDVI1Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1WOUQDBT2C`
--

DROP TABLE IF EXISTS `1WOUQDBT2C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1WOUQDBT2C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1WOUQDBT2C`
--

LOCK TABLES `1WOUQDBT2C` WRITE;
/*!40000 ALTER TABLE `1WOUQDBT2C` DISABLE KEYS */;
/*!40000 ALTER TABLE `1WOUQDBT2C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1XYP1WUOA9`
--

DROP TABLE IF EXISTS `1XYP1WUOA9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1XYP1WUOA9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1XYP1WUOA9`
--

LOCK TABLES `1XYP1WUOA9` WRITE;
/*!40000 ALTER TABLE `1XYP1WUOA9` DISABLE KEYS */;
/*!40000 ALTER TABLE `1XYP1WUOA9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1Y56DN7YAL`
--

DROP TABLE IF EXISTS `1Y56DN7YAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1Y56DN7YAL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1Y56DN7YAL`
--

LOCK TABLES `1Y56DN7YAL` WRITE;
/*!40000 ALTER TABLE `1Y56DN7YAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `1Y56DN7YAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `1ZJTTVLP2S`
--

DROP TABLE IF EXISTS `1ZJTTVLP2S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `1ZJTTVLP2S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `1ZJTTVLP2S`
--

LOCK TABLES `1ZJTTVLP2S` WRITE;
/*!40000 ALTER TABLE `1ZJTTVLP2S` DISABLE KEYS */;
/*!40000 ALTER TABLE `1ZJTTVLP2S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `218G2T3CR9`
--

DROP TABLE IF EXISTS `218G2T3CR9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `218G2T3CR9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `218G2T3CR9`
--

LOCK TABLES `218G2T3CR9` WRITE;
/*!40000 ALTER TABLE `218G2T3CR9` DISABLE KEYS */;
/*!40000 ALTER TABLE `218G2T3CR9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `21C3H6PFAH`
--

DROP TABLE IF EXISTS `21C3H6PFAH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `21C3H6PFAH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `21C3H6PFAH`
--

LOCK TABLES `21C3H6PFAH` WRITE;
/*!40000 ALTER TABLE `21C3H6PFAH` DISABLE KEYS */;
/*!40000 ALTER TABLE `21C3H6PFAH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `21QM5JL9J2`
--

DROP TABLE IF EXISTS `21QM5JL9J2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `21QM5JL9J2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `21QM5JL9J2`
--

LOCK TABLES `21QM5JL9J2` WRITE;
/*!40000 ALTER TABLE `21QM5JL9J2` DISABLE KEYS */;
/*!40000 ALTER TABLE `21QM5JL9J2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `21ZEPD7TJV`
--

DROP TABLE IF EXISTS `21ZEPD7TJV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `21ZEPD7TJV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `21ZEPD7TJV`
--

LOCK TABLES `21ZEPD7TJV` WRITE;
/*!40000 ALTER TABLE `21ZEPD7TJV` DISABLE KEYS */;
/*!40000 ALTER TABLE `21ZEPD7TJV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `23GCPQVHLW`
--

DROP TABLE IF EXISTS `23GCPQVHLW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `23GCPQVHLW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `23GCPQVHLW`
--

LOCK TABLES `23GCPQVHLW` WRITE;
/*!40000 ALTER TABLE `23GCPQVHLW` DISABLE KEYS */;
/*!40000 ALTER TABLE `23GCPQVHLW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `258LWYGS9D`
--

DROP TABLE IF EXISTS `258LWYGS9D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `258LWYGS9D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `258LWYGS9D`
--

LOCK TABLES `258LWYGS9D` WRITE;
/*!40000 ALTER TABLE `258LWYGS9D` DISABLE KEYS */;
/*!40000 ALTER TABLE `258LWYGS9D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `26WIKIAQ3X`
--

DROP TABLE IF EXISTS `26WIKIAQ3X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `26WIKIAQ3X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `26WIKIAQ3X`
--

LOCK TABLES `26WIKIAQ3X` WRITE;
/*!40000 ALTER TABLE `26WIKIAQ3X` DISABLE KEYS */;
/*!40000 ALTER TABLE `26WIKIAQ3X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2BALJTHBOI`
--

DROP TABLE IF EXISTS `2BALJTHBOI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2BALJTHBOI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2BALJTHBOI`
--

LOCK TABLES `2BALJTHBOI` WRITE;
/*!40000 ALTER TABLE `2BALJTHBOI` DISABLE KEYS */;
/*!40000 ALTER TABLE `2BALJTHBOI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2BV4Q5PA0M`
--

DROP TABLE IF EXISTS `2BV4Q5PA0M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2BV4Q5PA0M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2BV4Q5PA0M`
--

LOCK TABLES `2BV4Q5PA0M` WRITE;
/*!40000 ALTER TABLE `2BV4Q5PA0M` DISABLE KEYS */;
/*!40000 ALTER TABLE `2BV4Q5PA0M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2F6C72Q0TU`
--

DROP TABLE IF EXISTS `2F6C72Q0TU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2F6C72Q0TU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2F6C72Q0TU`
--

LOCK TABLES `2F6C72Q0TU` WRITE;
/*!40000 ALTER TABLE `2F6C72Q0TU` DISABLE KEYS */;
/*!40000 ALTER TABLE `2F6C72Q0TU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2HTCHVHU6K`
--

DROP TABLE IF EXISTS `2HTCHVHU6K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2HTCHVHU6K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2HTCHVHU6K`
--

LOCK TABLES `2HTCHVHU6K` WRITE;
/*!40000 ALTER TABLE `2HTCHVHU6K` DISABLE KEYS */;
/*!40000 ALTER TABLE `2HTCHVHU6K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2IZEA7ST0X`
--

DROP TABLE IF EXISTS `2IZEA7ST0X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2IZEA7ST0X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2IZEA7ST0X`
--

LOCK TABLES `2IZEA7ST0X` WRITE;
/*!40000 ALTER TABLE `2IZEA7ST0X` DISABLE KEYS */;
/*!40000 ALTER TABLE `2IZEA7ST0X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2K6NGDNJLG`
--

DROP TABLE IF EXISTS `2K6NGDNJLG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2K6NGDNJLG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2K6NGDNJLG`
--

LOCK TABLES `2K6NGDNJLG` WRITE;
/*!40000 ALTER TABLE `2K6NGDNJLG` DISABLE KEYS */;
/*!40000 ALTER TABLE `2K6NGDNJLG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2MPF7QJC49`
--

DROP TABLE IF EXISTS `2MPF7QJC49`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2MPF7QJC49` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2MPF7QJC49`
--

LOCK TABLES `2MPF7QJC49` WRITE;
/*!40000 ALTER TABLE `2MPF7QJC49` DISABLE KEYS */;
/*!40000 ALTER TABLE `2MPF7QJC49` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2N1VA123H8`
--

DROP TABLE IF EXISTS `2N1VA123H8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2N1VA123H8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2N1VA123H8`
--

LOCK TABLES `2N1VA123H8` WRITE;
/*!40000 ALTER TABLE `2N1VA123H8` DISABLE KEYS */;
/*!40000 ALTER TABLE `2N1VA123H8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2ORSFYOQNZ`
--

DROP TABLE IF EXISTS `2ORSFYOQNZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2ORSFYOQNZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2ORSFYOQNZ`
--

LOCK TABLES `2ORSFYOQNZ` WRITE;
/*!40000 ALTER TABLE `2ORSFYOQNZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `2ORSFYOQNZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2PYPA2ROXZ`
--

DROP TABLE IF EXISTS `2PYPA2ROXZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2PYPA2ROXZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2PYPA2ROXZ`
--

LOCK TABLES `2PYPA2ROXZ` WRITE;
/*!40000 ALTER TABLE `2PYPA2ROXZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `2PYPA2ROXZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2Q272LZODC`
--

DROP TABLE IF EXISTS `2Q272LZODC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2Q272LZODC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2Q272LZODC`
--

LOCK TABLES `2Q272LZODC` WRITE;
/*!40000 ALTER TABLE `2Q272LZODC` DISABLE KEYS */;
/*!40000 ALTER TABLE `2Q272LZODC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2QD57TEDDA`
--

DROP TABLE IF EXISTS `2QD57TEDDA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2QD57TEDDA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2QD57TEDDA`
--

LOCK TABLES `2QD57TEDDA` WRITE;
/*!40000 ALTER TABLE `2QD57TEDDA` DISABLE KEYS */;
/*!40000 ALTER TABLE `2QD57TEDDA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2WNXES9YKR`
--

DROP TABLE IF EXISTS `2WNXES9YKR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2WNXES9YKR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2WNXES9YKR`
--

LOCK TABLES `2WNXES9YKR` WRITE;
/*!40000 ALTER TABLE `2WNXES9YKR` DISABLE KEYS */;
/*!40000 ALTER TABLE `2WNXES9YKR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2XJFIY6LU2`
--

DROP TABLE IF EXISTS `2XJFIY6LU2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2XJFIY6LU2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2XJFIY6LU2`
--

LOCK TABLES `2XJFIY6LU2` WRITE;
/*!40000 ALTER TABLE `2XJFIY6LU2` DISABLE KEYS */;
/*!40000 ALTER TABLE `2XJFIY6LU2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2Y3EK0OXXS`
--

DROP TABLE IF EXISTS `2Y3EK0OXXS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2Y3EK0OXXS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2Y3EK0OXXS`
--

LOCK TABLES `2Y3EK0OXXS` WRITE;
/*!40000 ALTER TABLE `2Y3EK0OXXS` DISABLE KEYS */;
/*!40000 ALTER TABLE `2Y3EK0OXXS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2Y44IVRJIE`
--

DROP TABLE IF EXISTS `2Y44IVRJIE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2Y44IVRJIE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2Y44IVRJIE`
--

LOCK TABLES `2Y44IVRJIE` WRITE;
/*!40000 ALTER TABLE `2Y44IVRJIE` DISABLE KEYS */;
/*!40000 ALTER TABLE `2Y44IVRJIE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `2YR5JOALMI`
--

DROP TABLE IF EXISTS `2YR5JOALMI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `2YR5JOALMI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2YR5JOALMI`
--

LOCK TABLES `2YR5JOALMI` WRITE;
/*!40000 ALTER TABLE `2YR5JOALMI` DISABLE KEYS */;
/*!40000 ALTER TABLE `2YR5JOALMI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `31E9S3Q6RR`
--

DROP TABLE IF EXISTS `31E9S3Q6RR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `31E9S3Q6RR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `31E9S3Q6RR`
--

LOCK TABLES `31E9S3Q6RR` WRITE;
/*!40000 ALTER TABLE `31E9S3Q6RR` DISABLE KEYS */;
/*!40000 ALTER TABLE `31E9S3Q6RR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `31EVB3YBF7`
--

DROP TABLE IF EXISTS `31EVB3YBF7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `31EVB3YBF7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `31EVB3YBF7`
--

LOCK TABLES `31EVB3YBF7` WRITE;
/*!40000 ALTER TABLE `31EVB3YBF7` DISABLE KEYS */;
/*!40000 ALTER TABLE `31EVB3YBF7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `36AMPSOQCL`
--

DROP TABLE IF EXISTS `36AMPSOQCL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `36AMPSOQCL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `36AMPSOQCL`
--

LOCK TABLES `36AMPSOQCL` WRITE;
/*!40000 ALTER TABLE `36AMPSOQCL` DISABLE KEYS */;
/*!40000 ALTER TABLE `36AMPSOQCL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `37IDGW64W6`
--

DROP TABLE IF EXISTS `37IDGW64W6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `37IDGW64W6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `37IDGW64W6`
--

LOCK TABLES `37IDGW64W6` WRITE;
/*!40000 ALTER TABLE `37IDGW64W6` DISABLE KEYS */;
/*!40000 ALTER TABLE `37IDGW64W6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `38IHQC4NBX`
--

DROP TABLE IF EXISTS `38IHQC4NBX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `38IHQC4NBX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `38IHQC4NBX`
--

LOCK TABLES `38IHQC4NBX` WRITE;
/*!40000 ALTER TABLE `38IHQC4NBX` DISABLE KEYS */;
/*!40000 ALTER TABLE `38IHQC4NBX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `39BHHQKQ10`
--

DROP TABLE IF EXISTS `39BHHQKQ10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `39BHHQKQ10` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `39BHHQKQ10`
--

LOCK TABLES `39BHHQKQ10` WRITE;
/*!40000 ALTER TABLE `39BHHQKQ10` DISABLE KEYS */;
/*!40000 ALTER TABLE `39BHHQKQ10` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3A8DYZJC2E`
--

DROP TABLE IF EXISTS `3A8DYZJC2E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3A8DYZJC2E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3A8DYZJC2E`
--

LOCK TABLES `3A8DYZJC2E` WRITE;
/*!40000 ALTER TABLE `3A8DYZJC2E` DISABLE KEYS */;
/*!40000 ALTER TABLE `3A8DYZJC2E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3B5RZFM9SN`
--

DROP TABLE IF EXISTS `3B5RZFM9SN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3B5RZFM9SN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3B5RZFM9SN`
--

LOCK TABLES `3B5RZFM9SN` WRITE;
/*!40000 ALTER TABLE `3B5RZFM9SN` DISABLE KEYS */;
/*!40000 ALTER TABLE `3B5RZFM9SN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3D7L3HAWOT`
--

DROP TABLE IF EXISTS `3D7L3HAWOT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3D7L3HAWOT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3D7L3HAWOT`
--

LOCK TABLES `3D7L3HAWOT` WRITE;
/*!40000 ALTER TABLE `3D7L3HAWOT` DISABLE KEYS */;
/*!40000 ALTER TABLE `3D7L3HAWOT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3D9XD8JT4C`
--

DROP TABLE IF EXISTS `3D9XD8JT4C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3D9XD8JT4C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3D9XD8JT4C`
--

LOCK TABLES `3D9XD8JT4C` WRITE;
/*!40000 ALTER TABLE `3D9XD8JT4C` DISABLE KEYS */;
/*!40000 ALTER TABLE `3D9XD8JT4C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3G6UJ0BGQO`
--

DROP TABLE IF EXISTS `3G6UJ0BGQO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3G6UJ0BGQO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3G6UJ0BGQO`
--

LOCK TABLES `3G6UJ0BGQO` WRITE;
/*!40000 ALTER TABLE `3G6UJ0BGQO` DISABLE KEYS */;
/*!40000 ALTER TABLE `3G6UJ0BGQO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3IMLQII78V`
--

DROP TABLE IF EXISTS `3IMLQII78V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3IMLQII78V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3IMLQII78V`
--

LOCK TABLES `3IMLQII78V` WRITE;
/*!40000 ALTER TABLE `3IMLQII78V` DISABLE KEYS */;
/*!40000 ALTER TABLE `3IMLQII78V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3JGKIZE21C`
--

DROP TABLE IF EXISTS `3JGKIZE21C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3JGKIZE21C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3JGKIZE21C`
--

LOCK TABLES `3JGKIZE21C` WRITE;
/*!40000 ALTER TABLE `3JGKIZE21C` DISABLE KEYS */;
/*!40000 ALTER TABLE `3JGKIZE21C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3JUVL8ZW9P`
--

DROP TABLE IF EXISTS `3JUVL8ZW9P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3JUVL8ZW9P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3JUVL8ZW9P`
--

LOCK TABLES `3JUVL8ZW9P` WRITE;
/*!40000 ALTER TABLE `3JUVL8ZW9P` DISABLE KEYS */;
/*!40000 ALTER TABLE `3JUVL8ZW9P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3KPLDKBUKQ`
--

DROP TABLE IF EXISTS `3KPLDKBUKQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3KPLDKBUKQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3KPLDKBUKQ`
--

LOCK TABLES `3KPLDKBUKQ` WRITE;
/*!40000 ALTER TABLE `3KPLDKBUKQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `3KPLDKBUKQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3NYMBS61ZC`
--

DROP TABLE IF EXISTS `3NYMBS61ZC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3NYMBS61ZC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3NYMBS61ZC`
--

LOCK TABLES `3NYMBS61ZC` WRITE;
/*!40000 ALTER TABLE `3NYMBS61ZC` DISABLE KEYS */;
/*!40000 ALTER TABLE `3NYMBS61ZC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3O969JOTQ5`
--

DROP TABLE IF EXISTS `3O969JOTQ5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3O969JOTQ5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3O969JOTQ5`
--

LOCK TABLES `3O969JOTQ5` WRITE;
/*!40000 ALTER TABLE `3O969JOTQ5` DISABLE KEYS */;
/*!40000 ALTER TABLE `3O969JOTQ5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3Q31F9MTKL`
--

DROP TABLE IF EXISTS `3Q31F9MTKL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3Q31F9MTKL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3Q31F9MTKL`
--

LOCK TABLES `3Q31F9MTKL` WRITE;
/*!40000 ALTER TABLE `3Q31F9MTKL` DISABLE KEYS */;
/*!40000 ALTER TABLE `3Q31F9MTKL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3SY39K78GM`
--

DROP TABLE IF EXISTS `3SY39K78GM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3SY39K78GM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3SY39K78GM`
--

LOCK TABLES `3SY39K78GM` WRITE;
/*!40000 ALTER TABLE `3SY39K78GM` DISABLE KEYS */;
/*!40000 ALTER TABLE `3SY39K78GM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3TLXWGDE1P`
--

DROP TABLE IF EXISTS `3TLXWGDE1P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3TLXWGDE1P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3TLXWGDE1P`
--

LOCK TABLES `3TLXWGDE1P` WRITE;
/*!40000 ALTER TABLE `3TLXWGDE1P` DISABLE KEYS */;
/*!40000 ALTER TABLE `3TLXWGDE1P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3TMK2OGMZ1`
--

DROP TABLE IF EXISTS `3TMK2OGMZ1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3TMK2OGMZ1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3TMK2OGMZ1`
--

LOCK TABLES `3TMK2OGMZ1` WRITE;
/*!40000 ALTER TABLE `3TMK2OGMZ1` DISABLE KEYS */;
/*!40000 ALTER TABLE `3TMK2OGMZ1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3VGCUA8KEP`
--

DROP TABLE IF EXISTS `3VGCUA8KEP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3VGCUA8KEP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3VGCUA8KEP`
--

LOCK TABLES `3VGCUA8KEP` WRITE;
/*!40000 ALTER TABLE `3VGCUA8KEP` DISABLE KEYS */;
/*!40000 ALTER TABLE `3VGCUA8KEP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3VHEBIYL65`
--

DROP TABLE IF EXISTS `3VHEBIYL65`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3VHEBIYL65` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3VHEBIYL65`
--

LOCK TABLES `3VHEBIYL65` WRITE;
/*!40000 ALTER TABLE `3VHEBIYL65` DISABLE KEYS */;
/*!40000 ALTER TABLE `3VHEBIYL65` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3XUCQLFE8S`
--

DROP TABLE IF EXISTS `3XUCQLFE8S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3XUCQLFE8S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3XUCQLFE8S`
--

LOCK TABLES `3XUCQLFE8S` WRITE;
/*!40000 ALTER TABLE `3XUCQLFE8S` DISABLE KEYS */;
/*!40000 ALTER TABLE `3XUCQLFE8S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3XW78FONX5`
--

DROP TABLE IF EXISTS `3XW78FONX5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3XW78FONX5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3XW78FONX5`
--

LOCK TABLES `3XW78FONX5` WRITE;
/*!40000 ALTER TABLE `3XW78FONX5` DISABLE KEYS */;
/*!40000 ALTER TABLE `3XW78FONX5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3YHZYYQPSM`
--

DROP TABLE IF EXISTS `3YHZYYQPSM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3YHZYYQPSM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3YHZYYQPSM`
--

LOCK TABLES `3YHZYYQPSM` WRITE;
/*!40000 ALTER TABLE `3YHZYYQPSM` DISABLE KEYS */;
/*!40000 ALTER TABLE `3YHZYYQPSM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3YXK2ICY3Z`
--

DROP TABLE IF EXISTS `3YXK2ICY3Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3YXK2ICY3Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3YXK2ICY3Z`
--

LOCK TABLES `3YXK2ICY3Z` WRITE;
/*!40000 ALTER TABLE `3YXK2ICY3Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `3YXK2ICY3Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3ZQCKVDZQW`
--

DROP TABLE IF EXISTS `3ZQCKVDZQW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3ZQCKVDZQW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3ZQCKVDZQW`
--

LOCK TABLES `3ZQCKVDZQW` WRITE;
/*!40000 ALTER TABLE `3ZQCKVDZQW` DISABLE KEYS */;
/*!40000 ALTER TABLE `3ZQCKVDZQW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `3ZQWBZ7TA8`
--

DROP TABLE IF EXISTS `3ZQWBZ7TA8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `3ZQWBZ7TA8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `3ZQWBZ7TA8`
--

LOCK TABLES `3ZQWBZ7TA8` WRITE;
/*!40000 ALTER TABLE `3ZQWBZ7TA8` DISABLE KEYS */;
/*!40000 ALTER TABLE `3ZQWBZ7TA8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `40EYSP9BTK`
--

DROP TABLE IF EXISTS `40EYSP9BTK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `40EYSP9BTK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `40EYSP9BTK`
--

LOCK TABLES `40EYSP9BTK` WRITE;
/*!40000 ALTER TABLE `40EYSP9BTK` DISABLE KEYS */;
/*!40000 ALTER TABLE `40EYSP9BTK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `41CKLV1C0X`
--

DROP TABLE IF EXISTS `41CKLV1C0X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `41CKLV1C0X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `41CKLV1C0X`
--

LOCK TABLES `41CKLV1C0X` WRITE;
/*!40000 ALTER TABLE `41CKLV1C0X` DISABLE KEYS */;
/*!40000 ALTER TABLE `41CKLV1C0X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `42ISYDLPY7`
--

DROP TABLE IF EXISTS `42ISYDLPY7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `42ISYDLPY7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `42ISYDLPY7`
--

LOCK TABLES `42ISYDLPY7` WRITE;
/*!40000 ALTER TABLE `42ISYDLPY7` DISABLE KEYS */;
/*!40000 ALTER TABLE `42ISYDLPY7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4618ZUC98R`
--

DROP TABLE IF EXISTS `4618ZUC98R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4618ZUC98R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4618ZUC98R`
--

LOCK TABLES `4618ZUC98R` WRITE;
/*!40000 ALTER TABLE `4618ZUC98R` DISABLE KEYS */;
/*!40000 ALTER TABLE `4618ZUC98R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4729XRPAYB`
--

DROP TABLE IF EXISTS `4729XRPAYB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4729XRPAYB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4729XRPAYB`
--

LOCK TABLES `4729XRPAYB` WRITE;
/*!40000 ALTER TABLE `4729XRPAYB` DISABLE KEYS */;
/*!40000 ALTER TABLE `4729XRPAYB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4758VD8TRU`
--

DROP TABLE IF EXISTS `4758VD8TRU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4758VD8TRU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4758VD8TRU`
--

LOCK TABLES `4758VD8TRU` WRITE;
/*!40000 ALTER TABLE `4758VD8TRU` DISABLE KEYS */;
/*!40000 ALTER TABLE `4758VD8TRU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4BNCF4I7PK`
--

DROP TABLE IF EXISTS `4BNCF4I7PK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4BNCF4I7PK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4BNCF4I7PK`
--

LOCK TABLES `4BNCF4I7PK` WRITE;
/*!40000 ALTER TABLE `4BNCF4I7PK` DISABLE KEYS */;
/*!40000 ALTER TABLE `4BNCF4I7PK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4BQQJKMGNY`
--

DROP TABLE IF EXISTS `4BQQJKMGNY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4BQQJKMGNY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4BQQJKMGNY`
--

LOCK TABLES `4BQQJKMGNY` WRITE;
/*!40000 ALTER TABLE `4BQQJKMGNY` DISABLE KEYS */;
/*!40000 ALTER TABLE `4BQQJKMGNY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4BWQR2E3XG`
--

DROP TABLE IF EXISTS `4BWQR2E3XG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4BWQR2E3XG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4BWQR2E3XG`
--

LOCK TABLES `4BWQR2E3XG` WRITE;
/*!40000 ALTER TABLE `4BWQR2E3XG` DISABLE KEYS */;
/*!40000 ALTER TABLE `4BWQR2E3XG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4CE7WB00XX`
--

DROP TABLE IF EXISTS `4CE7WB00XX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4CE7WB00XX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4CE7WB00XX`
--

LOCK TABLES `4CE7WB00XX` WRITE;
/*!40000 ALTER TABLE `4CE7WB00XX` DISABLE KEYS */;
/*!40000 ALTER TABLE `4CE7WB00XX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4D7VL6YS9A`
--

DROP TABLE IF EXISTS `4D7VL6YS9A`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4D7VL6YS9A` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4D7VL6YS9A`
--

LOCK TABLES `4D7VL6YS9A` WRITE;
/*!40000 ALTER TABLE `4D7VL6YS9A` DISABLE KEYS */;
/*!40000 ALTER TABLE `4D7VL6YS9A` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4EMACPMSOQ`
--

DROP TABLE IF EXISTS `4EMACPMSOQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4EMACPMSOQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4EMACPMSOQ`
--

LOCK TABLES `4EMACPMSOQ` WRITE;
/*!40000 ALTER TABLE `4EMACPMSOQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `4EMACPMSOQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4FIIACJCXN`
--

DROP TABLE IF EXISTS `4FIIACJCXN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4FIIACJCXN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4FIIACJCXN`
--

LOCK TABLES `4FIIACJCXN` WRITE;
/*!40000 ALTER TABLE `4FIIACJCXN` DISABLE KEYS */;
/*!40000 ALTER TABLE `4FIIACJCXN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4GF73X03VR`
--

DROP TABLE IF EXISTS `4GF73X03VR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4GF73X03VR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4GF73X03VR`
--

LOCK TABLES `4GF73X03VR` WRITE;
/*!40000 ALTER TABLE `4GF73X03VR` DISABLE KEYS */;
/*!40000 ALTER TABLE `4GF73X03VR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4GPILED602`
--

DROP TABLE IF EXISTS `4GPILED602`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4GPILED602` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4GPILED602`
--

LOCK TABLES `4GPILED602` WRITE;
/*!40000 ALTER TABLE `4GPILED602` DISABLE KEYS */;
/*!40000 ALTER TABLE `4GPILED602` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4HUZZZANSF`
--

DROP TABLE IF EXISTS `4HUZZZANSF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4HUZZZANSF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4HUZZZANSF`
--

LOCK TABLES `4HUZZZANSF` WRITE;
/*!40000 ALTER TABLE `4HUZZZANSF` DISABLE KEYS */;
/*!40000 ALTER TABLE `4HUZZZANSF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4I90CA2FEA`
--

DROP TABLE IF EXISTS `4I90CA2FEA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4I90CA2FEA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4I90CA2FEA`
--

LOCK TABLES `4I90CA2FEA` WRITE;
/*!40000 ALTER TABLE `4I90CA2FEA` DISABLE KEYS */;
/*!40000 ALTER TABLE `4I90CA2FEA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4K7CP4100Z`
--

DROP TABLE IF EXISTS `4K7CP4100Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4K7CP4100Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4K7CP4100Z`
--

LOCK TABLES `4K7CP4100Z` WRITE;
/*!40000 ALTER TABLE `4K7CP4100Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `4K7CP4100Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4OM4XL2D8B`
--

DROP TABLE IF EXISTS `4OM4XL2D8B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4OM4XL2D8B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4OM4XL2D8B`
--

LOCK TABLES `4OM4XL2D8B` WRITE;
/*!40000 ALTER TABLE `4OM4XL2D8B` DISABLE KEYS */;
/*!40000 ALTER TABLE `4OM4XL2D8B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4PI47YOKZL`
--

DROP TABLE IF EXISTS `4PI47YOKZL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4PI47YOKZL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4PI47YOKZL`
--

LOCK TABLES `4PI47YOKZL` WRITE;
/*!40000 ALTER TABLE `4PI47YOKZL` DISABLE KEYS */;
/*!40000 ALTER TABLE `4PI47YOKZL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4S13AETHJZ`
--

DROP TABLE IF EXISTS `4S13AETHJZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4S13AETHJZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4S13AETHJZ`
--

LOCK TABLES `4S13AETHJZ` WRITE;
/*!40000 ALTER TABLE `4S13AETHJZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `4S13AETHJZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4T1BD46QN7`
--

DROP TABLE IF EXISTS `4T1BD46QN7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4T1BD46QN7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4T1BD46QN7`
--

LOCK TABLES `4T1BD46QN7` WRITE;
/*!40000 ALTER TABLE `4T1BD46QN7` DISABLE KEYS */;
/*!40000 ALTER TABLE `4T1BD46QN7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4UVEA466H3`
--

DROP TABLE IF EXISTS `4UVEA466H3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4UVEA466H3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4UVEA466H3`
--

LOCK TABLES `4UVEA466H3` WRITE;
/*!40000 ALTER TABLE `4UVEA466H3` DISABLE KEYS */;
/*!40000 ALTER TABLE `4UVEA466H3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4V2DQT0UZL`
--

DROP TABLE IF EXISTS `4V2DQT0UZL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4V2DQT0UZL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4V2DQT0UZL`
--

LOCK TABLES `4V2DQT0UZL` WRITE;
/*!40000 ALTER TABLE `4V2DQT0UZL` DISABLE KEYS */;
/*!40000 ALTER TABLE `4V2DQT0UZL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4VMF227BO4`
--

DROP TABLE IF EXISTS `4VMF227BO4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4VMF227BO4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4VMF227BO4`
--

LOCK TABLES `4VMF227BO4` WRITE;
/*!40000 ALTER TABLE `4VMF227BO4` DISABLE KEYS */;
/*!40000 ALTER TABLE `4VMF227BO4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4W2YB2THPX`
--

DROP TABLE IF EXISTS `4W2YB2THPX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4W2YB2THPX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4W2YB2THPX`
--

LOCK TABLES `4W2YB2THPX` WRITE;
/*!40000 ALTER TABLE `4W2YB2THPX` DISABLE KEYS */;
/*!40000 ALTER TABLE `4W2YB2THPX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4W32GM9ETF`
--

DROP TABLE IF EXISTS `4W32GM9ETF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4W32GM9ETF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4W32GM9ETF`
--

LOCK TABLES `4W32GM9ETF` WRITE;
/*!40000 ALTER TABLE `4W32GM9ETF` DISABLE KEYS */;
/*!40000 ALTER TABLE `4W32GM9ETF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4YGRQKTV0F`
--

DROP TABLE IF EXISTS `4YGRQKTV0F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4YGRQKTV0F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4YGRQKTV0F`
--

LOCK TABLES `4YGRQKTV0F` WRITE;
/*!40000 ALTER TABLE `4YGRQKTV0F` DISABLE KEYS */;
/*!40000 ALTER TABLE `4YGRQKTV0F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4YJ3JTOZKP`
--

DROP TABLE IF EXISTS `4YJ3JTOZKP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4YJ3JTOZKP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4YJ3JTOZKP`
--

LOCK TABLES `4YJ3JTOZKP` WRITE;
/*!40000 ALTER TABLE `4YJ3JTOZKP` DISABLE KEYS */;
/*!40000 ALTER TABLE `4YJ3JTOZKP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `4ZLN5OWUAB`
--

DROP TABLE IF EXISTS `4ZLN5OWUAB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `4ZLN5OWUAB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `4ZLN5OWUAB`
--

LOCK TABLES `4ZLN5OWUAB` WRITE;
/*!40000 ALTER TABLE `4ZLN5OWUAB` DISABLE KEYS */;
/*!40000 ALTER TABLE `4ZLN5OWUAB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `52R2FVQK63`
--

DROP TABLE IF EXISTS `52R2FVQK63`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `52R2FVQK63` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `52R2FVQK63`
--

LOCK TABLES `52R2FVQK63` WRITE;
/*!40000 ALTER TABLE `52R2FVQK63` DISABLE KEYS */;
/*!40000 ALTER TABLE `52R2FVQK63` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `54V6746E2U`
--

DROP TABLE IF EXISTS `54V6746E2U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `54V6746E2U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `54V6746E2U`
--

LOCK TABLES `54V6746E2U` WRITE;
/*!40000 ALTER TABLE `54V6746E2U` DISABLE KEYS */;
/*!40000 ALTER TABLE `54V6746E2U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `59DMICSTE6`
--

DROP TABLE IF EXISTS `59DMICSTE6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `59DMICSTE6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `59DMICSTE6`
--

LOCK TABLES `59DMICSTE6` WRITE;
/*!40000 ALTER TABLE `59DMICSTE6` DISABLE KEYS */;
/*!40000 ALTER TABLE `59DMICSTE6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `59FU1G15D8`
--

DROP TABLE IF EXISTS `59FU1G15D8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `59FU1G15D8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `59FU1G15D8`
--

LOCK TABLES `59FU1G15D8` WRITE;
/*!40000 ALTER TABLE `59FU1G15D8` DISABLE KEYS */;
/*!40000 ALTER TABLE `59FU1G15D8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5A091DRCI3`
--

DROP TABLE IF EXISTS `5A091DRCI3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5A091DRCI3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5A091DRCI3`
--

LOCK TABLES `5A091DRCI3` WRITE;
/*!40000 ALTER TABLE `5A091DRCI3` DISABLE KEYS */;
/*!40000 ALTER TABLE `5A091DRCI3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5ALEEJZHOO`
--

DROP TABLE IF EXISTS `5ALEEJZHOO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5ALEEJZHOO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5ALEEJZHOO`
--

LOCK TABLES `5ALEEJZHOO` WRITE;
/*!40000 ALTER TABLE `5ALEEJZHOO` DISABLE KEYS */;
/*!40000 ALTER TABLE `5ALEEJZHOO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5C9FUK4GQA`
--

DROP TABLE IF EXISTS `5C9FUK4GQA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5C9FUK4GQA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5C9FUK4GQA`
--

LOCK TABLES `5C9FUK4GQA` WRITE;
/*!40000 ALTER TABLE `5C9FUK4GQA` DISABLE KEYS */;
/*!40000 ALTER TABLE `5C9FUK4GQA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5EJLDEIAA3`
--

DROP TABLE IF EXISTS `5EJLDEIAA3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5EJLDEIAA3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5EJLDEIAA3`
--

LOCK TABLES `5EJLDEIAA3` WRITE;
/*!40000 ALTER TABLE `5EJLDEIAA3` DISABLE KEYS */;
/*!40000 ALTER TABLE `5EJLDEIAA3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5F1SXFAI1X`
--

DROP TABLE IF EXISTS `5F1SXFAI1X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5F1SXFAI1X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5F1SXFAI1X`
--

LOCK TABLES `5F1SXFAI1X` WRITE;
/*!40000 ALTER TABLE `5F1SXFAI1X` DISABLE KEYS */;
/*!40000 ALTER TABLE `5F1SXFAI1X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5GUL5VL51Z`
--

DROP TABLE IF EXISTS `5GUL5VL51Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5GUL5VL51Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5GUL5VL51Z`
--

LOCK TABLES `5GUL5VL51Z` WRITE;
/*!40000 ALTER TABLE `5GUL5VL51Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `5GUL5VL51Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5HD94X4AIM`
--

DROP TABLE IF EXISTS `5HD94X4AIM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5HD94X4AIM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5HD94X4AIM`
--

LOCK TABLES `5HD94X4AIM` WRITE;
/*!40000 ALTER TABLE `5HD94X4AIM` DISABLE KEYS */;
/*!40000 ALTER TABLE `5HD94X4AIM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5HLV3BJE6E`
--

DROP TABLE IF EXISTS `5HLV3BJE6E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5HLV3BJE6E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5HLV3BJE6E`
--

LOCK TABLES `5HLV3BJE6E` WRITE;
/*!40000 ALTER TABLE `5HLV3BJE6E` DISABLE KEYS */;
/*!40000 ALTER TABLE `5HLV3BJE6E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5IEYK1LQS8`
--

DROP TABLE IF EXISTS `5IEYK1LQS8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5IEYK1LQS8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5IEYK1LQS8`
--

LOCK TABLES `5IEYK1LQS8` WRITE;
/*!40000 ALTER TABLE `5IEYK1LQS8` DISABLE KEYS */;
/*!40000 ALTER TABLE `5IEYK1LQS8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5JRAL9N0MM`
--

DROP TABLE IF EXISTS `5JRAL9N0MM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5JRAL9N0MM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5JRAL9N0MM`
--

LOCK TABLES `5JRAL9N0MM` WRITE;
/*!40000 ALTER TABLE `5JRAL9N0MM` DISABLE KEYS */;
/*!40000 ALTER TABLE `5JRAL9N0MM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5K41PMUWW1`
--

DROP TABLE IF EXISTS `5K41PMUWW1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5K41PMUWW1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5K41PMUWW1`
--

LOCK TABLES `5K41PMUWW1` WRITE;
/*!40000 ALTER TABLE `5K41PMUWW1` DISABLE KEYS */;
/*!40000 ALTER TABLE `5K41PMUWW1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5N4EZ79MR5`
--

DROP TABLE IF EXISTS `5N4EZ79MR5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5N4EZ79MR5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5N4EZ79MR5`
--

LOCK TABLES `5N4EZ79MR5` WRITE;
/*!40000 ALTER TABLE `5N4EZ79MR5` DISABLE KEYS */;
/*!40000 ALTER TABLE `5N4EZ79MR5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5OO1XRYB4J`
--

DROP TABLE IF EXISTS `5OO1XRYB4J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5OO1XRYB4J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5OO1XRYB4J`
--

LOCK TABLES `5OO1XRYB4J` WRITE;
/*!40000 ALTER TABLE `5OO1XRYB4J` DISABLE KEYS */;
/*!40000 ALTER TABLE `5OO1XRYB4J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5PSTLMAWD6`
--

DROP TABLE IF EXISTS `5PSTLMAWD6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5PSTLMAWD6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5PSTLMAWD6`
--

LOCK TABLES `5PSTLMAWD6` WRITE;
/*!40000 ALTER TABLE `5PSTLMAWD6` DISABLE KEYS */;
/*!40000 ALTER TABLE `5PSTLMAWD6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5PYSDOK26A`
--

DROP TABLE IF EXISTS `5PYSDOK26A`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5PYSDOK26A` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5PYSDOK26A`
--

LOCK TABLES `5PYSDOK26A` WRITE;
/*!40000 ALTER TABLE `5PYSDOK26A` DISABLE KEYS */;
/*!40000 ALTER TABLE `5PYSDOK26A` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5R3TVRGURS`
--

DROP TABLE IF EXISTS `5R3TVRGURS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5R3TVRGURS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5R3TVRGURS`
--

LOCK TABLES `5R3TVRGURS` WRITE;
/*!40000 ALTER TABLE `5R3TVRGURS` DISABLE KEYS */;
/*!40000 ALTER TABLE `5R3TVRGURS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5RGKH3BPP7`
--

DROP TABLE IF EXISTS `5RGKH3BPP7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5RGKH3BPP7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5RGKH3BPP7`
--

LOCK TABLES `5RGKH3BPP7` WRITE;
/*!40000 ALTER TABLE `5RGKH3BPP7` DISABLE KEYS */;
/*!40000 ALTER TABLE `5RGKH3BPP7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5SDOU75BB9`
--

DROP TABLE IF EXISTS `5SDOU75BB9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5SDOU75BB9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5SDOU75BB9`
--

LOCK TABLES `5SDOU75BB9` WRITE;
/*!40000 ALTER TABLE `5SDOU75BB9` DISABLE KEYS */;
/*!40000 ALTER TABLE `5SDOU75BB9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5SHTJ7G3DN`
--

DROP TABLE IF EXISTS `5SHTJ7G3DN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5SHTJ7G3DN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5SHTJ7G3DN`
--

LOCK TABLES `5SHTJ7G3DN` WRITE;
/*!40000 ALTER TABLE `5SHTJ7G3DN` DISABLE KEYS */;
/*!40000 ALTER TABLE `5SHTJ7G3DN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5U01J10UFE`
--

DROP TABLE IF EXISTS `5U01J10UFE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5U01J10UFE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5U01J10UFE`
--

LOCK TABLES `5U01J10UFE` WRITE;
/*!40000 ALTER TABLE `5U01J10UFE` DISABLE KEYS */;
/*!40000 ALTER TABLE `5U01J10UFE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5VKSSFMQJ8`
--

DROP TABLE IF EXISTS `5VKSSFMQJ8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5VKSSFMQJ8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5VKSSFMQJ8`
--

LOCK TABLES `5VKSSFMQJ8` WRITE;
/*!40000 ALTER TABLE `5VKSSFMQJ8` DISABLE KEYS */;
/*!40000 ALTER TABLE `5VKSSFMQJ8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5WAIPL5FFK`
--

DROP TABLE IF EXISTS `5WAIPL5FFK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5WAIPL5FFK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5WAIPL5FFK`
--

LOCK TABLES `5WAIPL5FFK` WRITE;
/*!40000 ALTER TABLE `5WAIPL5FFK` DISABLE KEYS */;
/*!40000 ALTER TABLE `5WAIPL5FFK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5XKZUHF0JB`
--

DROP TABLE IF EXISTS `5XKZUHF0JB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5XKZUHF0JB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5XKZUHF0JB`
--

LOCK TABLES `5XKZUHF0JB` WRITE;
/*!40000 ALTER TABLE `5XKZUHF0JB` DISABLE KEYS */;
/*!40000 ALTER TABLE `5XKZUHF0JB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `5XZIPYEGB2`
--

DROP TABLE IF EXISTS `5XZIPYEGB2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `5XZIPYEGB2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `5XZIPYEGB2`
--

LOCK TABLES `5XZIPYEGB2` WRITE;
/*!40000 ALTER TABLE `5XZIPYEGB2` DISABLE KEYS */;
/*!40000 ALTER TABLE `5XZIPYEGB2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `605AUXNSGZ`
--

DROP TABLE IF EXISTS `605AUXNSGZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `605AUXNSGZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `605AUXNSGZ`
--

LOCK TABLES `605AUXNSGZ` WRITE;
/*!40000 ALTER TABLE `605AUXNSGZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `605AUXNSGZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `60JOB4J1K2`
--

DROP TABLE IF EXISTS `60JOB4J1K2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `60JOB4J1K2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `60JOB4J1K2`
--

LOCK TABLES `60JOB4J1K2` WRITE;
/*!40000 ALTER TABLE `60JOB4J1K2` DISABLE KEYS */;
/*!40000 ALTER TABLE `60JOB4J1K2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `61H98GECAP`
--

DROP TABLE IF EXISTS `61H98GECAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `61H98GECAP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `61H98GECAP`
--

LOCK TABLES `61H98GECAP` WRITE;
/*!40000 ALTER TABLE `61H98GECAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `61H98GECAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `61I21TN9R5`
--

DROP TABLE IF EXISTS `61I21TN9R5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `61I21TN9R5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `61I21TN9R5`
--

LOCK TABLES `61I21TN9R5` WRITE;
/*!40000 ALTER TABLE `61I21TN9R5` DISABLE KEYS */;
/*!40000 ALTER TABLE `61I21TN9R5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `632LVE4REB`
--

DROP TABLE IF EXISTS `632LVE4REB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `632LVE4REB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `632LVE4REB`
--

LOCK TABLES `632LVE4REB` WRITE;
/*!40000 ALTER TABLE `632LVE4REB` DISABLE KEYS */;
/*!40000 ALTER TABLE `632LVE4REB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `633N9YPCU5`
--

DROP TABLE IF EXISTS `633N9YPCU5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `633N9YPCU5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `633N9YPCU5`
--

LOCK TABLES `633N9YPCU5` WRITE;
/*!40000 ALTER TABLE `633N9YPCU5` DISABLE KEYS */;
/*!40000 ALTER TABLE `633N9YPCU5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `653IOWG6D0`
--

DROP TABLE IF EXISTS `653IOWG6D0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `653IOWG6D0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `653IOWG6D0`
--

LOCK TABLES `653IOWG6D0` WRITE;
/*!40000 ALTER TABLE `653IOWG6D0` DISABLE KEYS */;
/*!40000 ALTER TABLE `653IOWG6D0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `65A9E992AD`
--

DROP TABLE IF EXISTS `65A9E992AD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `65A9E992AD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `65A9E992AD`
--

LOCK TABLES `65A9E992AD` WRITE;
/*!40000 ALTER TABLE `65A9E992AD` DISABLE KEYS */;
/*!40000 ALTER TABLE `65A9E992AD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `66QXX5HV0F`
--

DROP TABLE IF EXISTS `66QXX5HV0F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `66QXX5HV0F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `66QXX5HV0F`
--

LOCK TABLES `66QXX5HV0F` WRITE;
/*!40000 ALTER TABLE `66QXX5HV0F` DISABLE KEYS */;
/*!40000 ALTER TABLE `66QXX5HV0F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `67LDFW5D4G`
--

DROP TABLE IF EXISTS `67LDFW5D4G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `67LDFW5D4G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `67LDFW5D4G`
--

LOCK TABLES `67LDFW5D4G` WRITE;
/*!40000 ALTER TABLE `67LDFW5D4G` DISABLE KEYS */;
/*!40000 ALTER TABLE `67LDFW5D4G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6B1NOLBO1Z`
--

DROP TABLE IF EXISTS `6B1NOLBO1Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6B1NOLBO1Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6B1NOLBO1Z`
--

LOCK TABLES `6B1NOLBO1Z` WRITE;
/*!40000 ALTER TABLE `6B1NOLBO1Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `6B1NOLBO1Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6B3Z7T7F7B`
--

DROP TABLE IF EXISTS `6B3Z7T7F7B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6B3Z7T7F7B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6B3Z7T7F7B`
--

LOCK TABLES `6B3Z7T7F7B` WRITE;
/*!40000 ALTER TABLE `6B3Z7T7F7B` DISABLE KEYS */;
/*!40000 ALTER TABLE `6B3Z7T7F7B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6BJSEG0QIZ`
--

DROP TABLE IF EXISTS `6BJSEG0QIZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6BJSEG0QIZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6BJSEG0QIZ`
--

LOCK TABLES `6BJSEG0QIZ` WRITE;
/*!40000 ALTER TABLE `6BJSEG0QIZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `6BJSEG0QIZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6E41Y2MZIJ`
--

DROP TABLE IF EXISTS `6E41Y2MZIJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6E41Y2MZIJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6E41Y2MZIJ`
--

LOCK TABLES `6E41Y2MZIJ` WRITE;
/*!40000 ALTER TABLE `6E41Y2MZIJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `6E41Y2MZIJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6EKRRQ42YR`
--

DROP TABLE IF EXISTS `6EKRRQ42YR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6EKRRQ42YR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6EKRRQ42YR`
--

LOCK TABLES `6EKRRQ42YR` WRITE;
/*!40000 ALTER TABLE `6EKRRQ42YR` DISABLE KEYS */;
/*!40000 ALTER TABLE `6EKRRQ42YR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6EZ8ZUVEZ6`
--

DROP TABLE IF EXISTS `6EZ8ZUVEZ6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6EZ8ZUVEZ6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6EZ8ZUVEZ6`
--

LOCK TABLES `6EZ8ZUVEZ6` WRITE;
/*!40000 ALTER TABLE `6EZ8ZUVEZ6` DISABLE KEYS */;
/*!40000 ALTER TABLE `6EZ8ZUVEZ6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6H0799S7O4`
--

DROP TABLE IF EXISTS `6H0799S7O4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6H0799S7O4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6H0799S7O4`
--

LOCK TABLES `6H0799S7O4` WRITE;
/*!40000 ALTER TABLE `6H0799S7O4` DISABLE KEYS */;
/*!40000 ALTER TABLE `6H0799S7O4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6I9GEODU8V`
--

DROP TABLE IF EXISTS `6I9GEODU8V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6I9GEODU8V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6I9GEODU8V`
--

LOCK TABLES `6I9GEODU8V` WRITE;
/*!40000 ALTER TABLE `6I9GEODU8V` DISABLE KEYS */;
/*!40000 ALTER TABLE `6I9GEODU8V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6JYVBLWEHA`
--

DROP TABLE IF EXISTS `6JYVBLWEHA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6JYVBLWEHA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6JYVBLWEHA`
--

LOCK TABLES `6JYVBLWEHA` WRITE;
/*!40000 ALTER TABLE `6JYVBLWEHA` DISABLE KEYS */;
/*!40000 ALTER TABLE `6JYVBLWEHA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6K3EX19PMP`
--

DROP TABLE IF EXISTS `6K3EX19PMP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6K3EX19PMP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6K3EX19PMP`
--

LOCK TABLES `6K3EX19PMP` WRITE;
/*!40000 ALTER TABLE `6K3EX19PMP` DISABLE KEYS */;
/*!40000 ALTER TABLE `6K3EX19PMP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6KWSBM6MJD`
--

DROP TABLE IF EXISTS `6KWSBM6MJD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6KWSBM6MJD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6KWSBM6MJD`
--

LOCK TABLES `6KWSBM6MJD` WRITE;
/*!40000 ALTER TABLE `6KWSBM6MJD` DISABLE KEYS */;
/*!40000 ALTER TABLE `6KWSBM6MJD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6L3Z9GXNRZ`
--

DROP TABLE IF EXISTS `6L3Z9GXNRZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6L3Z9GXNRZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6L3Z9GXNRZ`
--

LOCK TABLES `6L3Z9GXNRZ` WRITE;
/*!40000 ALTER TABLE `6L3Z9GXNRZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `6L3Z9GXNRZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6O0FQ3DKF8`
--

DROP TABLE IF EXISTS `6O0FQ3DKF8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6O0FQ3DKF8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6O0FQ3DKF8`
--

LOCK TABLES `6O0FQ3DKF8` WRITE;
/*!40000 ALTER TABLE `6O0FQ3DKF8` DISABLE KEYS */;
/*!40000 ALTER TABLE `6O0FQ3DKF8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6P22H3ZTAX`
--

DROP TABLE IF EXISTS `6P22H3ZTAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6P22H3ZTAX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6P22H3ZTAX`
--

LOCK TABLES `6P22H3ZTAX` WRITE;
/*!40000 ALTER TABLE `6P22H3ZTAX` DISABLE KEYS */;
/*!40000 ALTER TABLE `6P22H3ZTAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6RK98E1BC4`
--

DROP TABLE IF EXISTS `6RK98E1BC4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6RK98E1BC4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6RK98E1BC4`
--

LOCK TABLES `6RK98E1BC4` WRITE;
/*!40000 ALTER TABLE `6RK98E1BC4` DISABLE KEYS */;
/*!40000 ALTER TABLE `6RK98E1BC4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6SCC8LQR54`
--

DROP TABLE IF EXISTS `6SCC8LQR54`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6SCC8LQR54` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6SCC8LQR54`
--

LOCK TABLES `6SCC8LQR54` WRITE;
/*!40000 ALTER TABLE `6SCC8LQR54` DISABLE KEYS */;
/*!40000 ALTER TABLE `6SCC8LQR54` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6VUERU9IAP`
--

DROP TABLE IF EXISTS `6VUERU9IAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6VUERU9IAP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6VUERU9IAP`
--

LOCK TABLES `6VUERU9IAP` WRITE;
/*!40000 ALTER TABLE `6VUERU9IAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `6VUERU9IAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `6ZZP2C5KP3`
--

DROP TABLE IF EXISTS `6ZZP2C5KP3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `6ZZP2C5KP3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `6ZZP2C5KP3`
--

LOCK TABLES `6ZZP2C5KP3` WRITE;
/*!40000 ALTER TABLE `6ZZP2C5KP3` DISABLE KEYS */;
/*!40000 ALTER TABLE `6ZZP2C5KP3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7163GN43SD`
--

DROP TABLE IF EXISTS `7163GN43SD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7163GN43SD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7163GN43SD`
--

LOCK TABLES `7163GN43SD` WRITE;
/*!40000 ALTER TABLE `7163GN43SD` DISABLE KEYS */;
/*!40000 ALTER TABLE `7163GN43SD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `72JCQDXM8L`
--

DROP TABLE IF EXISTS `72JCQDXM8L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `72JCQDXM8L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `72JCQDXM8L`
--

LOCK TABLES `72JCQDXM8L` WRITE;
/*!40000 ALTER TABLE `72JCQDXM8L` DISABLE KEYS */;
/*!40000 ALTER TABLE `72JCQDXM8L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `72OE4TDIZ6`
--

DROP TABLE IF EXISTS `72OE4TDIZ6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `72OE4TDIZ6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `72OE4TDIZ6`
--

LOCK TABLES `72OE4TDIZ6` WRITE;
/*!40000 ALTER TABLE `72OE4TDIZ6` DISABLE KEYS */;
/*!40000 ALTER TABLE `72OE4TDIZ6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `72PZYKEPOT`
--

DROP TABLE IF EXISTS `72PZYKEPOT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `72PZYKEPOT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `72PZYKEPOT`
--

LOCK TABLES `72PZYKEPOT` WRITE;
/*!40000 ALTER TABLE `72PZYKEPOT` DISABLE KEYS */;
/*!40000 ALTER TABLE `72PZYKEPOT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `72VF8W6C75`
--

DROP TABLE IF EXISTS `72VF8W6C75`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `72VF8W6C75` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `72VF8W6C75`
--

LOCK TABLES `72VF8W6C75` WRITE;
/*!40000 ALTER TABLE `72VF8W6C75` DISABLE KEYS */;
/*!40000 ALTER TABLE `72VF8W6C75` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `741EZDK079`
--

DROP TABLE IF EXISTS `741EZDK079`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `741EZDK079` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `741EZDK079`
--

LOCK TABLES `741EZDK079` WRITE;
/*!40000 ALTER TABLE `741EZDK079` DISABLE KEYS */;
/*!40000 ALTER TABLE `741EZDK079` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `75AIDRGDZJ`
--

DROP TABLE IF EXISTS `75AIDRGDZJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `75AIDRGDZJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `75AIDRGDZJ`
--

LOCK TABLES `75AIDRGDZJ` WRITE;
/*!40000 ALTER TABLE `75AIDRGDZJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `75AIDRGDZJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `77JRX3ASW7`
--

DROP TABLE IF EXISTS `77JRX3ASW7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `77JRX3ASW7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `77JRX3ASW7`
--

LOCK TABLES `77JRX3ASW7` WRITE;
/*!40000 ALTER TABLE `77JRX3ASW7` DISABLE KEYS */;
/*!40000 ALTER TABLE `77JRX3ASW7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7CLLL2RQ8D`
--

DROP TABLE IF EXISTS `7CLLL2RQ8D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7CLLL2RQ8D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7CLLL2RQ8D`
--

LOCK TABLES `7CLLL2RQ8D` WRITE;
/*!40000 ALTER TABLE `7CLLL2RQ8D` DISABLE KEYS */;
/*!40000 ALTER TABLE `7CLLL2RQ8D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7D33SUKRN7`
--

DROP TABLE IF EXISTS `7D33SUKRN7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7D33SUKRN7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7D33SUKRN7`
--

LOCK TABLES `7D33SUKRN7` WRITE;
/*!40000 ALTER TABLE `7D33SUKRN7` DISABLE KEYS */;
/*!40000 ALTER TABLE `7D33SUKRN7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7GRQDB3CJK`
--

DROP TABLE IF EXISTS `7GRQDB3CJK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7GRQDB3CJK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7GRQDB3CJK`
--

LOCK TABLES `7GRQDB3CJK` WRITE;
/*!40000 ALTER TABLE `7GRQDB3CJK` DISABLE KEYS */;
/*!40000 ALTER TABLE `7GRQDB3CJK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7H2MO2MLNX`
--

DROP TABLE IF EXISTS `7H2MO2MLNX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7H2MO2MLNX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7H2MO2MLNX`
--

LOCK TABLES `7H2MO2MLNX` WRITE;
/*!40000 ALTER TABLE `7H2MO2MLNX` DISABLE KEYS */;
/*!40000 ALTER TABLE `7H2MO2MLNX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7IH7YWVS78`
--

DROP TABLE IF EXISTS `7IH7YWVS78`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7IH7YWVS78` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7IH7YWVS78`
--

LOCK TABLES `7IH7YWVS78` WRITE;
/*!40000 ALTER TABLE `7IH7YWVS78` DISABLE KEYS */;
/*!40000 ALTER TABLE `7IH7YWVS78` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7IT0Y45Q9N`
--

DROP TABLE IF EXISTS `7IT0Y45Q9N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7IT0Y45Q9N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7IT0Y45Q9N`
--

LOCK TABLES `7IT0Y45Q9N` WRITE;
/*!40000 ALTER TABLE `7IT0Y45Q9N` DISABLE KEYS */;
/*!40000 ALTER TABLE `7IT0Y45Q9N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7IYCPYY8SM`
--

DROP TABLE IF EXISTS `7IYCPYY8SM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7IYCPYY8SM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7IYCPYY8SM`
--

LOCK TABLES `7IYCPYY8SM` WRITE;
/*!40000 ALTER TABLE `7IYCPYY8SM` DISABLE KEYS */;
/*!40000 ALTER TABLE `7IYCPYY8SM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7KOV4MSUVJ`
--

DROP TABLE IF EXISTS `7KOV4MSUVJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7KOV4MSUVJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7KOV4MSUVJ`
--

LOCK TABLES `7KOV4MSUVJ` WRITE;
/*!40000 ALTER TABLE `7KOV4MSUVJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `7KOV4MSUVJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7MG9DTTABC`
--

DROP TABLE IF EXISTS `7MG9DTTABC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7MG9DTTABC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7MG9DTTABC`
--

LOCK TABLES `7MG9DTTABC` WRITE;
/*!40000 ALTER TABLE `7MG9DTTABC` DISABLE KEYS */;
/*!40000 ALTER TABLE `7MG9DTTABC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7MMQZQCTHR`
--

DROP TABLE IF EXISTS `7MMQZQCTHR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7MMQZQCTHR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7MMQZQCTHR`
--

LOCK TABLES `7MMQZQCTHR` WRITE;
/*!40000 ALTER TABLE `7MMQZQCTHR` DISABLE KEYS */;
/*!40000 ALTER TABLE `7MMQZQCTHR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7PRVG7ZQI3`
--

DROP TABLE IF EXISTS `7PRVG7ZQI3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7PRVG7ZQI3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7PRVG7ZQI3`
--

LOCK TABLES `7PRVG7ZQI3` WRITE;
/*!40000 ALTER TABLE `7PRVG7ZQI3` DISABLE KEYS */;
/*!40000 ALTER TABLE `7PRVG7ZQI3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7QWQNL18HU`
--

DROP TABLE IF EXISTS `7QWQNL18HU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7QWQNL18HU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7QWQNL18HU`
--

LOCK TABLES `7QWQNL18HU` WRITE;
/*!40000 ALTER TABLE `7QWQNL18HU` DISABLE KEYS */;
/*!40000 ALTER TABLE `7QWQNL18HU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7SDG9IMF5N`
--

DROP TABLE IF EXISTS `7SDG9IMF5N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7SDG9IMF5N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7SDG9IMF5N`
--

LOCK TABLES `7SDG9IMF5N` WRITE;
/*!40000 ALTER TABLE `7SDG9IMF5N` DISABLE KEYS */;
/*!40000 ALTER TABLE `7SDG9IMF5N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7SH2QFPHGN`
--

DROP TABLE IF EXISTS `7SH2QFPHGN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7SH2QFPHGN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7SH2QFPHGN`
--

LOCK TABLES `7SH2QFPHGN` WRITE;
/*!40000 ALTER TABLE `7SH2QFPHGN` DISABLE KEYS */;
/*!40000 ALTER TABLE `7SH2QFPHGN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7SUT9ZTNLU`
--

DROP TABLE IF EXISTS `7SUT9ZTNLU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7SUT9ZTNLU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7SUT9ZTNLU`
--

LOCK TABLES `7SUT9ZTNLU` WRITE;
/*!40000 ALTER TABLE `7SUT9ZTNLU` DISABLE KEYS */;
/*!40000 ALTER TABLE `7SUT9ZTNLU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7V56QKO4HP`
--

DROP TABLE IF EXISTS `7V56QKO4HP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7V56QKO4HP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7V56QKO4HP`
--

LOCK TABLES `7V56QKO4HP` WRITE;
/*!40000 ALTER TABLE `7V56QKO4HP` DISABLE KEYS */;
/*!40000 ALTER TABLE `7V56QKO4HP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7W2E6NUCHM`
--

DROP TABLE IF EXISTS `7W2E6NUCHM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7W2E6NUCHM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7W2E6NUCHM`
--

LOCK TABLES `7W2E6NUCHM` WRITE;
/*!40000 ALTER TABLE `7W2E6NUCHM` DISABLE KEYS */;
/*!40000 ALTER TABLE `7W2E6NUCHM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7X6CN6EQTP`
--

DROP TABLE IF EXISTS `7X6CN6EQTP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7X6CN6EQTP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7X6CN6EQTP`
--

LOCK TABLES `7X6CN6EQTP` WRITE;
/*!40000 ALTER TABLE `7X6CN6EQTP` DISABLE KEYS */;
/*!40000 ALTER TABLE `7X6CN6EQTP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7XNTX9EUST`
--

DROP TABLE IF EXISTS `7XNTX9EUST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7XNTX9EUST` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7XNTX9EUST`
--

LOCK TABLES `7XNTX9EUST` WRITE;
/*!40000 ALTER TABLE `7XNTX9EUST` DISABLE KEYS */;
/*!40000 ALTER TABLE `7XNTX9EUST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7Y632UQYSK`
--

DROP TABLE IF EXISTS `7Y632UQYSK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7Y632UQYSK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7Y632UQYSK`
--

LOCK TABLES `7Y632UQYSK` WRITE;
/*!40000 ALTER TABLE `7Y632UQYSK` DISABLE KEYS */;
/*!40000 ALTER TABLE `7Y632UQYSK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `7Z9C590P9I`
--

DROP TABLE IF EXISTS `7Z9C590P9I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `7Z9C590P9I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `7Z9C590P9I`
--

LOCK TABLES `7Z9C590P9I` WRITE;
/*!40000 ALTER TABLE `7Z9C590P9I` DISABLE KEYS */;
/*!40000 ALTER TABLE `7Z9C590P9I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `80D7A8MNVP`
--

DROP TABLE IF EXISTS `80D7A8MNVP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `80D7A8MNVP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `80D7A8MNVP`
--

LOCK TABLES `80D7A8MNVP` WRITE;
/*!40000 ALTER TABLE `80D7A8MNVP` DISABLE KEYS */;
/*!40000 ALTER TABLE `80D7A8MNVP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `80LIOHSGA2`
--

DROP TABLE IF EXISTS `80LIOHSGA2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `80LIOHSGA2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `80LIOHSGA2`
--

LOCK TABLES `80LIOHSGA2` WRITE;
/*!40000 ALTER TABLE `80LIOHSGA2` DISABLE KEYS */;
/*!40000 ALTER TABLE `80LIOHSGA2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `84UVTD85QV`
--

DROP TABLE IF EXISTS `84UVTD85QV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `84UVTD85QV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `84UVTD85QV`
--

LOCK TABLES `84UVTD85QV` WRITE;
/*!40000 ALTER TABLE `84UVTD85QV` DISABLE KEYS */;
/*!40000 ALTER TABLE `84UVTD85QV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `85FSG2SVTV`
--

DROP TABLE IF EXISTS `85FSG2SVTV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `85FSG2SVTV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `85FSG2SVTV`
--

LOCK TABLES `85FSG2SVTV` WRITE;
/*!40000 ALTER TABLE `85FSG2SVTV` DISABLE KEYS */;
/*!40000 ALTER TABLE `85FSG2SVTV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8685P4JUIK`
--

DROP TABLE IF EXISTS `8685P4JUIK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8685P4JUIK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8685P4JUIK`
--

LOCK TABLES `8685P4JUIK` WRITE;
/*!40000 ALTER TABLE `8685P4JUIK` DISABLE KEYS */;
/*!40000 ALTER TABLE `8685P4JUIK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `86GTJ9IP3V`
--

DROP TABLE IF EXISTS `86GTJ9IP3V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `86GTJ9IP3V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `86GTJ9IP3V`
--

LOCK TABLES `86GTJ9IP3V` WRITE;
/*!40000 ALTER TABLE `86GTJ9IP3V` DISABLE KEYS */;
/*!40000 ALTER TABLE `86GTJ9IP3V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `88G3CUUFUK`
--

DROP TABLE IF EXISTS `88G3CUUFUK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `88G3CUUFUK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `88G3CUUFUK`
--

LOCK TABLES `88G3CUUFUK` WRITE;
/*!40000 ALTER TABLE `88G3CUUFUK` DISABLE KEYS */;
/*!40000 ALTER TABLE `88G3CUUFUK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8CFJ53OAS4`
--

DROP TABLE IF EXISTS `8CFJ53OAS4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8CFJ53OAS4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8CFJ53OAS4`
--

LOCK TABLES `8CFJ53OAS4` WRITE;
/*!40000 ALTER TABLE `8CFJ53OAS4` DISABLE KEYS */;
/*!40000 ALTER TABLE `8CFJ53OAS4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8DL116J4QE`
--

DROP TABLE IF EXISTS `8DL116J4QE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8DL116J4QE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8DL116J4QE`
--

LOCK TABLES `8DL116J4QE` WRITE;
/*!40000 ALTER TABLE `8DL116J4QE` DISABLE KEYS */;
/*!40000 ALTER TABLE `8DL116J4QE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8F8FJYJQ1S`
--

DROP TABLE IF EXISTS `8F8FJYJQ1S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8F8FJYJQ1S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8F8FJYJQ1S`
--

LOCK TABLES `8F8FJYJQ1S` WRITE;
/*!40000 ALTER TABLE `8F8FJYJQ1S` DISABLE KEYS */;
/*!40000 ALTER TABLE `8F8FJYJQ1S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8J2YVN5TNW`
--

DROP TABLE IF EXISTS `8J2YVN5TNW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8J2YVN5TNW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8J2YVN5TNW`
--

LOCK TABLES `8J2YVN5TNW` WRITE;
/*!40000 ALTER TABLE `8J2YVN5TNW` DISABLE KEYS */;
/*!40000 ALTER TABLE `8J2YVN5TNW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8L2DWTV9GY`
--

DROP TABLE IF EXISTS `8L2DWTV9GY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8L2DWTV9GY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8L2DWTV9GY`
--

LOCK TABLES `8L2DWTV9GY` WRITE;
/*!40000 ALTER TABLE `8L2DWTV9GY` DISABLE KEYS */;
/*!40000 ALTER TABLE `8L2DWTV9GY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8LPPTOFECB`
--

DROP TABLE IF EXISTS `8LPPTOFECB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8LPPTOFECB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8LPPTOFECB`
--

LOCK TABLES `8LPPTOFECB` WRITE;
/*!40000 ALTER TABLE `8LPPTOFECB` DISABLE KEYS */;
/*!40000 ALTER TABLE `8LPPTOFECB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8MZSRN9C0J`
--

DROP TABLE IF EXISTS `8MZSRN9C0J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8MZSRN9C0J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8MZSRN9C0J`
--

LOCK TABLES `8MZSRN9C0J` WRITE;
/*!40000 ALTER TABLE `8MZSRN9C0J` DISABLE KEYS */;
/*!40000 ALTER TABLE `8MZSRN9C0J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8N9FKM9KCV`
--

DROP TABLE IF EXISTS `8N9FKM9KCV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8N9FKM9KCV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8N9FKM9KCV`
--

LOCK TABLES `8N9FKM9KCV` WRITE;
/*!40000 ALTER TABLE `8N9FKM9KCV` DISABLE KEYS */;
/*!40000 ALTER TABLE `8N9FKM9KCV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8NJ6ZKWX94`
--

DROP TABLE IF EXISTS `8NJ6ZKWX94`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8NJ6ZKWX94` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8NJ6ZKWX94`
--

LOCK TABLES `8NJ6ZKWX94` WRITE;
/*!40000 ALTER TABLE `8NJ6ZKWX94` DISABLE KEYS */;
/*!40000 ALTER TABLE `8NJ6ZKWX94` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8P0ML58LS9`
--

DROP TABLE IF EXISTS `8P0ML58LS9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8P0ML58LS9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8P0ML58LS9`
--

LOCK TABLES `8P0ML58LS9` WRITE;
/*!40000 ALTER TABLE `8P0ML58LS9` DISABLE KEYS */;
/*!40000 ALTER TABLE `8P0ML58LS9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8Q9VC4NN7I`
--

DROP TABLE IF EXISTS `8Q9VC4NN7I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8Q9VC4NN7I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8Q9VC4NN7I`
--

LOCK TABLES `8Q9VC4NN7I` WRITE;
/*!40000 ALTER TABLE `8Q9VC4NN7I` DISABLE KEYS */;
/*!40000 ALTER TABLE `8Q9VC4NN7I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8RI6KW8CER`
--

DROP TABLE IF EXISTS `8RI6KW8CER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8RI6KW8CER` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8RI6KW8CER`
--

LOCK TABLES `8RI6KW8CER` WRITE;
/*!40000 ALTER TABLE `8RI6KW8CER` DISABLE KEYS */;
/*!40000 ALTER TABLE `8RI6KW8CER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8SSTEUU4VW`
--

DROP TABLE IF EXISTS `8SSTEUU4VW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8SSTEUU4VW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8SSTEUU4VW`
--

LOCK TABLES `8SSTEUU4VW` WRITE;
/*!40000 ALTER TABLE `8SSTEUU4VW` DISABLE KEYS */;
/*!40000 ALTER TABLE `8SSTEUU4VW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8TCLRE39SI`
--

DROP TABLE IF EXISTS `8TCLRE39SI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8TCLRE39SI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8TCLRE39SI`
--

LOCK TABLES `8TCLRE39SI` WRITE;
/*!40000 ALTER TABLE `8TCLRE39SI` DISABLE KEYS */;
/*!40000 ALTER TABLE `8TCLRE39SI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8TJKBQQKCE`
--

DROP TABLE IF EXISTS `8TJKBQQKCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8TJKBQQKCE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8TJKBQQKCE`
--

LOCK TABLES `8TJKBQQKCE` WRITE;
/*!40000 ALTER TABLE `8TJKBQQKCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `8TJKBQQKCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8WVDP64PXE`
--

DROP TABLE IF EXISTS `8WVDP64PXE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8WVDP64PXE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8WVDP64PXE`
--

LOCK TABLES `8WVDP64PXE` WRITE;
/*!40000 ALTER TABLE `8WVDP64PXE` DISABLE KEYS */;
/*!40000 ALTER TABLE `8WVDP64PXE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8XEAUJVR2E`
--

DROP TABLE IF EXISTS `8XEAUJVR2E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8XEAUJVR2E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8XEAUJVR2E`
--

LOCK TABLES `8XEAUJVR2E` WRITE;
/*!40000 ALTER TABLE `8XEAUJVR2E` DISABLE KEYS */;
/*!40000 ALTER TABLE `8XEAUJVR2E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8XI8POGEFG`
--

DROP TABLE IF EXISTS `8XI8POGEFG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8XI8POGEFG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8XI8POGEFG`
--

LOCK TABLES `8XI8POGEFG` WRITE;
/*!40000 ALTER TABLE `8XI8POGEFG` DISABLE KEYS */;
/*!40000 ALTER TABLE `8XI8POGEFG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8XKOU8N27D`
--

DROP TABLE IF EXISTS `8XKOU8N27D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8XKOU8N27D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8XKOU8N27D`
--

LOCK TABLES `8XKOU8N27D` WRITE;
/*!40000 ALTER TABLE `8XKOU8N27D` DISABLE KEYS */;
/*!40000 ALTER TABLE `8XKOU8N27D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8XNOEFMBRM`
--

DROP TABLE IF EXISTS `8XNOEFMBRM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8XNOEFMBRM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8XNOEFMBRM`
--

LOCK TABLES `8XNOEFMBRM` WRITE;
/*!40000 ALTER TABLE `8XNOEFMBRM` DISABLE KEYS */;
/*!40000 ALTER TABLE `8XNOEFMBRM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `8YXMJEPRWA`
--

DROP TABLE IF EXISTS `8YXMJEPRWA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `8YXMJEPRWA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `8YXMJEPRWA`
--

LOCK TABLES `8YXMJEPRWA` WRITE;
/*!40000 ALTER TABLE `8YXMJEPRWA` DISABLE KEYS */;
/*!40000 ALTER TABLE `8YXMJEPRWA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `91A77FPFG1`
--

DROP TABLE IF EXISTS `91A77FPFG1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `91A77FPFG1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `91A77FPFG1`
--

LOCK TABLES `91A77FPFG1` WRITE;
/*!40000 ALTER TABLE `91A77FPFG1` DISABLE KEYS */;
/*!40000 ALTER TABLE `91A77FPFG1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `920XWPC4AI`
--

DROP TABLE IF EXISTS `920XWPC4AI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `920XWPC4AI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `920XWPC4AI`
--

LOCK TABLES `920XWPC4AI` WRITE;
/*!40000 ALTER TABLE `920XWPC4AI` DISABLE KEYS */;
/*!40000 ALTER TABLE `920XWPC4AI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `93EQRF8FAR`
--

DROP TABLE IF EXISTS `93EQRF8FAR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `93EQRF8FAR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `93EQRF8FAR`
--

LOCK TABLES `93EQRF8FAR` WRITE;
/*!40000 ALTER TABLE `93EQRF8FAR` DISABLE KEYS */;
/*!40000 ALTER TABLE `93EQRF8FAR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `94DG5440ZL`
--

DROP TABLE IF EXISTS `94DG5440ZL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `94DG5440ZL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `94DG5440ZL`
--

LOCK TABLES `94DG5440ZL` WRITE;
/*!40000 ALTER TABLE `94DG5440ZL` DISABLE KEYS */;
/*!40000 ALTER TABLE `94DG5440ZL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `97TZ3QDOR7`
--

DROP TABLE IF EXISTS `97TZ3QDOR7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `97TZ3QDOR7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `97TZ3QDOR7`
--

LOCK TABLES `97TZ3QDOR7` WRITE;
/*!40000 ALTER TABLE `97TZ3QDOR7` DISABLE KEYS */;
/*!40000 ALTER TABLE `97TZ3QDOR7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `985R8F241C`
--

DROP TABLE IF EXISTS `985R8F241C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `985R8F241C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `985R8F241C`
--

LOCK TABLES `985R8F241C` WRITE;
/*!40000 ALTER TABLE `985R8F241C` DISABLE KEYS */;
/*!40000 ALTER TABLE `985R8F241C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9ABOXD6ZYD`
--

DROP TABLE IF EXISTS `9ABOXD6ZYD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9ABOXD6ZYD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9ABOXD6ZYD`
--

LOCK TABLES `9ABOXD6ZYD` WRITE;
/*!40000 ALTER TABLE `9ABOXD6ZYD` DISABLE KEYS */;
/*!40000 ALTER TABLE `9ABOXD6ZYD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9AF4HIW9NQ`
--

DROP TABLE IF EXISTS `9AF4HIW9NQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9AF4HIW9NQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9AF4HIW9NQ`
--

LOCK TABLES `9AF4HIW9NQ` WRITE;
/*!40000 ALTER TABLE `9AF4HIW9NQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `9AF4HIW9NQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9EGGFEMKX2`
--

DROP TABLE IF EXISTS `9EGGFEMKX2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9EGGFEMKX2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9EGGFEMKX2`
--

LOCK TABLES `9EGGFEMKX2` WRITE;
/*!40000 ALTER TABLE `9EGGFEMKX2` DISABLE KEYS */;
/*!40000 ALTER TABLE `9EGGFEMKX2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9F4EUNSKK3`
--

DROP TABLE IF EXISTS `9F4EUNSKK3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9F4EUNSKK3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9F4EUNSKK3`
--

LOCK TABLES `9F4EUNSKK3` WRITE;
/*!40000 ALTER TABLE `9F4EUNSKK3` DISABLE KEYS */;
/*!40000 ALTER TABLE `9F4EUNSKK3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9JLKWLYKFA`
--

DROP TABLE IF EXISTS `9JLKWLYKFA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9JLKWLYKFA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9JLKWLYKFA`
--

LOCK TABLES `9JLKWLYKFA` WRITE;
/*!40000 ALTER TABLE `9JLKWLYKFA` DISABLE KEYS */;
/*!40000 ALTER TABLE `9JLKWLYKFA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9JU5OCWF38`
--

DROP TABLE IF EXISTS `9JU5OCWF38`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9JU5OCWF38` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9JU5OCWF38`
--

LOCK TABLES `9JU5OCWF38` WRITE;
/*!40000 ALTER TABLE `9JU5OCWF38` DISABLE KEYS */;
/*!40000 ALTER TABLE `9JU5OCWF38` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9O61YBZ1PP`
--

DROP TABLE IF EXISTS `9O61YBZ1PP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9O61YBZ1PP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9O61YBZ1PP`
--

LOCK TABLES `9O61YBZ1PP` WRITE;
/*!40000 ALTER TABLE `9O61YBZ1PP` DISABLE KEYS */;
/*!40000 ALTER TABLE `9O61YBZ1PP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9O8WBEOVQQ`
--

DROP TABLE IF EXISTS `9O8WBEOVQQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9O8WBEOVQQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9O8WBEOVQQ`
--

LOCK TABLES `9O8WBEOVQQ` WRITE;
/*!40000 ALTER TABLE `9O8WBEOVQQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `9O8WBEOVQQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9PLCKWZXR9`
--

DROP TABLE IF EXISTS `9PLCKWZXR9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9PLCKWZXR9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9PLCKWZXR9`
--

LOCK TABLES `9PLCKWZXR9` WRITE;
/*!40000 ALTER TABLE `9PLCKWZXR9` DISABLE KEYS */;
/*!40000 ALTER TABLE `9PLCKWZXR9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9QHF7CWXSP`
--

DROP TABLE IF EXISTS `9QHF7CWXSP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9QHF7CWXSP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9QHF7CWXSP`
--

LOCK TABLES `9QHF7CWXSP` WRITE;
/*!40000 ALTER TABLE `9QHF7CWXSP` DISABLE KEYS */;
/*!40000 ALTER TABLE `9QHF7CWXSP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9RWBGRQYPW`
--

DROP TABLE IF EXISTS `9RWBGRQYPW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9RWBGRQYPW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9RWBGRQYPW`
--

LOCK TABLES `9RWBGRQYPW` WRITE;
/*!40000 ALTER TABLE `9RWBGRQYPW` DISABLE KEYS */;
/*!40000 ALTER TABLE `9RWBGRQYPW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9U1FD2ODC4`
--

DROP TABLE IF EXISTS `9U1FD2ODC4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9U1FD2ODC4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9U1FD2ODC4`
--

LOCK TABLES `9U1FD2ODC4` WRITE;
/*!40000 ALTER TABLE `9U1FD2ODC4` DISABLE KEYS */;
/*!40000 ALTER TABLE `9U1FD2ODC4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9W2DIR6BQ9`
--

DROP TABLE IF EXISTS `9W2DIR6BQ9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9W2DIR6BQ9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9W2DIR6BQ9`
--

LOCK TABLES `9W2DIR6BQ9` WRITE;
/*!40000 ALTER TABLE `9W2DIR6BQ9` DISABLE KEYS */;
/*!40000 ALTER TABLE `9W2DIR6BQ9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9W8WEGBHBA`
--

DROP TABLE IF EXISTS `9W8WEGBHBA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9W8WEGBHBA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9W8WEGBHBA`
--

LOCK TABLES `9W8WEGBHBA` WRITE;
/*!40000 ALTER TABLE `9W8WEGBHBA` DISABLE KEYS */;
/*!40000 ALTER TABLE `9W8WEGBHBA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9YJHKC9M8L`
--

DROP TABLE IF EXISTS `9YJHKC9M8L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9YJHKC9M8L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9YJHKC9M8L`
--

LOCK TABLES `9YJHKC9M8L` WRITE;
/*!40000 ALTER TABLE `9YJHKC9M8L` DISABLE KEYS */;
/*!40000 ALTER TABLE `9YJHKC9M8L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `9Z6793W2OP`
--

DROP TABLE IF EXISTS `9Z6793W2OP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `9Z6793W2OP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `9Z6793W2OP`
--

LOCK TABLES `9Z6793W2OP` WRITE;
/*!40000 ALTER TABLE `9Z6793W2OP` DISABLE KEYS */;
/*!40000 ALTER TABLE `9Z6793W2OP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A150091WHL`
--

DROP TABLE IF EXISTS `A150091WHL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A150091WHL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A150091WHL`
--

LOCK TABLES `A150091WHL` WRITE;
/*!40000 ALTER TABLE `A150091WHL` DISABLE KEYS */;
/*!40000 ALTER TABLE `A150091WHL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A1E5GY4U3L`
--

DROP TABLE IF EXISTS `A1E5GY4U3L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A1E5GY4U3L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A1E5GY4U3L`
--

LOCK TABLES `A1E5GY4U3L` WRITE;
/*!40000 ALTER TABLE `A1E5GY4U3L` DISABLE KEYS */;
/*!40000 ALTER TABLE `A1E5GY4U3L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A24MN27ZGV`
--

DROP TABLE IF EXISTS `A24MN27ZGV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A24MN27ZGV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A24MN27ZGV`
--

LOCK TABLES `A24MN27ZGV` WRITE;
/*!40000 ALTER TABLE `A24MN27ZGV` DISABLE KEYS */;
/*!40000 ALTER TABLE `A24MN27ZGV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A2K38RYZSF`
--

DROP TABLE IF EXISTS `A2K38RYZSF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A2K38RYZSF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A2K38RYZSF`
--

LOCK TABLES `A2K38RYZSF` WRITE;
/*!40000 ALTER TABLE `A2K38RYZSF` DISABLE KEYS */;
/*!40000 ALTER TABLE `A2K38RYZSF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A2LAN3D3CI`
--

DROP TABLE IF EXISTS `A2LAN3D3CI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A2LAN3D3CI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A2LAN3D3CI`
--

LOCK TABLES `A2LAN3D3CI` WRITE;
/*!40000 ALTER TABLE `A2LAN3D3CI` DISABLE KEYS */;
/*!40000 ALTER TABLE `A2LAN3D3CI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A4E4RJ6FLG`
--

DROP TABLE IF EXISTS `A4E4RJ6FLG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A4E4RJ6FLG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A4E4RJ6FLG`
--

LOCK TABLES `A4E4RJ6FLG` WRITE;
/*!40000 ALTER TABLE `A4E4RJ6FLG` DISABLE KEYS */;
/*!40000 ALTER TABLE `A4E4RJ6FLG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `A52IDXG7I7`
--

DROP TABLE IF EXISTS `A52IDXG7I7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `A52IDXG7I7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `A52IDXG7I7`
--

LOCK TABLES `A52IDXG7I7` WRITE;
/*!40000 ALTER TABLE `A52IDXG7I7` DISABLE KEYS */;
/*!40000 ALTER TABLE `A52IDXG7I7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AA8PGVN9ZB`
--

DROP TABLE IF EXISTS `AA8PGVN9ZB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AA8PGVN9ZB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AA8PGVN9ZB`
--

LOCK TABLES `AA8PGVN9ZB` WRITE;
/*!40000 ALTER TABLE `AA8PGVN9ZB` DISABLE KEYS */;
/*!40000 ALTER TABLE `AA8PGVN9ZB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AAYDYTLPRP`
--

DROP TABLE IF EXISTS `AAYDYTLPRP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AAYDYTLPRP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AAYDYTLPRP`
--

LOCK TABLES `AAYDYTLPRP` WRITE;
/*!40000 ALTER TABLE `AAYDYTLPRP` DISABLE KEYS */;
/*!40000 ALTER TABLE `AAYDYTLPRP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AD1M065MW2`
--

DROP TABLE IF EXISTS `AD1M065MW2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AD1M065MW2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AD1M065MW2`
--

LOCK TABLES `AD1M065MW2` WRITE;
/*!40000 ALTER TABLE `AD1M065MW2` DISABLE KEYS */;
/*!40000 ALTER TABLE `AD1M065MW2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AF2E9AEHXC`
--

DROP TABLE IF EXISTS `AF2E9AEHXC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AF2E9AEHXC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AF2E9AEHXC`
--

LOCK TABLES `AF2E9AEHXC` WRITE;
/*!40000 ALTER TABLE `AF2E9AEHXC` DISABLE KEYS */;
/*!40000 ALTER TABLE `AF2E9AEHXC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AFGTPG0XUO`
--

DROP TABLE IF EXISTS `AFGTPG0XUO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AFGTPG0XUO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AFGTPG0XUO`
--

LOCK TABLES `AFGTPG0XUO` WRITE;
/*!40000 ALTER TABLE `AFGTPG0XUO` DISABLE KEYS */;
/*!40000 ALTER TABLE `AFGTPG0XUO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AG9DVHIB1I`
--

DROP TABLE IF EXISTS `AG9DVHIB1I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AG9DVHIB1I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AG9DVHIB1I`
--

LOCK TABLES `AG9DVHIB1I` WRITE;
/*!40000 ALTER TABLE `AG9DVHIB1I` DISABLE KEYS */;
/*!40000 ALTER TABLE `AG9DVHIB1I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AI3GQDR6KX`
--

DROP TABLE IF EXISTS `AI3GQDR6KX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AI3GQDR6KX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AI3GQDR6KX`
--

LOCK TABLES `AI3GQDR6KX` WRITE;
/*!40000 ALTER TABLE `AI3GQDR6KX` DISABLE KEYS */;
/*!40000 ALTER TABLE `AI3GQDR6KX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AJ5UBRBCDG`
--

DROP TABLE IF EXISTS `AJ5UBRBCDG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AJ5UBRBCDG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AJ5UBRBCDG`
--

LOCK TABLES `AJ5UBRBCDG` WRITE;
/*!40000 ALTER TABLE `AJ5UBRBCDG` DISABLE KEYS */;
/*!40000 ALTER TABLE `AJ5UBRBCDG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ALNL9JTLTJ`
--

DROP TABLE IF EXISTS `ALNL9JTLTJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ALNL9JTLTJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ALNL9JTLTJ`
--

LOCK TABLES `ALNL9JTLTJ` WRITE;
/*!40000 ALTER TABLE `ALNL9JTLTJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `ALNL9JTLTJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AN2OZW8YXY`
--

DROP TABLE IF EXISTS `AN2OZW8YXY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AN2OZW8YXY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AN2OZW8YXY`
--

LOCK TABLES `AN2OZW8YXY` WRITE;
/*!40000 ALTER TABLE `AN2OZW8YXY` DISABLE KEYS */;
/*!40000 ALTER TABLE `AN2OZW8YXY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ANC394AT7M`
--

DROP TABLE IF EXISTS `ANC394AT7M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ANC394AT7M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ANC394AT7M`
--

LOCK TABLES `ANC394AT7M` WRITE;
/*!40000 ALTER TABLE `ANC394AT7M` DISABLE KEYS */;
/*!40000 ALTER TABLE `ANC394AT7M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AODETH1VI7`
--

DROP TABLE IF EXISTS `AODETH1VI7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AODETH1VI7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AODETH1VI7`
--

LOCK TABLES `AODETH1VI7` WRITE;
/*!40000 ALTER TABLE `AODETH1VI7` DISABLE KEYS */;
/*!40000 ALTER TABLE `AODETH1VI7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AOLTWDMPZM`
--

DROP TABLE IF EXISTS `AOLTWDMPZM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AOLTWDMPZM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AOLTWDMPZM`
--

LOCK TABLES `AOLTWDMPZM` WRITE;
/*!40000 ALTER TABLE `AOLTWDMPZM` DISABLE KEYS */;
/*!40000 ALTER TABLE `AOLTWDMPZM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AOQU5FYW01`
--

DROP TABLE IF EXISTS `AOQU5FYW01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AOQU5FYW01` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AOQU5FYW01`
--

LOCK TABLES `AOQU5FYW01` WRITE;
/*!40000 ALTER TABLE `AOQU5FYW01` DISABLE KEYS */;
/*!40000 ALTER TABLE `AOQU5FYW01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AQ91KF6HWY`
--

DROP TABLE IF EXISTS `AQ91KF6HWY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AQ91KF6HWY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AQ91KF6HWY`
--

LOCK TABLES `AQ91KF6HWY` WRITE;
/*!40000 ALTER TABLE `AQ91KF6HWY` DISABLE KEYS */;
/*!40000 ALTER TABLE `AQ91KF6HWY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ASX1Z793K3`
--

DROP TABLE IF EXISTS `ASX1Z793K3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ASX1Z793K3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ASX1Z793K3`
--

LOCK TABLES `ASX1Z793K3` WRITE;
/*!40000 ALTER TABLE `ASX1Z793K3` DISABLE KEYS */;
/*!40000 ALTER TABLE `ASX1Z793K3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AT5BJCZ3IN`
--

DROP TABLE IF EXISTS `AT5BJCZ3IN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AT5BJCZ3IN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AT5BJCZ3IN`
--

LOCK TABLES `AT5BJCZ3IN` WRITE;
/*!40000 ALTER TABLE `AT5BJCZ3IN` DISABLE KEYS */;
/*!40000 ALTER TABLE `AT5BJCZ3IN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AU4FJAKUEI`
--

DROP TABLE IF EXISTS `AU4FJAKUEI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AU4FJAKUEI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AU4FJAKUEI`
--

LOCK TABLES `AU4FJAKUEI` WRITE;
/*!40000 ALTER TABLE `AU4FJAKUEI` DISABLE KEYS */;
/*!40000 ALTER TABLE `AU4FJAKUEI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AU6EHDDAAD`
--

DROP TABLE IF EXISTS `AU6EHDDAAD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AU6EHDDAAD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AU6EHDDAAD`
--

LOCK TABLES `AU6EHDDAAD` WRITE;
/*!40000 ALTER TABLE `AU6EHDDAAD` DISABLE KEYS */;
/*!40000 ALTER TABLE `AU6EHDDAAD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUWQEKNEQ1`
--

DROP TABLE IF EXISTS `AUWQEKNEQ1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUWQEKNEQ1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUWQEKNEQ1`
--

LOCK TABLES `AUWQEKNEQ1` WRITE;
/*!40000 ALTER TABLE `AUWQEKNEQ1` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUWQEKNEQ1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AX4V512GOF`
--

DROP TABLE IF EXISTS `AX4V512GOF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AX4V512GOF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AX4V512GOF`
--

LOCK TABLES `AX4V512GOF` WRITE;
/*!40000 ALTER TABLE `AX4V512GOF` DISABLE KEYS */;
/*!40000 ALTER TABLE `AX4V512GOF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AYT33LY7CP`
--

DROP TABLE IF EXISTS `AYT33LY7CP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AYT33LY7CP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AYT33LY7CP`
--

LOCK TABLES `AYT33LY7CP` WRITE;
/*!40000 ALTER TABLE `AYT33LY7CP` DISABLE KEYS */;
/*!40000 ALTER TABLE `AYT33LY7CP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B0B46XEZ9U`
--

DROP TABLE IF EXISTS `B0B46XEZ9U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B0B46XEZ9U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B0B46XEZ9U`
--

LOCK TABLES `B0B46XEZ9U` WRITE;
/*!40000 ALTER TABLE `B0B46XEZ9U` DISABLE KEYS */;
/*!40000 ALTER TABLE `B0B46XEZ9U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B0HV7O4G39`
--

DROP TABLE IF EXISTS `B0HV7O4G39`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B0HV7O4G39` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B0HV7O4G39`
--

LOCK TABLES `B0HV7O4G39` WRITE;
/*!40000 ALTER TABLE `B0HV7O4G39` DISABLE KEYS */;
/*!40000 ALTER TABLE `B0HV7O4G39` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B3JPEJ7VX3`
--

DROP TABLE IF EXISTS `B3JPEJ7VX3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B3JPEJ7VX3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B3JPEJ7VX3`
--

LOCK TABLES `B3JPEJ7VX3` WRITE;
/*!40000 ALTER TABLE `B3JPEJ7VX3` DISABLE KEYS */;
/*!40000 ALTER TABLE `B3JPEJ7VX3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B6658Z296T`
--

DROP TABLE IF EXISTS `B6658Z296T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B6658Z296T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B6658Z296T`
--

LOCK TABLES `B6658Z296T` WRITE;
/*!40000 ALTER TABLE `B6658Z296T` DISABLE KEYS */;
/*!40000 ALTER TABLE `B6658Z296T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B697H5DQK2`
--

DROP TABLE IF EXISTS `B697H5DQK2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B697H5DQK2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B697H5DQK2`
--

LOCK TABLES `B697H5DQK2` WRITE;
/*!40000 ALTER TABLE `B697H5DQK2` DISABLE KEYS */;
/*!40000 ALTER TABLE `B697H5DQK2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B6JM4F3OL3`
--

DROP TABLE IF EXISTS `B6JM4F3OL3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B6JM4F3OL3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B6JM4F3OL3`
--

LOCK TABLES `B6JM4F3OL3` WRITE;
/*!40000 ALTER TABLE `B6JM4F3OL3` DISABLE KEYS */;
/*!40000 ALTER TABLE `B6JM4F3OL3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B6RS0OB1WD`
--

DROP TABLE IF EXISTS `B6RS0OB1WD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B6RS0OB1WD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B6RS0OB1WD`
--

LOCK TABLES `B6RS0OB1WD` WRITE;
/*!40000 ALTER TABLE `B6RS0OB1WD` DISABLE KEYS */;
/*!40000 ALTER TABLE `B6RS0OB1WD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B7YJ9GJY18`
--

DROP TABLE IF EXISTS `B7YJ9GJY18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B7YJ9GJY18` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B7YJ9GJY18`
--

LOCK TABLES `B7YJ9GJY18` WRITE;
/*!40000 ALTER TABLE `B7YJ9GJY18` DISABLE KEYS */;
/*!40000 ALTER TABLE `B7YJ9GJY18` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B9J21AAF72`
--

DROP TABLE IF EXISTS `B9J21AAF72`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B9J21AAF72` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B9J21AAF72`
--

LOCK TABLES `B9J21AAF72` WRITE;
/*!40000 ALTER TABLE `B9J21AAF72` DISABLE KEYS */;
/*!40000 ALTER TABLE `B9J21AAF72` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `B9VWF9K1V9`
--

DROP TABLE IF EXISTS `B9VWF9K1V9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `B9VWF9K1V9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `B9VWF9K1V9`
--

LOCK TABLES `B9VWF9K1V9` WRITE;
/*!40000 ALTER TABLE `B9VWF9K1V9` DISABLE KEYS */;
/*!40000 ALTER TABLE `B9VWF9K1V9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BA4J4KSHTV`
--

DROP TABLE IF EXISTS `BA4J4KSHTV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BA4J4KSHTV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BA4J4KSHTV`
--

LOCK TABLES `BA4J4KSHTV` WRITE;
/*!40000 ALTER TABLE `BA4J4KSHTV` DISABLE KEYS */;
/*!40000 ALTER TABLE `BA4J4KSHTV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BHFDJ2GGB5`
--

DROP TABLE IF EXISTS `BHFDJ2GGB5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BHFDJ2GGB5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BHFDJ2GGB5`
--

LOCK TABLES `BHFDJ2GGB5` WRITE;
/*!40000 ALTER TABLE `BHFDJ2GGB5` DISABLE KEYS */;
/*!40000 ALTER TABLE `BHFDJ2GGB5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BISZW4F2XT`
--

DROP TABLE IF EXISTS `BISZW4F2XT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BISZW4F2XT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BISZW4F2XT`
--

LOCK TABLES `BISZW4F2XT` WRITE;
/*!40000 ALTER TABLE `BISZW4F2XT` DISABLE KEYS */;
/*!40000 ALTER TABLE `BISZW4F2XT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BJ62VFLDCQ`
--

DROP TABLE IF EXISTS `BJ62VFLDCQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BJ62VFLDCQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BJ62VFLDCQ`
--

LOCK TABLES `BJ62VFLDCQ` WRITE;
/*!40000 ALTER TABLE `BJ62VFLDCQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `BJ62VFLDCQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BK3G0S11TR`
--

DROP TABLE IF EXISTS `BK3G0S11TR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BK3G0S11TR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BK3G0S11TR`
--

LOCK TABLES `BK3G0S11TR` WRITE;
/*!40000 ALTER TABLE `BK3G0S11TR` DISABLE KEYS */;
/*!40000 ALTER TABLE `BK3G0S11TR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BLJ50U2RO7`
--

DROP TABLE IF EXISTS `BLJ50U2RO7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BLJ50U2RO7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BLJ50U2RO7`
--

LOCK TABLES `BLJ50U2RO7` WRITE;
/*!40000 ALTER TABLE `BLJ50U2RO7` DISABLE KEYS */;
/*!40000 ALTER TABLE `BLJ50U2RO7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BLPFPJ136J`
--

DROP TABLE IF EXISTS `BLPFPJ136J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BLPFPJ136J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BLPFPJ136J`
--

LOCK TABLES `BLPFPJ136J` WRITE;
/*!40000 ALTER TABLE `BLPFPJ136J` DISABLE KEYS */;
/*!40000 ALTER TABLE `BLPFPJ136J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BM6BTUAL8E`
--

DROP TABLE IF EXISTS `BM6BTUAL8E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BM6BTUAL8E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BM6BTUAL8E`
--

LOCK TABLES `BM6BTUAL8E` WRITE;
/*!40000 ALTER TABLE `BM6BTUAL8E` DISABLE KEYS */;
/*!40000 ALTER TABLE `BM6BTUAL8E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BPVGFD861J`
--

DROP TABLE IF EXISTS `BPVGFD861J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BPVGFD861J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BPVGFD861J`
--

LOCK TABLES `BPVGFD861J` WRITE;
/*!40000 ALTER TABLE `BPVGFD861J` DISABLE KEYS */;
/*!40000 ALTER TABLE `BPVGFD861J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BPW9XMQHNU`
--

DROP TABLE IF EXISTS `BPW9XMQHNU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BPW9XMQHNU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BPW9XMQHNU`
--

LOCK TABLES `BPW9XMQHNU` WRITE;
/*!40000 ALTER TABLE `BPW9XMQHNU` DISABLE KEYS */;
/*!40000 ALTER TABLE `BPW9XMQHNU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BSP41BX8D9`
--

DROP TABLE IF EXISTS `BSP41BX8D9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BSP41BX8D9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BSP41BX8D9`
--

LOCK TABLES `BSP41BX8D9` WRITE;
/*!40000 ALTER TABLE `BSP41BX8D9` DISABLE KEYS */;
/*!40000 ALTER TABLE `BSP41BX8D9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BU84ZXVV9N`
--

DROP TABLE IF EXISTS `BU84ZXVV9N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BU84ZXVV9N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BU84ZXVV9N`
--

LOCK TABLES `BU84ZXVV9N` WRITE;
/*!40000 ALTER TABLE `BU84ZXVV9N` DISABLE KEYS */;
/*!40000 ALTER TABLE `BU84ZXVV9N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BUX3OT3OW7`
--

DROP TABLE IF EXISTS `BUX3OT3OW7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BUX3OT3OW7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BUX3OT3OW7`
--

LOCK TABLES `BUX3OT3OW7` WRITE;
/*!40000 ALTER TABLE `BUX3OT3OW7` DISABLE KEYS */;
/*!40000 ALTER TABLE `BUX3OT3OW7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BVIMXW7N5W`
--

DROP TABLE IF EXISTS `BVIMXW7N5W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BVIMXW7N5W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BVIMXW7N5W`
--

LOCK TABLES `BVIMXW7N5W` WRITE;
/*!40000 ALTER TABLE `BVIMXW7N5W` DISABLE KEYS */;
/*!40000 ALTER TABLE `BVIMXW7N5W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BYOR5KF7XN`
--

DROP TABLE IF EXISTS `BYOR5KF7XN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BYOR5KF7XN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BYOR5KF7XN`
--

LOCK TABLES `BYOR5KF7XN` WRITE;
/*!40000 ALTER TABLE `BYOR5KF7XN` DISABLE KEYS */;
/*!40000 ALTER TABLE `BYOR5KF7XN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BZ3B774EDZ`
--

DROP TABLE IF EXISTS `BZ3B774EDZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BZ3B774EDZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BZ3B774EDZ`
--

LOCK TABLES `BZ3B774EDZ` WRITE;
/*!40000 ALTER TABLE `BZ3B774EDZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `BZ3B774EDZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `C14BUN68ID`
--

DROP TABLE IF EXISTS `C14BUN68ID`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `C14BUN68ID` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `C14BUN68ID`
--

LOCK TABLES `C14BUN68ID` WRITE;
/*!40000 ALTER TABLE `C14BUN68ID` DISABLE KEYS */;
/*!40000 ALTER TABLE `C14BUN68ID` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `C1TYN7WLC3`
--

DROP TABLE IF EXISTS `C1TYN7WLC3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `C1TYN7WLC3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `C1TYN7WLC3`
--

LOCK TABLES `C1TYN7WLC3` WRITE;
/*!40000 ALTER TABLE `C1TYN7WLC3` DISABLE KEYS */;
/*!40000 ALTER TABLE `C1TYN7WLC3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `C4RX1VOEMT`
--

DROP TABLE IF EXISTS `C4RX1VOEMT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `C4RX1VOEMT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `C4RX1VOEMT`
--

LOCK TABLES `C4RX1VOEMT` WRITE;
/*!40000 ALTER TABLE `C4RX1VOEMT` DISABLE KEYS */;
/*!40000 ALTER TABLE `C4RX1VOEMT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `C76WOUJKGR`
--

DROP TABLE IF EXISTS `C76WOUJKGR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `C76WOUJKGR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `C76WOUJKGR`
--

LOCK TABLES `C76WOUJKGR` WRITE;
/*!40000 ALTER TABLE `C76WOUJKGR` DISABLE KEYS */;
/*!40000 ALTER TABLE `C76WOUJKGR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CB7L7JALQD`
--

DROP TABLE IF EXISTS `CB7L7JALQD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CB7L7JALQD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CB7L7JALQD`
--

LOCK TABLES `CB7L7JALQD` WRITE;
/*!40000 ALTER TABLE `CB7L7JALQD` DISABLE KEYS */;
/*!40000 ALTER TABLE `CB7L7JALQD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CBGTYMGTAS`
--

DROP TABLE IF EXISTS `CBGTYMGTAS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CBGTYMGTAS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CBGTYMGTAS`
--

LOCK TABLES `CBGTYMGTAS` WRITE;
/*!40000 ALTER TABLE `CBGTYMGTAS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CBGTYMGTAS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CCDJ1KIGRI`
--

DROP TABLE IF EXISTS `CCDJ1KIGRI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CCDJ1KIGRI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CCDJ1KIGRI`
--

LOCK TABLES `CCDJ1KIGRI` WRITE;
/*!40000 ALTER TABLE `CCDJ1KIGRI` DISABLE KEYS */;
/*!40000 ALTER TABLE `CCDJ1KIGRI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CF37E3RHSZ`
--

DROP TABLE IF EXISTS `CF37E3RHSZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CF37E3RHSZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CF37E3RHSZ`
--

LOCK TABLES `CF37E3RHSZ` WRITE;
/*!40000 ALTER TABLE `CF37E3RHSZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `CF37E3RHSZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CGE9ERXU2Y`
--

DROP TABLE IF EXISTS `CGE9ERXU2Y`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CGE9ERXU2Y` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CGE9ERXU2Y`
--

LOCK TABLES `CGE9ERXU2Y` WRITE;
/*!40000 ALTER TABLE `CGE9ERXU2Y` DISABLE KEYS */;
/*!40000 ALTER TABLE `CGE9ERXU2Y` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CK3RF3HUGW`
--

DROP TABLE IF EXISTS `CK3RF3HUGW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CK3RF3HUGW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CK3RF3HUGW`
--

LOCK TABLES `CK3RF3HUGW` WRITE;
/*!40000 ALTER TABLE `CK3RF3HUGW` DISABLE KEYS */;
/*!40000 ALTER TABLE `CK3RF3HUGW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CK7U7I11JG`
--

DROP TABLE IF EXISTS `CK7U7I11JG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CK7U7I11JG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CK7U7I11JG`
--

LOCK TABLES `CK7U7I11JG` WRITE;
/*!40000 ALTER TABLE `CK7U7I11JG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CK7U7I11JG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CME110BO0C`
--

DROP TABLE IF EXISTS `CME110BO0C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CME110BO0C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CME110BO0C`
--

LOCK TABLES `CME110BO0C` WRITE;
/*!40000 ALTER TABLE `CME110BO0C` DISABLE KEYS */;
/*!40000 ALTER TABLE `CME110BO0C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO7GB76S45`
--

DROP TABLE IF EXISTS `CO7GB76S45`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO7GB76S45` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO7GB76S45`
--

LOCK TABLES `CO7GB76S45` WRITE;
/*!40000 ALTER TABLE `CO7GB76S45` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO7GB76S45` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COSETY62J4`
--

DROP TABLE IF EXISTS `COSETY62J4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COSETY62J4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COSETY62J4`
--

LOCK TABLES `COSETY62J4` WRITE;
/*!40000 ALTER TABLE `COSETY62J4` DISABLE KEYS */;
/*!40000 ALTER TABLE `COSETY62J4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CPTJBOQV2X`
--

DROP TABLE IF EXISTS `CPTJBOQV2X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CPTJBOQV2X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CPTJBOQV2X`
--

LOCK TABLES `CPTJBOQV2X` WRITE;
/*!40000 ALTER TABLE `CPTJBOQV2X` DISABLE KEYS */;
/*!40000 ALTER TABLE `CPTJBOQV2X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CQCQD5KFVV`
--

DROP TABLE IF EXISTS `CQCQD5KFVV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CQCQD5KFVV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CQCQD5KFVV`
--

LOCK TABLES `CQCQD5KFVV` WRITE;
/*!40000 ALTER TABLE `CQCQD5KFVV` DISABLE KEYS */;
/*!40000 ALTER TABLE `CQCQD5KFVV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CR63AV4LZR`
--

DROP TABLE IF EXISTS `CR63AV4LZR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CR63AV4LZR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CR63AV4LZR`
--

LOCK TABLES `CR63AV4LZR` WRITE;
/*!40000 ALTER TABLE `CR63AV4LZR` DISABLE KEYS */;
/*!40000 ALTER TABLE `CR63AV4LZR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CTW8MM69SG`
--

DROP TABLE IF EXISTS `CTW8MM69SG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CTW8MM69SG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CTW8MM69SG`
--

LOCK TABLES `CTW8MM69SG` WRITE;
/*!40000 ALTER TABLE `CTW8MM69SG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CTW8MM69SG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUQ44B9VRW`
--

DROP TABLE IF EXISTS `CUQ44B9VRW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CUQ44B9VRW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUQ44B9VRW`
--

LOCK TABLES `CUQ44B9VRW` WRITE;
/*!40000 ALTER TABLE `CUQ44B9VRW` DISABLE KEYS */;
/*!40000 ALTER TABLE `CUQ44B9VRW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CVO5D3SVKV`
--

DROP TABLE IF EXISTS `CVO5D3SVKV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CVO5D3SVKV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CVO5D3SVKV`
--

LOCK TABLES `CVO5D3SVKV` WRITE;
/*!40000 ALTER TABLE `CVO5D3SVKV` DISABLE KEYS */;
/*!40000 ALTER TABLE `CVO5D3SVKV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CWS55XFFDY`
--

DROP TABLE IF EXISTS `CWS55XFFDY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CWS55XFFDY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CWS55XFFDY`
--

LOCK TABLES `CWS55XFFDY` WRITE;
/*!40000 ALTER TABLE `CWS55XFFDY` DISABLE KEYS */;
/*!40000 ALTER TABLE `CWS55XFFDY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CY54DW9RPG`
--

DROP TABLE IF EXISTS `CY54DW9RPG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CY54DW9RPG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CY54DW9RPG`
--

LOCK TABLES `CY54DW9RPG` WRITE;
/*!40000 ALTER TABLE `CY54DW9RPG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CY54DW9RPG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CZGP7A2IHS`
--

DROP TABLE IF EXISTS `CZGP7A2IHS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CZGP7A2IHS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CZGP7A2IHS`
--

LOCK TABLES `CZGP7A2IHS` WRITE;
/*!40000 ALTER TABLE `CZGP7A2IHS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CZGP7A2IHS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D39N6XUMRB`
--

DROP TABLE IF EXISTS `D39N6XUMRB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D39N6XUMRB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D39N6XUMRB`
--

LOCK TABLES `D39N6XUMRB` WRITE;
/*!40000 ALTER TABLE `D39N6XUMRB` DISABLE KEYS */;
/*!40000 ALTER TABLE `D39N6XUMRB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D4C64HJTQ4`
--

DROP TABLE IF EXISTS `D4C64HJTQ4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D4C64HJTQ4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D4C64HJTQ4`
--

LOCK TABLES `D4C64HJTQ4` WRITE;
/*!40000 ALTER TABLE `D4C64HJTQ4` DISABLE KEYS */;
/*!40000 ALTER TABLE `D4C64HJTQ4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D4CZ3NFM62`
--

DROP TABLE IF EXISTS `D4CZ3NFM62`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D4CZ3NFM62` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D4CZ3NFM62`
--

LOCK TABLES `D4CZ3NFM62` WRITE;
/*!40000 ALTER TABLE `D4CZ3NFM62` DISABLE KEYS */;
/*!40000 ALTER TABLE `D4CZ3NFM62` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D4TJK4APMH`
--

DROP TABLE IF EXISTS `D4TJK4APMH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D4TJK4APMH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D4TJK4APMH`
--

LOCK TABLES `D4TJK4APMH` WRITE;
/*!40000 ALTER TABLE `D4TJK4APMH` DISABLE KEYS */;
/*!40000 ALTER TABLE `D4TJK4APMH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D626OPK4BP`
--

DROP TABLE IF EXISTS `D626OPK4BP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D626OPK4BP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D626OPK4BP`
--

LOCK TABLES `D626OPK4BP` WRITE;
/*!40000 ALTER TABLE `D626OPK4BP` DISABLE KEYS */;
/*!40000 ALTER TABLE `D626OPK4BP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D6Z6M5FAAM`
--

DROP TABLE IF EXISTS `D6Z6M5FAAM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `D6Z6M5FAAM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D6Z6M5FAAM`
--

LOCK TABLES `D6Z6M5FAAM` WRITE;
/*!40000 ALTER TABLE `D6Z6M5FAAM` DISABLE KEYS */;
/*!40000 ALTER TABLE `D6Z6M5FAAM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DBJ4S43IRD`
--

DROP TABLE IF EXISTS `DBJ4S43IRD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DBJ4S43IRD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DBJ4S43IRD`
--

LOCK TABLES `DBJ4S43IRD` WRITE;
/*!40000 ALTER TABLE `DBJ4S43IRD` DISABLE KEYS */;
/*!40000 ALTER TABLE `DBJ4S43IRD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DCDPD2NR4F`
--

DROP TABLE IF EXISTS `DCDPD2NR4F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DCDPD2NR4F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DCDPD2NR4F`
--

LOCK TABLES `DCDPD2NR4F` WRITE;
/*!40000 ALTER TABLE `DCDPD2NR4F` DISABLE KEYS */;
/*!40000 ALTER TABLE `DCDPD2NR4F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DD0CB9PDHB`
--

DROP TABLE IF EXISTS `DD0CB9PDHB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DD0CB9PDHB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DD0CB9PDHB`
--

LOCK TABLES `DD0CB9PDHB` WRITE;
/*!40000 ALTER TABLE `DD0CB9PDHB` DISABLE KEYS */;
/*!40000 ALTER TABLE `DD0CB9PDHB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEI2P6QDJJ`
--

DROP TABLE IF EXISTS `DEI2P6QDJJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DEI2P6QDJJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEI2P6QDJJ`
--

LOCK TABLES `DEI2P6QDJJ` WRITE;
/*!40000 ALTER TABLE `DEI2P6QDJJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `DEI2P6QDJJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DF9Y4Y2SVV`
--

DROP TABLE IF EXISTS `DF9Y4Y2SVV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DF9Y4Y2SVV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DF9Y4Y2SVV`
--

LOCK TABLES `DF9Y4Y2SVV` WRITE;
/*!40000 ALTER TABLE `DF9Y4Y2SVV` DISABLE KEYS */;
/*!40000 ALTER TABLE `DF9Y4Y2SVV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DFGPKMKHKT`
--

DROP TABLE IF EXISTS `DFGPKMKHKT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DFGPKMKHKT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DFGPKMKHKT`
--

LOCK TABLES `DFGPKMKHKT` WRITE;
/*!40000 ALTER TABLE `DFGPKMKHKT` DISABLE KEYS */;
/*!40000 ALTER TABLE `DFGPKMKHKT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DJ9Y3YPEHQ`
--

DROP TABLE IF EXISTS `DJ9Y3YPEHQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DJ9Y3YPEHQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DJ9Y3YPEHQ`
--

LOCK TABLES `DJ9Y3YPEHQ` WRITE;
/*!40000 ALTER TABLE `DJ9Y3YPEHQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `DJ9Y3YPEHQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DL8Y27CCPW`
--

DROP TABLE IF EXISTS `DL8Y27CCPW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DL8Y27CCPW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DL8Y27CCPW`
--

LOCK TABLES `DL8Y27CCPW` WRITE;
/*!40000 ALTER TABLE `DL8Y27CCPW` DISABLE KEYS */;
/*!40000 ALTER TABLE `DL8Y27CCPW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DNCP61KMRM`
--

DROP TABLE IF EXISTS `DNCP61KMRM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DNCP61KMRM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DNCP61KMRM`
--

LOCK TABLES `DNCP61KMRM` WRITE;
/*!40000 ALTER TABLE `DNCP61KMRM` DISABLE KEYS */;
/*!40000 ALTER TABLE `DNCP61KMRM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DO9B86PZJQ`
--

DROP TABLE IF EXISTS `DO9B86PZJQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DO9B86PZJQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DO9B86PZJQ`
--

LOCK TABLES `DO9B86PZJQ` WRITE;
/*!40000 ALTER TABLE `DO9B86PZJQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `DO9B86PZJQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DR67D36RYX`
--

DROP TABLE IF EXISTS `DR67D36RYX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DR67D36RYX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DR67D36RYX`
--

LOCK TABLES `DR67D36RYX` WRITE;
/*!40000 ALTER TABLE `DR67D36RYX` DISABLE KEYS */;
/*!40000 ALTER TABLE `DR67D36RYX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DRQAF12J7I`
--

DROP TABLE IF EXISTS `DRQAF12J7I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DRQAF12J7I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DRQAF12J7I`
--

LOCK TABLES `DRQAF12J7I` WRITE;
/*!40000 ALTER TABLE `DRQAF12J7I` DISABLE KEYS */;
/*!40000 ALTER TABLE `DRQAF12J7I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DRZXVY44DT`
--

DROP TABLE IF EXISTS `DRZXVY44DT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DRZXVY44DT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DRZXVY44DT`
--

LOCK TABLES `DRZXVY44DT` WRITE;
/*!40000 ALTER TABLE `DRZXVY44DT` DISABLE KEYS */;
/*!40000 ALTER TABLE `DRZXVY44DT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DT3NDQG32U`
--

DROP TABLE IF EXISTS `DT3NDQG32U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DT3NDQG32U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DT3NDQG32U`
--

LOCK TABLES `DT3NDQG32U` WRITE;
/*!40000 ALTER TABLE `DT3NDQG32U` DISABLE KEYS */;
/*!40000 ALTER TABLE `DT3NDQG32U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DUPBCG7CMN`
--

DROP TABLE IF EXISTS `DUPBCG7CMN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DUPBCG7CMN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DUPBCG7CMN`
--

LOCK TABLES `DUPBCG7CMN` WRITE;
/*!40000 ALTER TABLE `DUPBCG7CMN` DISABLE KEYS */;
/*!40000 ALTER TABLE `DUPBCG7CMN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DUTU472BGF`
--

DROP TABLE IF EXISTS `DUTU472BGF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DUTU472BGF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DUTU472BGF`
--

LOCK TABLES `DUTU472BGF` WRITE;
/*!40000 ALTER TABLE `DUTU472BGF` DISABLE KEYS */;
/*!40000 ALTER TABLE `DUTU472BGF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DVBO54B9HA`
--

DROP TABLE IF EXISTS `DVBO54B9HA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DVBO54B9HA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DVBO54B9HA`
--

LOCK TABLES `DVBO54B9HA` WRITE;
/*!40000 ALTER TABLE `DVBO54B9HA` DISABLE KEYS */;
/*!40000 ALTER TABLE `DVBO54B9HA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DVHG6EYDS0`
--

DROP TABLE IF EXISTS `DVHG6EYDS0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DVHG6EYDS0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DVHG6EYDS0`
--

LOCK TABLES `DVHG6EYDS0` WRITE;
/*!40000 ALTER TABLE `DVHG6EYDS0` DISABLE KEYS */;
/*!40000 ALTER TABLE `DVHG6EYDS0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DVV0J211RN`
--

DROP TABLE IF EXISTS `DVV0J211RN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DVV0J211RN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DVV0J211RN`
--

LOCK TABLES `DVV0J211RN` WRITE;
/*!40000 ALTER TABLE `DVV0J211RN` DISABLE KEYS */;
/*!40000 ALTER TABLE `DVV0J211RN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DW4S2Z53DG`
--

DROP TABLE IF EXISTS `DW4S2Z53DG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DW4S2Z53DG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DW4S2Z53DG`
--

LOCK TABLES `DW4S2Z53DG` WRITE;
/*!40000 ALTER TABLE `DW4S2Z53DG` DISABLE KEYS */;
/*!40000 ALTER TABLE `DW4S2Z53DG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DW6Z047PBH`
--

DROP TABLE IF EXISTS `DW6Z047PBH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DW6Z047PBH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DW6Z047PBH`
--

LOCK TABLES `DW6Z047PBH` WRITE;
/*!40000 ALTER TABLE `DW6Z047PBH` DISABLE KEYS */;
/*!40000 ALTER TABLE `DW6Z047PBH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DWBURTOL6X`
--

DROP TABLE IF EXISTS `DWBURTOL6X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DWBURTOL6X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DWBURTOL6X`
--

LOCK TABLES `DWBURTOL6X` WRITE;
/*!40000 ALTER TABLE `DWBURTOL6X` DISABLE KEYS */;
/*!40000 ALTER TABLE `DWBURTOL6X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DWOJQ7GHYL`
--

DROP TABLE IF EXISTS `DWOJQ7GHYL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DWOJQ7GHYL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DWOJQ7GHYL`
--

LOCK TABLES `DWOJQ7GHYL` WRITE;
/*!40000 ALTER TABLE `DWOJQ7GHYL` DISABLE KEYS */;
/*!40000 ALTER TABLE `DWOJQ7GHYL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DXP6TFL43Z`
--

DROP TABLE IF EXISTS `DXP6TFL43Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DXP6TFL43Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DXP6TFL43Z`
--

LOCK TABLES `DXP6TFL43Z` WRITE;
/*!40000 ALTER TABLE `DXP6TFL43Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `DXP6TFL43Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E18L7XHG90`
--

DROP TABLE IF EXISTS `E18L7XHG90`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E18L7XHG90` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E18L7XHG90`
--

LOCK TABLES `E18L7XHG90` WRITE;
/*!40000 ALTER TABLE `E18L7XHG90` DISABLE KEYS */;
/*!40000 ALTER TABLE `E18L7XHG90` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E2VLZUOYXF`
--

DROP TABLE IF EXISTS `E2VLZUOYXF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E2VLZUOYXF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E2VLZUOYXF`
--

LOCK TABLES `E2VLZUOYXF` WRITE;
/*!40000 ALTER TABLE `E2VLZUOYXF` DISABLE KEYS */;
/*!40000 ALTER TABLE `E2VLZUOYXF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E32NKCPWIR`
--

DROP TABLE IF EXISTS `E32NKCPWIR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E32NKCPWIR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E32NKCPWIR`
--

LOCK TABLES `E32NKCPWIR` WRITE;
/*!40000 ALTER TABLE `E32NKCPWIR` DISABLE KEYS */;
/*!40000 ALTER TABLE `E32NKCPWIR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E3CZ5X1TQQ`
--

DROP TABLE IF EXISTS `E3CZ5X1TQQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E3CZ5X1TQQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E3CZ5X1TQQ`
--

LOCK TABLES `E3CZ5X1TQQ` WRITE;
/*!40000 ALTER TABLE `E3CZ5X1TQQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `E3CZ5X1TQQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E891FM4QWG`
--

DROP TABLE IF EXISTS `E891FM4QWG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E891FM4QWG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E891FM4QWG`
--

LOCK TABLES `E891FM4QWG` WRITE;
/*!40000 ALTER TABLE `E891FM4QWG` DISABLE KEYS */;
/*!40000 ALTER TABLE `E891FM4QWG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `E9W7WLQT3P`
--

DROP TABLE IF EXISTS `E9W7WLQT3P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `E9W7WLQT3P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `E9W7WLQT3P`
--

LOCK TABLES `E9W7WLQT3P` WRITE;
/*!40000 ALTER TABLE `E9W7WLQT3P` DISABLE KEYS */;
/*!40000 ALTER TABLE `E9W7WLQT3P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EAGJC1BL3T`
--

DROP TABLE IF EXISTS `EAGJC1BL3T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EAGJC1BL3T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EAGJC1BL3T`
--

LOCK TABLES `EAGJC1BL3T` WRITE;
/*!40000 ALTER TABLE `EAGJC1BL3T` DISABLE KEYS */;
/*!40000 ALTER TABLE `EAGJC1BL3T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EAHC3ADSOX`
--

DROP TABLE IF EXISTS `EAHC3ADSOX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EAHC3ADSOX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EAHC3ADSOX`
--

LOCK TABLES `EAHC3ADSOX` WRITE;
/*!40000 ALTER TABLE `EAHC3ADSOX` DISABLE KEYS */;
/*!40000 ALTER TABLE `EAHC3ADSOX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ED8Z9TXZZ6`
--

DROP TABLE IF EXISTS `ED8Z9TXZZ6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ED8Z9TXZZ6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ED8Z9TXZZ6`
--

LOCK TABLES `ED8Z9TXZZ6` WRITE;
/*!40000 ALTER TABLE `ED8Z9TXZZ6` DISABLE KEYS */;
/*!40000 ALTER TABLE `ED8Z9TXZZ6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EFLSN9IH1D`
--

DROP TABLE IF EXISTS `EFLSN9IH1D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EFLSN9IH1D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EFLSN9IH1D`
--

LOCK TABLES `EFLSN9IH1D` WRITE;
/*!40000 ALTER TABLE `EFLSN9IH1D` DISABLE KEYS */;
/*!40000 ALTER TABLE `EFLSN9IH1D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EG9MPH7ZBK`
--

DROP TABLE IF EXISTS `EG9MPH7ZBK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EG9MPH7ZBK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EG9MPH7ZBK`
--

LOCK TABLES `EG9MPH7ZBK` WRITE;
/*!40000 ALTER TABLE `EG9MPH7ZBK` DISABLE KEYS */;
/*!40000 ALTER TABLE `EG9MPH7ZBK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EHI8FPG6TX`
--

DROP TABLE IF EXISTS `EHI8FPG6TX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EHI8FPG6TX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EHI8FPG6TX`
--

LOCK TABLES `EHI8FPG6TX` WRITE;
/*!40000 ALTER TABLE `EHI8FPG6TX` DISABLE KEYS */;
/*!40000 ALTER TABLE `EHI8FPG6TX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EIG6N2P1A3`
--

DROP TABLE IF EXISTS `EIG6N2P1A3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EIG6N2P1A3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EIG6N2P1A3`
--

LOCK TABLES `EIG6N2P1A3` WRITE;
/*!40000 ALTER TABLE `EIG6N2P1A3` DISABLE KEYS */;
/*!40000 ALTER TABLE `EIG6N2P1A3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EJ662JUNM9`
--

DROP TABLE IF EXISTS `EJ662JUNM9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EJ662JUNM9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EJ662JUNM9`
--

LOCK TABLES `EJ662JUNM9` WRITE;
/*!40000 ALTER TABLE `EJ662JUNM9` DISABLE KEYS */;
/*!40000 ALTER TABLE `EJ662JUNM9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMJQNKMBJP`
--

DROP TABLE IF EXISTS `EMJQNKMBJP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMJQNKMBJP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMJQNKMBJP`
--

LOCK TABLES `EMJQNKMBJP` WRITE;
/*!40000 ALTER TABLE `EMJQNKMBJP` DISABLE KEYS */;
/*!40000 ALTER TABLE `EMJQNKMBJP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EN83XIF5O0`
--

DROP TABLE IF EXISTS `EN83XIF5O0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EN83XIF5O0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EN83XIF5O0`
--

LOCK TABLES `EN83XIF5O0` WRITE;
/*!40000 ALTER TABLE `EN83XIF5O0` DISABLE KEYS */;
/*!40000 ALTER TABLE `EN83XIF5O0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ET5G9DNADU`
--

DROP TABLE IF EXISTS `ET5G9DNADU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ET5G9DNADU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ET5G9DNADU`
--

LOCK TABLES `ET5G9DNADU` WRITE;
/*!40000 ALTER TABLE `ET5G9DNADU` DISABLE KEYS */;
/*!40000 ALTER TABLE `ET5G9DNADU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EUEIKI0LS5`
--

DROP TABLE IF EXISTS `EUEIKI0LS5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EUEIKI0LS5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EUEIKI0LS5`
--

LOCK TABLES `EUEIKI0LS5` WRITE;
/*!40000 ALTER TABLE `EUEIKI0LS5` DISABLE KEYS */;
/*!40000 ALTER TABLE `EUEIKI0LS5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EY12N0I3DE`
--

DROP TABLE IF EXISTS `EY12N0I3DE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EY12N0I3DE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EY12N0I3DE`
--

LOCK TABLES `EY12N0I3DE` WRITE;
/*!40000 ALTER TABLE `EY12N0I3DE` DISABLE KEYS */;
/*!40000 ALTER TABLE `EY12N0I3DE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EY30SGW4U2`
--

DROP TABLE IF EXISTS `EY30SGW4U2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EY30SGW4U2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EY30SGW4U2`
--

LOCK TABLES `EY30SGW4U2` WRITE;
/*!40000 ALTER TABLE `EY30SGW4U2` DISABLE KEYS */;
/*!40000 ALTER TABLE `EY30SGW4U2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F1UBG6WCEP`
--

DROP TABLE IF EXISTS `F1UBG6WCEP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F1UBG6WCEP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F1UBG6WCEP`
--

LOCK TABLES `F1UBG6WCEP` WRITE;
/*!40000 ALTER TABLE `F1UBG6WCEP` DISABLE KEYS */;
/*!40000 ALTER TABLE `F1UBG6WCEP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F2V1VSJ5KB`
--

DROP TABLE IF EXISTS `F2V1VSJ5KB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F2V1VSJ5KB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F2V1VSJ5KB`
--

LOCK TABLES `F2V1VSJ5KB` WRITE;
/*!40000 ALTER TABLE `F2V1VSJ5KB` DISABLE KEYS */;
/*!40000 ALTER TABLE `F2V1VSJ5KB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F380EVRZLO`
--

DROP TABLE IF EXISTS `F380EVRZLO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F380EVRZLO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F380EVRZLO`
--

LOCK TABLES `F380EVRZLO` WRITE;
/*!40000 ALTER TABLE `F380EVRZLO` DISABLE KEYS */;
/*!40000 ALTER TABLE `F380EVRZLO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F4SJSZT412`
--

DROP TABLE IF EXISTS `F4SJSZT412`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F4SJSZT412` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F4SJSZT412`
--

LOCK TABLES `F4SJSZT412` WRITE;
/*!40000 ALTER TABLE `F4SJSZT412` DISABLE KEYS */;
/*!40000 ALTER TABLE `F4SJSZT412` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F5VQNXOJ1L`
--

DROP TABLE IF EXISTS `F5VQNXOJ1L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F5VQNXOJ1L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F5VQNXOJ1L`
--

LOCK TABLES `F5VQNXOJ1L` WRITE;
/*!40000 ALTER TABLE `F5VQNXOJ1L` DISABLE KEYS */;
/*!40000 ALTER TABLE `F5VQNXOJ1L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F8ZFR4EKO2`
--

DROP TABLE IF EXISTS `F8ZFR4EKO2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F8ZFR4EKO2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F8ZFR4EKO2`
--

LOCK TABLES `F8ZFR4EKO2` WRITE;
/*!40000 ALTER TABLE `F8ZFR4EKO2` DISABLE KEYS */;
/*!40000 ALTER TABLE `F8ZFR4EKO2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `F9WIATJ9OG`
--

DROP TABLE IF EXISTS `F9WIATJ9OG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `F9WIATJ9OG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F9WIATJ9OG`
--

LOCK TABLES `F9WIATJ9OG` WRITE;
/*!40000 ALTER TABLE `F9WIATJ9OG` DISABLE KEYS */;
/*!40000 ALTER TABLE `F9WIATJ9OG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FA6W1154UJ`
--

DROP TABLE IF EXISTS `FA6W1154UJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FA6W1154UJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FA6W1154UJ`
--

LOCK TABLES `FA6W1154UJ` WRITE;
/*!40000 ALTER TABLE `FA6W1154UJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `FA6W1154UJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FBDKFWZFL5`
--

DROP TABLE IF EXISTS `FBDKFWZFL5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FBDKFWZFL5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FBDKFWZFL5`
--

LOCK TABLES `FBDKFWZFL5` WRITE;
/*!40000 ALTER TABLE `FBDKFWZFL5` DISABLE KEYS */;
/*!40000 ALTER TABLE `FBDKFWZFL5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FDOY17BLQA`
--

DROP TABLE IF EXISTS `FDOY17BLQA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FDOY17BLQA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FDOY17BLQA`
--

LOCK TABLES `FDOY17BLQA` WRITE;
/*!40000 ALTER TABLE `FDOY17BLQA` DISABLE KEYS */;
/*!40000 ALTER TABLE `FDOY17BLQA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FFCTTXZ2R1`
--

DROP TABLE IF EXISTS `FFCTTXZ2R1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FFCTTXZ2R1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FFCTTXZ2R1`
--

LOCK TABLES `FFCTTXZ2R1` WRITE;
/*!40000 ALTER TABLE `FFCTTXZ2R1` DISABLE KEYS */;
/*!40000 ALTER TABLE `FFCTTXZ2R1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FFV50BOWAA`
--

DROP TABLE IF EXISTS `FFV50BOWAA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FFV50BOWAA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FFV50BOWAA`
--

LOCK TABLES `FFV50BOWAA` WRITE;
/*!40000 ALTER TABLE `FFV50BOWAA` DISABLE KEYS */;
/*!40000 ALTER TABLE `FFV50BOWAA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FIT30KCY9E`
--

DROP TABLE IF EXISTS `FIT30KCY9E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FIT30KCY9E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FIT30KCY9E`
--

LOCK TABLES `FIT30KCY9E` WRITE;
/*!40000 ALTER TABLE `FIT30KCY9E` DISABLE KEYS */;
/*!40000 ALTER TABLE `FIT30KCY9E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FJBHJ0P5FQ`
--

DROP TABLE IF EXISTS `FJBHJ0P5FQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FJBHJ0P5FQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FJBHJ0P5FQ`
--

LOCK TABLES `FJBHJ0P5FQ` WRITE;
/*!40000 ALTER TABLE `FJBHJ0P5FQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `FJBHJ0P5FQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FKPDK6RQLU`
--

DROP TABLE IF EXISTS `FKPDK6RQLU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FKPDK6RQLU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FKPDK6RQLU`
--

LOCK TABLES `FKPDK6RQLU` WRITE;
/*!40000 ALTER TABLE `FKPDK6RQLU` DISABLE KEYS */;
/*!40000 ALTER TABLE `FKPDK6RQLU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FL4GH0LD3R`
--

DROP TABLE IF EXISTS `FL4GH0LD3R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FL4GH0LD3R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `flag` varchar(255) DEFAULT NULL,
  `stock` int DEFAULT '0',
  `isGuessy` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FL4GH0LD3R`
--

LOCK TABLES `FL4GH0LD3R` WRITE;
/*!40000 ALTER TABLE `FL4GH0LD3R` DISABLE KEYS */;
INSERT INTO `FL4GH0LD3R` VALUES (1,'dctf1337{mnemotechnical_icterogenetic_co-omnipotent_Fauve_overfilter_preordered}',1,0),(2,'dctf1337{rehang_chirographers_superpatriotic_hectocotylus_collocated_citrylidene_Bedouin}',1,0),(3,'dctf1337{orientality_recoupment_Parsi_stolport_nontactic}',1,0),(4,'dctf1337{grackles_arn_argonautid_scarifier_pleio-_Estey}',1,0),(5,'dctf1337{lurry_vernonin_Nootka_ALS_bangers_phantastic}',1,0),(6,'dctf1337{ibidem_slumism_synchronizable_salpid_populate}',1,0),(7,'dctf1337{dodecasemic_self-wisdom_bifurcating_Cariacus_Catasetum_misbilled_Jesuitocracy}',1,0),(8,'dctf1337{kasbahs_prestricken_instability_bourns_liquid}',1,0),(9,'dctf1337{developpes_chloroplatinous_bacteriform_Nelsonia_reexpose}',1,0),(10,'dctf1337{uniarticulate_barstools_spreadingly_tipstaves_wood-skirted_pungyi_Benedikt_buccula_Phocodontia}',1,0),(11,'dctf1337{fodge_Warram_unlabialized_lactophosphate_price-cutting}',1,0),(12,'dctf1337{well-adapted_Byrle_anileness_rheumatism-root_pretorial_compliances_postic_pseudoinspirational_baptises}',1,0),(13,'dctf1337{tastemaker_saccharinity_re-engraving_Megaloptera_coniform_dissembly_cragginess}',1,0),(14,'dctf1337{creditably_shipbreaking_Phoma_hewn_chinkle_motorcar_partizanship}',1,0),(15,'dctf1337{Kordofanian_undetectably_Gros_unexposable_dismasting_quasi-fortunate_one-by-one_yus_utero-_tender-heartedly}',1,0),(16,'dctf1337{computist_balza_radiators_locust\'s_moosemise_syncraniate_prosected}',1,0),(17,'dctf1337{harvesters_renegotiator_McAndrews_squaccos_eschatologist_Estherwood_unrevested}',1,0),(18,'dctf1337{furlough_unblusterously_gold-washer_geranin_loimic_triakisoctahedron_newswriting}',1,0),(19,'dctf1337{anaphroditic_protandry_heavenly_slingback_alvearies_sophomores}',1,0),(20,'dctf1337{jews\'harp_merchandrise_Welcy_semifinals_well-focused_argentometer_mirex}',1,0),(21,'dctf1337{arsenic-_gondoletta_crosscuts_proaccelerin_trephiner_posturize_drawbridge}',1,0),(22,'dctf1337{quirksome_fixed-do_bombilation_unsolid_caddices_simplist_drop-out}',1,0),(23,'dctf1337{Vandyke_preamp_ungarnered_coplotter_supersafety}',1,0),(24,'dctf1337{reimpregnating_headlight_postseasonal_supermilitary_pegmen_encephalitic_Wutsin_whinyard_Archelenis}',1,0),(25,'dctf1337{caracoles_white-russet_paleron_sleight_negatory_fanaticize_attenuators_gedder_buccinoid}',1,0),(26,'dctf1337{celloidin_Adamski_outdressing_wind-gall_Alemanni_codiniac_BOSS_Selmer}',1,0),(27,'dctf1337{Danaids_chromatology_Sturnus_opsonium_whiny_reauthorization}',1,0),(28,'dctf1337{yapons_matelass_synopsizing_consulships_yean_titanaugite_Tenach_chides_zoomagnetism_longsighted}',1,0),(29,'dctf1337{woodmancraft_amalgamist_mulcting_shipmast_nondeterrent_airy-fairy_visceroptotic}',1,0),(30,'dctf1337{pastiling_wieldiest_stillage_evections_cantlet_subchoroidal_backwoodsman}',1,0),(31,'dctf1337{decriminalize_signaled_emphasise_nondeprivable_Liaoyang_judicialized_oppilative_innocents_Ingraham_reinsertion}',1,0),(32,'dctf1337{quadricrescentic_sylvius_antifaction_Sulafat_haunch-bone_Dinophyceae_myrioscope_sloat_harpins_tetanisation}',1,0),(33,'dctf1337{inscenation_unoxygenated_brae\'s_Pelasgoi_monkeyhood_re-tread_Duse_luhinga_IAUC}',1,0),(34,'dctf1337{Dachau_eliminatory_Kalevala_authorisable_fascination_Maryn_Salicariaceae_self-repugnant_full-resounding}',1,0),(35,'dctf1337{Oxyuridae_quietened_semimathematical_parasitotrope_autopilot\'s_summarization\'s}',1,0),(36,'dctf1337{therefor_Maryus_epidermically_Ninnekah_guidwife_Pabst_indene_reconfirming_bursitos_producible}',1,0),(37,'dctf1337{centupling_stomapod_phellem_barrel-roll_uncommercially_paraffin}',1,0),(38,'dctf1337{encake_Helipterum_fanfishes_Toulouse_penthouse_thalamifloral_predestinator}',1,0),(39,'dctf1337{palace_hadji_Frants_Kassapa_demijambe_makework_ombudsperson_quadragintesimal}',1,0),(40,'dctf1337{airmanship_evil-eyed_shockingly_Alfirk_hypocrinia}',1,0),(41,'dctf1337{exclusivity_punctuative_quasi-logical_holochoanoidal_sandy-bottomed_impacability_Scot._acatalectic_overcapitalizes}',1,0),(42,'dctf1337{orthopaedia_land-visiting_beta-orcin_soluble_reappliance}',1,0),(43,'dctf1337{nonprepositional_grivets_unaffected_entablement_foppy}',1,0),(44,'dctf1337{dunite_Xanthium_undrunk_nonhistrionicalness_Chatom}',1,0),(45,'dctf1337{rollicking_Bhavnagar_milchig_shooled_Antilopinae}',1,0),(46,'dctf1337{aurine_vesicular_overconfidence_knapsack\'s_Litorinidae}',1,0),(47,'dctf1337{irrogate_harpy-eagle_Polycladida_assayers_Morral_plateaus_Battat_supersarcastically_grandstand_illuvia}',1,0),(48,'dctf1337{overdescribe_unpenetratively_cove_Cavalerius_temptationless_regulator\'s_liquids_ringstraked}',1,0),(49,'dctf1337{alack_apatite_reliquaries_Bolshevikism_murmurs_paroling_cacao_Guaymas}',1,0),(50,'dctf1337{viscoelasticity_sey_dew-dabbled_candlewicking_flintier_Ponemah_icebreakers}',1,0),(51,'dctf1337{unpopularized_world-directing_pre-excellent_reprotect_busser_watercresses_Khosa}',1,0),(52,'dctf1337{wax-bearing_subcontinued_Zenonic_toreutics_thunderlight_cotwinned_theatrograph_bawls_Seabeck}',1,0),(53,'dctf1337{twice-counted_ascender_Tillandsia_diffarreation_phrenomesmerism}',1,0),(54,'dctf1337{Wallon_unevasively_Jovinianist_Serrasalmo_grillworks_darkskin_superpose_nimbification_retardive_osteogenetic}',1,0),(55,'dctf1337{hocus-pocussing_Admetus_Schumann_arsonite_misfigure_musicodramatic_suppositive_Blondie_scutiform}',1,0),(56,'dctf1337{atef-crown_softest_methoxyl_birostrated_Blondie_Manichaeanism_leptospirosis}',1,0),(57,'dctf1337{prepossessingness_noncannibalistically_shiggaion_Ogawa_melophonist_lane\'s_offendedness_cowpea_Sopheric}',1,0),(58,'dctf1337{summage_Reszke_patchcock_semiovate_NEAR_high-fated_Baldr_unexpiable}',1,0),(59,'dctf1337{readl_Tova_rubijervine_Scomber_upholsterers}',1,0),(60,'dctf1337{satyress_peauder_Ossineke_lounging_Barnwell}',1,0),(61,'dctf1337{dalapons_Oona_wildcatted_fences_double-ended}',1,0),(62,'dctf1337{castrati_Franciskus_SRCN_ankle_unicellularity_self-sheltered_moppers_pharyngocele_tabbying}',1,0),(63,'dctf1337{trolleyed_paleomagnetist_congas_nonignitible_hippopotamoid_Fultondale}',1,0),(64,'dctf1337{movelessly_unroost_zigger_Dody_ungelatinous_sheth}',1,0),(65,'dctf1337{peasen_mutableness_Ailis_branchiness_dammar_non-jurant_swingboat_strombuliferous_birdseyes}',1,0),(66,'dctf1337{protrusible_retrohepatic_unpartitive_cigar\'s_Hesperornithiformes_bellboy_camp-shot_Uintatherium_menisci}',1,0),(67,'dctf1337{naturata_reguarantee_unadroitness_sixpenny_overabusing_Achillize_irresonance_gladen_deciliters}',1,0),(68,'dctf1337{poaches_equiradial_postthalamic_dactylopore_lambskin_unwrought}',1,0),(69,'dctf1337{howker_gecks_vatical_chlorinous_firm-based_voluming_notturni_cyanidation}',1,0),(70,'dctf1337{rootward_indivisible_preparers_mysid_habitator_schooldame_tooth-shaped}',1,0),(71,'dctf1337{Yorgo_latebricole_suberise_ungeuntarium_self-sterility_wormlike_trans-subjective_algometric_uranate}',1,0),(72,'dctf1337{remoras_vivax_undertribe_depressions_arabians_Powellton}',1,0),(73,'dctf1337{Anetta_Theotokos_noiselessly_glochidial_Achish_cumberer_pullovers_nosy_unletterlike_inmprovidence}',1,0),(74,'dctf1337{overneutralizer_sonnetized_phon_trenail_interforce_Subiaco_dismortgaging}',1,0),(75,'dctf1337{infects_broidery_refectorial_moufflons_Buckie_panther\'s}',1,0),(76,'dctf1337{heartblood_captioning_underfeeling_Pachomius_Masry_unindigenously_forest-clad_bootstrap_thudded}',1,0),(77,'dctf1337{rhomb-leaved_albuminometer_nichevo_daguerreotypist_self-revelation_self-awareness_dysautonomia_antineutrino}',1,0),(78,'dctf1337{aerohydrodynamic_semese_OGT_heel-attaching_testamentalness_snottier_nonfeelingly}',1,0),(79,'dctf1337{untrophied_wort_obstinative_absorbed_overtipple_Flory_nonimperially_Gomarite_dermatoneurology}',1,0),(80,'dctf1337{cryptonymous_scelalgia_dimwits_columella_omodynia_prankier_nonfrangible_Muse}',1,0),(81,'dctf1337{butlers_Chinantecan_modernising_hematines_superaffluently_goldbug}',1,0),(82,'dctf1337{sweepstake_Terrie_unwiser_nonpueblo_Belaites}',1,0),(83,'dctf1337{polyarchal_malpropriety_overgirdle_triodia_aborigines}',1,0),(84,'dctf1337{hemodromograph_reddock_discomfort_paracenteses_korona_Ionicization_hypoxanthic_ameen_hospodariat_threadfishes}',1,0),(85,'dctf1337{microcyst_absolvitor_geophytic_law-learned_quantifier}',1,0),(86,'dctf1337{Chlorococcum_unhealthy_bullwhipping_supermannish_kytoon_stuffiness_debellation}',1,0),(87,'dctf1337{XO_Phycodromidae_joker_hand-fire_Genucius_wirehaired_shrouding_traumatization}',1,0),(88,'dctf1337{neckwear_Bare_burnt-umber_nonspecialists_homacanth_pregnancies}',1,0),(89,'dctf1337{pleurobranch_geolinguistics_Ambroise_hadada_guano_uncircumcised_unpredict_Cranaus_berghaan_Kokas}',1,0),(90,'dctf1337{Larkin_micacite_reoriented_guanidopropionic_tamaraus}',1,0),(91,'dctf1337{uncontriteness_disomatous_restrictively_Crossroads_eurythmical}',1,0),(92,'dctf1337{Aves_Dover_housemaidenly_sailplaned_juncoes_dissimilating_interpleader}',1,0),(93,'dctf1337{muletas_escent_ribandry_Nevile_Firebee_ill-effaceable_hemihypertrophy_bluetongue}',1,0),(94,'dctf1337{self-question_zygadenin_Voluntown_frazil_onychopathy}',1,0),(95,'dctf1337{hastated_sulfinide_aldermanical_membranophonic_genes_Phillie_quinquevalency_motherkin_Pellikka}',1,0),(96,'dctf1337{musk-tree_musmon_love-starved_disconformities_avian_sicarian_red-billed_imparking_deputed}',1,0),(97,'dctf1337{Mabinogion_esophagogastrostomy_abamp_Bildad_Plasmodiophora_olefinic_crooknecked_unmorally_obtusi-_unapproaching}',1,0),(98,'dctf1337{staypak_prerectal_Donalt_AMAT_sleepwort_implausibly_polkaing_agrostologic_auth._Toni}',1,0),(99,'dctf1337{uncoursed_doctorially_tossing-in_dichasia_LMT}',1,0),(100,'dctf1337{enmarbled_suddens_chicory_epiglottides_frijol_begary}',1,0),(101,'dctf1337{intensely_palatopharyngeus_cognisable_extraburghal_Remonstrance}',1,0),(102,'dctf1337{Mentone_pipage_scantlinged_kinoos_Koball_inconnus_fluviatile_gruyeres}',1,0),(103,'dctf1337{sound-minded_fructified_amalgamation_tachylyte_isocyanurate_cautivo_planeticose_strong-stapled_sharp-tailed}',1,0),(104,'dctf1337{militaristic_pregladden_pantology_sow-bread_quasi-distantly}',1,0),(105,'dctf1337{mosquito-free_prejudged_half-intoned_Passeriformes_crossband_walloped_worthinesses_novella_impostumate_neckerchief}',1,0),(106,'dctf1337{fire-tight_storable_vanish_subrules_nictitant_prematurely}',1,0),(107,'dctf1337{abjunct_steamboat_Barnsley_nonvehemently_cablish_ultraistic_consarcinate}',1,0),(108,'dctf1337{vardy_unexuberant_xenoliths_gabbier_Tilghman_postexilian_val._four-cylindered}',1,0),(109,'dctf1337{thylacitis_nobbiest_steadite_therapeutism_rufopiceous_Ghazzali_jotted}',1,0),(110,'dctf1337{hocco_humectation_curvation_ropers_unentered_riverless_camphoraceous_demasts}',1,0),(111,'dctf1337{pregnability_work-study_laterocervical_describability_unh-unh_reshapes_nanocephalus_helloes}',1,0),(112,'dctf1337{doorstead_athletically_subterranean_nuculoid_passings_wrangs_uploom_subsoiling_deforming}',1,0),(113,'dctf1337{redeemeress_wagonless_paranoidism_Nullstellensatz_cheaper_mether}',1,0),(114,'dctf1337{cotillon_bloodsucker_Marlene_crownlet_graecophil_branglement_tildes_Catriona_matr-_subferryman}',1,0),(115,'dctf1337{sonicated_pilloried_identifer_credentialism_beatae}',1,0),(116,'dctf1337{Bernicia_phyllocerate_freckled_Teheran_exomphalos_noncontemplativeness_screeving_asynchronisms_enwreathing_costipulator}',1,0),(117,'dctf1337{Extasiie_phytobiologist_forewrought_hectometer_botryopterid_Trinetta_jibbons_pretexts_undigestable}',1,0),(118,'dctf1337{Pratts_bulleting_extraterrene_pasquillic_fecundated_yttrocerite}',1,0),(119,'dctf1337{tract\'s_bog-bred_buttoning_cross-firing_simp}',1,0),(120,'dctf1337{oxyquinoline_missilemen_unshapenness_curtailedly_discases}',1,0),(121,'dctf1337{incontiguous_spur-galled_Fauve_infiltrators_odd-thinking_unstrap_Nierstein_philtered}',1,0),(122,'dctf1337{jetliners_cankerbird_loggish_epistomal_orthographist_pedatrophia_Cibolan_ghurry_tyrannisingly}',1,0),(123,'dctf1337{muskit_Aviculariidae_denunciant_oligistical_antineologian_stepbrotherhood}',1,0),(124,'dctf1337{lumbo-abdominal_voltzite_creole-fishes_recommits_Saccopharyngidae_Schutz_experiences}',1,0),(125,'dctf1337{unengrossing_rhythm-and-blues_mesally_lokshen_unobsequiousness_prekindergartens_hennas_mirky_whoso_overspeak}',1,0),(126,'dctf1337{resistively_futuramic_swimy_Tussaud_flatfoots_popover}',1,0),(127,'dctf1337{expede_monembryary_albines_xviii_limeade_ergotist_ignoramuses_heteronereis_quick-selling}',1,0),(128,'dctf1337{tar-removing_deodorizers_drop-leaf_pereirine_incertain_robustity}',1,0),(129,'dctf1337{Nubian_retentionist_appointee_currish_brachistochronous}',1,0),(130,'dctf1337{grim-visaged_Mariko_membranology_Euthamia_nontillable_downrush_electrobiological_streke_recherche_antiradically}',1,0),(131,'dctf1337{newsbeat_neurol_rebooks_haemad_Caphtor_unsubordinated_blueprint\'s}',1,0),(132,'dctf1337{Nairobi_vendues_insperse_uninquiring_sciaenid_Shore}',1,0),(133,'dctf1337{staphyloangina_grubby_gypsoplast_danzon_meteoritical_willyer_nonespousal_Kefauver_sectarianly}',1,0),(134,'dctf1337{Sarcosporidia_semicollegiate_empicture_world-studded_proprietorial_lienculi_centennial_Inhiston}',1,0),(135,'dctf1337{prehistorically_dirigomotor_Ordovices_organisms_tyrannosaurs_Chaseley_undampable_whatkin_Pipile}',1,0),(136,'dctf1337{puppetman_fire-flowing_diosphenol_crosswords_ambilaterally_mudlarker_Boma_tefillin_phalangerine}',1,0),(137,'dctf1337{seventy-ninth_tameless_unsoberness_marker-off_unanimately_heterochromatized_cog-wood}',1,0),(138,'dctf1337{pilocarpin_wariness_uroo_overcoy_Sumerology_gyrosyn_mistrusting_passionately_Mammea_resolvability}',1,0),(139,'dctf1337{contra-indicate_TAT_abstort_incretionary_mytilacean_conkanee_Propliopithecus_craggier_toothiest}',1,0),(140,'dctf1337{symmetry\'s_woolding_Runnells_clunks_subheadquarters_semispiral_trilobitic_steep-descending}',1,0),(141,'dctf1337{carboxyl_megabucks_n\'s_Calliphoridae_baseband_quadrans}',1,0),(142,'dctf1337{Bueyeros_hullaballoo_unflagging_Septembrist_Hidatsas_Heterosporeae_sageness_damaskeen_questionous}',1,0),(143,'dctf1337{capriole_countryish_amitroles_hemagglutinate_miltsick_goninidia_overproduction_emplastrum_superbity_ruching}',1,0),(144,'dctf1337{visitrix_catalectic_matchboard_three-fruited_overrepresentativeness}',1,0),(145,'dctf1337{hacienda_putties_overgreatness_midiskirt_wem_Chambers_amniotes_chylified_gastrostaxis}',1,0),(146,'dctf1337{leaser_earth-lit_thremmatology_tentilla_galiongee}',1,0),(147,'dctf1337{graphostatic_urofuscohematin_accel_cirrus_Dekow_Arapesh_Celia}',1,0),(148,'dctf1337{Rolando_Karachi_finalizing_epanody_Artimas_snuff-stained_argufying_break-down_maintaining_railriding}',1,0),(149,'dctf1337{folkmooter_paederastically_Isomera_paper-selling_pettifoggery_microcirculatory_self-inclosed_Riesling_recodification}',1,0),(150,'dctf1337{pneumoperitonitis_Scoter_AFNOR_right-sidedness_aurigerous_chaunts_hyperfunctioning_subprogram\'s_subserosa}',1,0),(151,'dctf1337{chain-smoke_Chavantean_pachucos_croakiest_trypanosomacide_where\'ll_many-formed_quadriciliate_pouty_bronchiarctia}',1,0),(152,'dctf1337{limnobiologically_forwean_Sethi_Athapascan_incomposure_Ebenezer}',1,0),(153,'dctf1337{indelibility_tomatillo_hippocastanaceous_art._ikrar-namah_twenty-year}',1,0),(154,'dctf1337{overinstruction_spirographic_intensely_nonfrigidly_irrecusably_doeth_Shuman}',1,0),(155,'dctf1337{leapfrogger_redocument_saggared_palestrae_Actinomycetaceae}',1,0),(156,'dctf1337{brass-bold_BDS_otomycosis_Janith_derivations_mustelid}',1,0),(157,'dctf1337{shedder_celeb_preaccomplish_worts_Woodworth_wurrup_rhinalgia_felloe_procurator-general_harassedly}',1,0),(158,'dctf1337{bibbler_frightsome_sociate_Sylow_Cumana}',1,0),(159,'dctf1337{Ustilaginoidea_Deipylus_unpastor_disinfects_nutsedges_akia_methodically_Belden_Betelgeux_IChemE}',1,0),(160,'dctf1337{buckoes_crackiness_unengendered_nail-biting_pharmacologist_misenroll_Aleurites_scopiform}',1,0),(161,'dctf1337{acclaims_electrosurgery_broadwise_shipowning_coronets_retropulsive_parameciums_unmusicianly}',1,0),(162,'dctf1337{overgrain_ritziest_reversionable_bacteriologists_airworthy_irresistless_oilers_Myxinoidei_cremates}',1,0),(163,'dctf1337{Hispanically_vealed_Dott_adipose_wooliness_soul-thralling_ankush_swaggered_sandburr}',1,0),(164,'dctf1337{booklice_solvable_comatosely_staggiest_specificated_Eadwina}',1,0),(165,'dctf1337{gipsyweed_inferential_behind_thioacetal_vamoosing_R.C.}',1,0),(166,'dctf1337{retrogressions_twice-alleged_lactobutyrometer_nonpliantly_Fnen_mesocranic_inconditional_holaspidean_Cowperian}',1,0),(167,'dctf1337{Szomorodni_Whigham_fluctuate_agrarianism_myosinose_nonefficiency_rhinitides_partway}',1,0),(168,'dctf1337{despatch_punatoo_Deusdedit_pelviolithotomy_tertio_diosmosed_inhesions}',1,0),(169,'dctf1337{unwinkingly_Bahamas_nonrationalism_Kumar_unnymphean_explicits_minces_quitting_free-reed_unsatanic}',1,0),(170,'dctf1337{cumulose_unfusibility_teratoid_rewidening_phalarope_groutier_osmiamic_transmutability_unspouted_embergoose}',1,0),(171,'dctf1337{photoxylography_guaiacol_preobliged_Milburr_diplantidian}',1,0),(172,'dctf1337{euryalidan_medicative_Sothena_peppiness_obols_riband-wreathed}',1,0),(173,'dctf1337{mind-expansion_Titanichthys_undeservedness_salesrooms_abbozzo}',1,0),(174,'dctf1337{discipliner_disability\'s_twice-doubted_pneumochirurgia_unturn_Matt_preinvestigation_hagi-_Weatherby_tardamente}',1,0),(175,'dctf1337{achlorhydric_Jailsco_ratherest_gravamens_tightwads_cottoid_inconveniently_plagiarists_FFC}',1,0),(176,'dctf1337{Kilbourne_Pseudo-chinese_glycerination_retransmission_coronach}',1,0),(177,'dctf1337{bhindi_Edmond_laparoscope_uncoacted_iridopupillary_co-optate_encephalopsychesis_Genesia}',1,0),(178,'dctf1337{Pterygotus_spiral-bound_omphaloid_gapes_Sericana_plagiocephalous_texturally_playfully_unsqueezed_enfeebler}',1,0),(179,'dctf1337{snaff_Hackett_worm-tongued_scabicide_ciceroni}',1,0),(180,'dctf1337{euphonous_Arvid_etherizing_Enoch_Farmersville_succinylsulphathiazole_squabbing}',1,0),(181,'dctf1337{skirmishingly_redeemable_symbranchoid_proleaguer_Legis_polygamize_clothesman_sabertooth}',1,0),(182,'dctf1337{Jaques_manent_hoof-printed_syenodiorite_outpeopled_woodier}',1,0),(183,'dctf1337{casthouse_anhydric_wooshes_ultrabasite_flyable_preexcept_overreplete_sphincter_imagines_Badaxe}',1,0),(184,'dctf1337{self-advancer_odourless_nonpopery_cauterise_hopelessly_hemicephalous_colocola_Paasikivi_unpebbled}',1,0),(185,'dctf1337{Turkomanize_disruptions_card-carrier_hyperanarchic_unremittency_Drusie_impaling}',1,0),(186,'dctf1337{tin-bounder_allonymously_knowable_Hecabe_silliest}',1,0),(187,'dctf1337{extraconstellated_Bircher_Ten_unpresaged_plagiostomous_divertingness}',1,0),(188,'dctf1337{faitery_poetico-philosophic_furole_deutonephron_nuciculture_AUI_treemaking}',1,0),(189,'dctf1337{aerosporin_xanthiuria_elocutionists_thegn_fulminator}',1,0),(190,'dctf1337{subpatroness_centrolineal_Cels_emerit_hidage_andrographolide_latericumbent}',1,0),(191,'dctf1337{purple-vested_inventoried_salpid_tribunicial_platypodia_endshake_stative_unimplanted_truantcy_Mobutu}',1,0),(192,'dctf1337{forked-tailed_eremophyte_canoing_reprove_side-lever}',1,0),(193,'dctf1337{hyperethical_draw-boy_Goasila_Eduino_Derrik}',1,0),(194,'dctf1337{pockets_jerrybuild_nonrealism_nose-tickling_Ratha}',1,0),(195,'dctf1337{glandularly_misbode_barrowcoat_gerodontic_forblack_possum_tradeable}',1,0),(196,'dctf1337{inheritage_blurriness_inconclusion_postsigmoidal_Romaniform_suborbiculated_handicraft_Platycarpus}',1,0),(197,'dctf1337{nearaways_ungraspable_radiorays_woordbook_decapper_daggy_taketh_nontotalitarian_paleon}',1,0),(198,'dctf1337{mahatmas_remodelment_Taegu_federatively_languescent_Pan-asiaticism_nut-hook}',1,0),(199,'dctf1337{Spartacus_Alroi_molest_slave-grown_gnathion_pre-Darwinianism}',1,0),(200,'dctf1337{Heady_cislunar_sandyx_unmulled_skeletonic_polyoecious_chemicobiologic}',1,0),(201,'dctf1337{gastrodiaphanoscopy_afterwisdom_self-toning_slumber_dolorogenic_rivered}',1,0),(202,'dctf1337{overassertion_disabusing_urbainite_self-procured_sullages_appropriates_enharden}',1,0),(203,'dctf1337{reptiliousness_infestations_auspicate_counterequivalent_cyclones_kurn_reputeless_fuchsines_Stanfield_Merle}',1,0),(204,'dctf1337{algidity_presells_disrest_Usbeg_mahar_nibbing_Tetzel_silver-backed_brawniest_embankment}',1,0),(205,'dctf1337{Klossner_scrawnily_hypophysectomize_tessitura_Noxon_grousers_patrol\'s_dorsiflexor}',1,0),(206,'dctf1337{autothaumaturgist_vexillar_newfangledism_matrimonious_amel_antifelony_Sans_benchmen_panic-pale_bedquilts}',1,0),(207,'dctf1337{unregenerating_guardianly_mascaras_prestandardized_Vaidic_keyless_staffed_intendency}',1,0),(208,'dctf1337{litchi_saddlemaker_antimilitarist_Garett_Rudman_originator_forcipulate}',1,0),(209,'dctf1337{unrevelationize_crucians_ragwork_semilogical_pillion}',1,0),(210,'dctf1337{Lycia_incinerable_stiver_particularistically_soiree_Henning_tripinnatisect_haikun_clover-sick}',1,0),(211,'dctf1337{skys_Regina_solvolyze_precartilage_Justin_overstud_vawards_introductive_clayed_overambitiousness}',1,0),(212,'dctf1337{abada_superpetrous_unsecrecy_Okeene_electrosurgical}',1,0),(213,'dctf1337{bimillionaire_tegumental_quadriparous_dendrolite_hepatomas_communing_myoperitonitis_azans_best-natured_PCNFS}',1,0),(214,'dctf1337{thicken_coccy-_feigher_subvitalisation_self-undoing_Latimore_side-wheel_stereoradiograph_Tompion}',1,0),(215,'dctf1337{untransferring_hypogeous_uncommendable_armets_Sands_isotac_colporter_fluidrams}',1,0),(216,'dctf1337{clavier_fleay_quadrijugate_frowsiest_innavigable_Marquita_achigan_mutuum_dog-owning_Woodbourne}',1,0),(217,'dctf1337{reincluded_Balch_perfume_vitraux_sparrygrass_diakineses_pneumatography}',1,0),(218,'dctf1337{stalwartism_inducteous_Pycnocoma_Bastille_flourishable_polka-dot_pre-estimation_subediting_risotto}',1,0),(219,'dctf1337{hemerythrin_dilo_Suhail_psychro-_day-rule_praecornu}',1,0),(220,'dctf1337{malarias_sportive_antiphonal_osteopathist_undure_gluepot_rediscountable_postatrial_titbits}',1,0),(221,'dctf1337{skioring_self-consumed_agenesias_Ingvar_prebaptismal}',1,0),(222,'dctf1337{anthelae_surrogates_unprying_unspot_homagers_lounging}',1,0),(223,'dctf1337{unsecretively_Strohl_annals_Dagall_engrieve_Arapeshes_lulus}',1,0),(224,'dctf1337{Theseum_pennames_invertebral_divorcive_Dallapiccola_chroming_brothelry_arborolater_stomatose}',1,0),(225,'dctf1337{Gardenville_inordinateness_somdiel_Famechon_jackwood_Toxostoma_kishy_parisienne_outsnoring}',1,0),(226,'dctf1337{superfetated_eschewed_Earlville_foreprovided_weed-choked}',1,0),(227,'dctf1337{semiclassic_subdivide_Jewism_aphengoscope_disincrust_Hahn_propodium}',1,0),(228,'dctf1337{obstructors_Peshitta_Exocyclica_unsourly_Romanisation_micellar_samarskite_quadriparous_Ervine}',1,0),(229,'dctf1337{moot-house_ASHRAE_superethmoidal_automa_kingwoods_unperfidiously_Margarodes}',1,0),(230,'dctf1337{uncatalogued_hyperpathetically_scuddawn_Rathenau_budded_furfuration_rufofuscous_Vermes_oblast}',1,0),(231,'dctf1337{Sertularia_melopoeic_tow-feeder_airlike_cretoria_awee_bye-blow_butyrin_epitrichial_dimouts}',1,0),(232,'dctf1337{machiavellist_spoonhutch_visionlike_semipoisonous_Kahlua_invader_intransigentist_homeoplasia}',1,0),(233,'dctf1337{anted_skivvied_undersea_hypothecater_Keisling_Communist}',1,0),(234,'dctf1337{rootstalk_pardons_lawsone_fragrantness_effeminising}',1,0),(235,'dctf1337{Oklahoma_metallify_hogget_stroboscopical_cypraeiform_intertwisted_permoralize_tubulostriato}',1,0),(236,'dctf1337{supplements_ovations_ray-lit_profaners_blusteringly}',1,0),(237,'dctf1337{glyc_butterbush_Konyak_symbiontic_Tagassuidae}',1,0),(238,'dctf1337{intratubular_man-forked_sourcake_capsulotome_Kyurin_cathepsin_Danegeld_interconnections_herd-boy_kotowing}',1,0),(239,'dctf1337{doddy_apologiae_presbyterated_foot-up_Wiltshire_undertraded_storkling_outpaint_preimagining_unspeed}',1,0),(240,'dctf1337{skirling_succesful_unflurried_Azar_quinquepetaloid}',1,0),(241,'dctf1337{brusquer_cattie_chimble_stabbed_Peatroy_unsufficed_Pamphylia_bloomeries_introductorily}',1,0),(242,'dctf1337{transliteration_nongrievousness_Lucey_lavy_asternia_salmonids_beckelite_clumsinesses}',1,0),(243,'dctf1337{imidic_Ibby_snow-drifted_parochially_hydroscopicity_debates_nonreflectively_dispulp_stillest}',1,0),(244,'dctf1337{unnavigableness_petit-maltre_novelist_intaxable_verisimilar_unbudged_so-forth}',1,0),(245,'dctf1337{hipbones_Resnais_bicollaterality_bottle-nosed_bloody-eyed_memoried_grafters}',1,0),(246,'dctf1337{supererogate_misallotted_unflauntingly_baaskaap_actuaries_hurtlessness_unloosening}',1,0),(247,'dctf1337{academicianship_troth-contracted_Semi-pythagorean_belltopperdom_congresses_indiscrete_brass-tipped}',1,0),(248,'dctf1337{tenebrousness_board-school_variously_pioury_vocoid_stringiest_supernationally}',1,0),(249,'dctf1337{Scopas_aquatic_antimonarchism_iron-grey_ornitho-}',1,0),(250,'dctf1337{severedly_chalcedonous_double-space_nucleohyaloplasm_stroboscopy_barrat}',1,0),(251,'dctf1337{tarring_powder-monkey_Rhynchocephali_backlogged_urbanity_redoubler}',1,0),(252,'dctf1337{coenoblastic_Dickeyville_hircine_glycosaemia_recollapse_rampaciously_Querciflorae_poppyfish}',1,0),(253,'dctf1337{missingly_engraffing_embays_polyphyllous_curvaceous_tetrapyrenous_scorepad_ozonization_paper-testing_phthalan}',1,0),(254,'dctf1337{uncourageousness_humuses_vest_darbukka_epopoean}',1,0),(255,'dctf1337{unbating_Qum_overnegligentness_postarticular_well-kept_Jacqueline_sagoweer_mafiosi}',1,0),(256,'dctf1337{superingeniousness_trimesinic_thermonuclear_same-minded_unconstruable_gemmuliferous_Padus_postpose}',1,0),(257,'dctf1337{viands_vestry_microvolt_image-maker_Machicui_dickcissel}',1,0),(258,'dctf1337{goal_haven\'s_postcarotid_self-effacing_spellcasting_smallclothes_abietic}',1,0),(259,'dctf1337{hookahs_Colymbidae_bountiousness_over-liberal_regaled}',1,0),(260,'dctf1337{Nemorensian_chowsing_barpost_Appel_Pentheam_frizes_factionalisms_ecospecies_excitant_anticonfederationism}',1,0),(261,'dctf1337{MTTFF_glomeli_Pyrodine_undyeable_characinoid_Jesuitish_Rourke}',1,0),(262,'dctf1337{Verden_neighborlinesses_embordered_LCI_gonophoric_unwonder_patricianhood}',1,0),(263,'dctf1337{eluviating_undevastatingly_Saururae_toxic-_overdiverseness_jelliedness_beastings_lassoes_Epstein_plumification}',1,0),(264,'dctf1337{self-scorn_telo-_stenographist_Maytown_vasomotoric_CART_kiss-off}',1,0),(265,'dctf1337{tight-clenched_surprinting_kashima_yeller_nondiametral_unovervalued_briolette_Czechoslovak_major-domoship_beatings}',1,0),(266,'dctf1337{vine-growing_trashiness_unbrave_intercorporate_temerous_pph_McClusky_substantious}',1,0),(267,'dctf1337{drumming_mouthily_Baconianism_blessings_arbacin_vibratos}',1,0),(268,'dctf1337{peristalses_Woodbridge_skimpiest_Luthersburg_nonillusive}',1,0),(269,'dctf1337{folie_ellops_bebait_air-drawn_Golter_inchoacy_troutlike}',1,0),(270,'dctf1337{reincrudate_plasmoquine_dervish_titanothere_Tepper_Pascual}',1,0),(271,'dctf1337{agonies_merbromin_ammonify_thickety_zeal-inspiring_pervagate}',1,0),(272,'dctf1337{card-carrying_Barksdale_Samal_repaginated_so-formed_Dmitrov_plaustral}',1,0),(273,'dctf1337{Billmyre_semiglobose_breast-feeding_grasswards_noncontinuousness}',1,0),(274,'dctf1337{Europeanise_biscot_anoure_ushering_no-par-value_stumpers_symposiac_dispropriate_methylals_slatifying}',1,0),(275,'dctf1337{Giule_decasualize_phantasmagorian_tracheotomized_toran_stabilivolt_Crossroads_mormyrian}',1,0),(276,'dctf1337{membraned_unimbellished_upper-grade_wild-aimed_sherlocks_availableness_bousy}',1,0),(277,'dctf1337{collidin_organogenetic_epimerum_tartufishly_conceptions_resurveying_asarone}',1,0),(278,'dctf1337{solidate_thermantic_cemetery\'s_dactyliographer_humorize_stark-false_bloodhound\'s_Balaenoidea_contrapuntal_Milman}',1,0),(279,'dctf1337{Dacelo_catchwork_fluosilicic_vendues_nonepigrammatic_routinizes}',1,0),(280,'dctf1337{exaggerators_biosatellites_lunted_cortisols_Gymnolaema_XTC}',1,0),(281,'dctf1337{outknave_macrodomatic_hetaeras_hydrates_pyopneumoperitoneum}',1,0),(282,'dctf1337{lungy_twice-counted_Half-english_OTHB_unembezzled_tired-headed_overplease_waistbands_percentable}',1,0),(283,'dctf1337{recapitulative_Ephedraceae_subnodal_Bacillariales_sfz_armillated_ungilled}',1,0),(284,'dctf1337{paleokinetic_changeful_impropitious_oldfangledness_valebant}',1,0),(285,'dctf1337{semigravel_joual_archontate_Jap_Myxospongiae_vitriolating}',1,0),(286,'dctf1337{honeys_synedrous_vacciniola_skewback_iratest_monopitch_cure_Grosz_circumjacencies_hyperenthusiastically}',1,0),(287,'dctf1337{hippometry_brightening_daintier_periodontology_Sphaerocarpus_overmonopolized_traducer_retrain}',1,0),(288,'dctf1337{fowlery_dissections_Abaddon_tumefy_nitidous_venisuture}',1,0),(289,'dctf1337{Iloko_present-minded_weretiger_re-proven_reperceived_semiallegiance_parecism_layloc}',1,0),(290,'dctf1337{Anders_acrobatholithic_Hastings-on-Hudson_expediteness_reembroider_grandads}',1,0),(291,'dctf1337{beetroot_Neal_tractor_encroaches_debater_mitigate_Rhne}',1,0),(292,'dctf1337{outrant_randiness_quantitation_uncubical_unmedalled_precenting_spared}',1,0),(293,'dctf1337{several-celled_comprizes_Ophiurida_Tetradecapoda_prehandled_spectate}',1,0),(294,'dctf1337{unwhiglike_dynamitic_AET_clarigold_rufosity_stampedo}',1,0),(295,'dctf1337{aviating_unfanatically_unjudiciousness_assessor_Purkinje_garrotting}',1,0),(296,'dctf1337{lehrs_Heroides_nonfimbriate_midpoints_photophobe}',1,0),(297,'dctf1337{sensuous_strappers_nonreader_ear-rending_nobbles_fibrinogenous_quasi-pledging}',1,0),(298,'dctf1337{moisture-resisting_Trygonidae_interments_celibatic_radiologically_untapped_Oswald_sampans}',1,0),(299,'dctf1337{barbitals_tuitional_folly-maddened_ripoffs_aegeriid_lentisco_unglibly_overlinked}',1,0),(300,'dctf1337{Shellans_fuddy-duddies_sea-cut_Ochozath_tango_heterodoxness_salt-cat_forepart_Dickson}',1,0),(301,'dctf1337{witchhood_minting_penitently_Cloelia_geochronology_sour-breathed_paraphs_delit_Pa.}',1,0),(302,'dctf1337{luminesced_philologian_Pro-gentile_subhypothesis_cheslep_nucleotide\'s_Recor_Saudi_cholecystolithiasis}',1,0),(303,'dctf1337{Democratic-republican_adv_nondruidical_thin-leaved_Clitus_twice-deserved_tatty-peelin}',1,0),(304,'dctf1337{landammann_dacryocystalgia_nondialectic_unmeedful_self-opiniativeness_relevancy_calcifications_deflocculating_contests}',1,0),(305,'dctf1337{chylification_erke_carotinemia_Bukhara_insular_ballooning_praelector}',1,0),(306,'dctf1337{superheroically_hyperbolized_unfervent_shoeshine_moulrush_balat_hypercholesterolemic}',1,0),(307,'dctf1337{predicatory_clairecolle_Ullur_engr_world-educating}',1,0),(308,'dctf1337{unhereditary_wonga-wonga_MELD_gas-charged_Lucernariidae_Fieldon_heptite_trionychid}',1,0),(309,'dctf1337{vouge_quandaries_freq_Forli_pyridinize_semi-instinctive_tutu_readdressed_unchanced_stringendo}',1,0),(310,'dctf1337{virgulate_magnet_cardiodysesthesia_facioscapulohumeral_scouther_coppas_edge-bone}',1,0),(311,'dctf1337{Elvine_ultraorthodox_wood-planing_Mindanao_tiffing}',1,0),(312,'dctf1337{dust-throwing_fanatical_propenyl_semiphosphorescent_revisit_unrip_toto-_septocylindrical_trimeride}',1,0),(313,'dctf1337{hawkmoth_tocherless_belace_glycohaemia_cultivatability_visionarily_drosophilae_cut-leaf}',1,0),(314,'dctf1337{microsplanchnic_Samhain_wannest_long-rooted_rettorn_bellyman}',1,0),(315,'dctf1337{ween_uneffigiated_tautologized_woodpecker_sassiest_heme_hedging-in}',1,0),(316,'dctf1337{unfadable_bibliothecary_condyloid_filtrability_Gorman_ribandry_Ja._unliberal_larixin}',1,0),(317,'dctf1337{tolter_chromaphil_teachers_tinged_sclaff_unspoilableness_nonsancties_Farwell_all-sacred_propense}',1,0),(318,'dctf1337{munity_intertransversal_Olpidium_nuptialize_xanthopsydracia}',1,0),(319,'dctf1337{Lydian_superaffluent_russeting_sceptring_Cirenaica_presupplemental}',1,0),(320,'dctf1337{bavenite_doorhawk_chartroom_pseudoascetically_darndests_Procellariiformes_cobhouse_Lycodes}',1,0),(321,'dctf1337{Humiriaceae_woodenware_aseismic_yockel_Quackenbush_manganosite_IOD_reassemblage}',1,0),(322,'dctf1337{catharizing_nonvortically_mealywing_bulbed_Megalobatrachus_pizzeria_beamfilling}',1,0),(323,'dctf1337{dead-weight_strinkle_laparogastroscopy_asweve_Florinda_wire-sewn_cowcatcher_ovulist_echnida_anemometrically}',1,0),(324,'dctf1337{bultow_collegians_unadorably_autograft_tzarevitch}',1,0),(325,'dctf1337{prototype_exiling_Vanni_regurge_thermocouple_upbears_pathologists_deceivable_proclivity\'s_exhibits}',1,0),(326,'dctf1337{spored_Alten_inogenic_citadel\'s_three-seeded_divorcing_mahatmaism_turr}',1,0),(327,'dctf1337{zoogeog_half-convinced_interzooecial_machinability_sennights}',1,0),(328,'dctf1337{Haily_sutlership_chloridized_validated_molests_outprays_Forl_venial_retime}',1,0),(329,'dctf1337{sherif_chomp_potgun_shimper_nonegoistical_element_aerification}',1,0),(330,'dctf1337{ambition\'s_Cannock_Tyan-Shan_ritus_ticking_preestablishes_shebeen_knurls_macromolecular}',1,0),(331,'dctf1337{milammeter_world-overcoming_blinky_sheitlen_Germanistic_repetends}',1,0),(332,'dctf1337{well-concluded_overfrailty_royalized_ultimogeniture_kotylos_releasibility_pint-sized}',1,0),(333,'dctf1337{denarinarii_Chinamen_redecimate_pneumotyphus_dermatogen_ungraduating_pimelic_cormels_internuncios_meadowland}',1,0),(334,'dctf1337{Encyrtidae_Kinny_semicultivated_Daedalian_rosarian_isonephelic_Eudemian}',1,0),(335,'dctf1337{researchable_ungual_obelised_hercynite_inerrant_kiddie}',1,0),(336,'dctf1337{parcel-tying_acuminous_sofkee_unwistful_naphthas_provability_eye-pit_rhodocyte}',1,0),(337,'dctf1337{stone-lined_unshuttered_improvingly_skatiku_vestries_Whiteboy}',1,0),(338,'dctf1337{textuaries_ureteroenteric_stockstone_owlism_well-encountered_unearths_Freyre_cheekier_potamogetonaceous}',1,0),(339,'dctf1337{gipseian_prim-lipped_albuminofibrin_sleaves_undivable_maidishness_fumigate_pommies_disobeyed_Malina}',1,0),(340,'dctf1337{Hyrmina_panclastite_presspack_reaccost_Northumberland}',1,0),(341,'dctf1337{undignified_slow-sailing_bibliographize_unasked_Ribston_accend_copalite}',1,0),(342,'dctf1337{wanderings_Canichana_Poth_surnai_servicemen_planky_bald-headed_Tigrean_canvassed_left-wing}',1,0),(343,'dctf1337{Aylesbury_scramblebrained_picketer_circumsession_pacas_overmobilizing_farmhands}',1,0),(344,'dctf1337{tun_lithoclasty_AOPA_kammina_anniversary\'s}',1,0),(345,'dctf1337{lipin_mythologema_couche_substantiates_world-supporting}',1,0),(346,'dctf1337{washwork_Laotze_journal_Wallach_dustiest_sanctimoniousness_ceratophyllaceous_krennerite_novillero}',1,0),(347,'dctf1337{bergeret_Glennallen_trisected_detraction_hurrer_adital_smoke-drying_gour_redressable}',1,0),(348,'dctf1337{paramyoclonus_unlibeled_untrusses_rectostomy_cosmozoic_unicum_Pro-moroccan_unsplit}',1,0),(349,'dctf1337{housage_Amatruda_tabuliform_perthophyte_untrickable_nibby-jibby}',1,0),(350,'dctf1337{unjelled_clench_quercin_unquellable_bibelots}',1,0),(351,'dctf1337{edible_vacant-brained_jihads_nondispersive_ratanhia_psychogenetics}',1,0),(352,'dctf1337{astrologies_previolating_unguardedness_echoist_Helladian}',1,0),(353,'dctf1337{all-arranging_buzzardly_northering_twice-given_UAPDU_postcolon}',1,0),(354,'dctf1337{Paleolithic_Philine_ill-won_aulophobia_cryoconite_Hillcrest_uncarboned_cloam_self-reduplication_chartroom}',1,0),(355,'dctf1337{Hasinai_strayers_wide-open_bogginess_nitric_emblanch_sulphamerazine}',1,0),(356,'dctf1337{maxillipede_muntz_calinda_ideality_chaplaincies}',1,0),(357,'dctf1337{satined_csk_serialization\'s_noninterchangeableness_recelebrate_conidium}',1,0),(358,'dctf1337{weta_fictitiousness_begiggle_archoptoma_fibrilliferous}',1,0),(359,'dctf1337{kulaite_innocence_scatter-brain_chalkotheke_bowse}',1,0),(360,'dctf1337{Ellington_precaria_emblemizing_heptarchal_myxedematoid_water-hen}',1,0),(361,'dctf1337{Fredericks_uncollusive_dechlorinate_reingratiate_afterthought_Pan-sclavist_palmellaceous}',1,0),(362,'dctf1337{ultraemphasis_prophet-preacher_tauntingness_braining_unsentimentalised_feedbin_WBS_altininck}',1,0),(363,'dctf1337{medialization_implanted_unearthing_noised_recessively_trustiness_weathery}',1,0),(364,'dctf1337{silverleaves_filigraned_bogled_unlabelled_monomastigate_reorientating_agnails_tach_abducted_Marcuse}',1,0),(365,'dctf1337{a-sudden_well-fledged_sedulously_plutomania_Andes_chancelry_eye-earnestly_she-king_path-_deuteromyosinose}',1,0),(366,'dctf1337{postmortal_wine-colored_estranges_gynandry_quatrocento_adversaria_surrept_danger-fearing}',1,0),(367,'dctf1337{sulphoamide_visaged_assesses_Choccolocco_Fabrienne_Fayette_signalist}',1,0),(368,'dctf1337{Conocarpus_Lanka_paving_Heliconiidae_bonaught_unfurnished}',1,0),(369,'dctf1337{Karlise_Kronfeld_keraci_Decaisnea_Gautier_dispeace_contractus_Galanti}',1,0),(370,'dctf1337{preannouncer_Lithodidae_majas_nullos_Themiste_inworn_matrace_billety_unthankfully_acerbating}',1,0),(371,'dctf1337{carinas_Shavese_ultramaximal_depender_newsreels}',1,0),(372,'dctf1337{terrifical_Schouten_snooting_Dromornis_pellotine_concisely_duckboard_prehensorial}',1,0),(373,'dctf1337{allotheistic_signable_Rosinski_avern_swelteringly}',1,0),(374,'dctf1337{untraversed_dogcart_scatter-brain_catechumenism_Ibrahim_well-penned}',1,0),(375,'dctf1337{noncompliances_premiere_unnotify_crotaphite_slakes_Kirkland}',1,0),(376,'dctf1337{nonconfining_scurfer_left-brained_Bozman_honorariums_Worlock}',1,0),(377,'dctf1337{linefeed_Hallam_unoptimistically_Strain_Sarcopsyllidae_high-flyer_lymphopoieses_heretoch_hangdog_finessed}',1,0),(378,'dctf1337{alkalizate_vaccinella_creosoted_fiberization_gabbiness_monoparesis}',1,0),(379,'dctf1337{applecart_Demetris_cnemic_unspotten_triploblastic_long-ribbed_thenage}',1,0),(380,'dctf1337{short-witted_pictures_Ronsardize_Roby_emphasis}',1,0),(381,'dctf1337{bathophobia_unrevealing_monochloride_Mayes_solarisms_grantable_rowport_bastard-saw_coomb}',1,0),(382,'dctf1337{Gravettian_epigean_capitaliser_assistant_intraoctave_muleback_crayonstone_untotted}',1,0),(383,'dctf1337{nonusers_complementizer_transcalent_retreatism_twaddledom}',1,0),(384,'dctf1337{washstand_contributory_predisposable_fluky_closed_sermonizer_ash-blond_menhaden_ultimatum}',1,0),(385,'dctf1337{documentations_soodle_unheart_cubocuneiform_reundercut_cystoma_jeers_Sherilyn}',1,0),(386,'dctf1337{Aerobacter_baignoire_fellers_peroxyl_staph_apocamphoric_batties_accentor_laquear}',1,0),(387,'dctf1337{underfortify_honors_alacriously_boullework_cystoureteritis_nonteaching_whussle}',1,0),(388,'dctf1337{Bourbonism_Branchiura_proexperiment_decursive_psychomonism_vaccinations_Colquitt_overpassionately_unnominal}',1,0),(389,'dctf1337{armrest_bunkerman_Calimeris_open-timber_intine_PRI_benthal_Permian_Roseanne_laissez-passer}',1,0),(390,'dctf1337{reoffend_co-ossification_eudaemonism_usances_instrumenting_oceanographic_accretes_raking_accessable}',1,0),(391,'dctf1337{processions_tryste_ovivorous_praeludium_trichophore_achromat-_chancelloress}',1,0),(392,'dctf1337{neifs_resembling_Sholley_first-preferred_sheather_halke_undersleeve_self-exclusion}',1,0),(393,'dctf1337{Oxly_nongolfer_mightyship_judicatory_malthas}',1,0),(394,'dctf1337{pamphletized_self-roofed_plurative_copartners_stargazing_semisocialism}',1,0),(395,'dctf1337{rooving_bulkish_complexometric_recooper_unmeasured_unentitled_Jeannine_semblative}',1,0),(396,'dctf1337{blandness_unrecognisable_quasi-exceptionally_hemstitch_moither}',1,0),(397,'dctf1337{kicker_crimper_imbursement_tetrasyllable_complexity}',1,0),(398,'dctf1337{Ethbun_abomine_Boas_agones_unprejudicial_worsening_crony_nonexhortatory_germs}',1,0),(399,'dctf1337{dislocatedness_Shaff_postmamillary_pain-free_lacerability_beau-pleader_countermovement_philippize_undishonored_cooperationist}',1,0),(400,'dctf1337{unburden_concocts_brainstorming_testicles_vice-guilty}',1,0),(401,'dctf1337{conjugato-palmate_angelomachy_Oakton_cantatrice_exhauster_Aloha_snowlike_saging_nondancer_unbenignity}',1,0),(402,'dctf1337{cached_pheochromocytoma_re-emergent_sweet-conditioned_swure_post-Talmudic_toper_kahala}',1,0),(403,'dctf1337{mooner_riziform_cordoban_cartels_lm/W_enjambments}',1,0),(404,'dctf1337{nonpresence_siderotechny_burnwood_Tartarization_Geithner}',1,0),(405,'dctf1337{quick-gushing_Gorham_vauntingly_bowwoman_tea-growing_ballweed_idee}',1,0),(406,'dctf1337{octopine_nonfermentable_expect_wind-dried_stencil_Epigonus_Negrotic_septendecillionth}',1,0),(407,'dctf1337{spindlelegs_moon-loved_plummets_nonlucrativeness_vergerism}',1,0),(408,'dctf1337{fellable_pseudo-urea_cocentric_Grissel_lowmen_melon-bulb}',1,0),(409,'dctf1337{subperitoneal_tetrazotization_inspector\'s_well-knowing_Rototiller_sea-hedgehog_diabology}',1,0),(410,'dctf1337{somnambule_Sib_Goodfield_Sihanouk_coemanate_muruxi_mangiest_Mahabharata_fusht}',1,0),(411,'dctf1337{Kubango_Bechuana_dyscrasic_sighters_interembraced_flavine_fastidiosity}',1,0),(412,'dctf1337{strophomenoid_Septemberist_Dadoxylon_nondefining_solecizing_Septemberer_pantalan_accessable_Zech}',1,0),(413,'dctf1337{Ausonius_hygrostomia_Drisko_blossom-bordered_time-lasting_deindustrialization_applesauce_dusters}',1,0),(414,'dctf1337{dithalous_eight-hour_opposit_fumariaceous_corrivate_Spongiidae_self-adorned_wheeped}',1,0),(415,'dctf1337{strophiole_wisdomproof_Ferrari_confider_usings}',1,0),(416,'dctf1337{run-around_nicotines_longbow_nonrioter_preinstructing_calendas_fetialis}',1,0),(417,'dctf1337{hundreder_decisteres_pumicers_maudlinness_drove_Bramantip}',1,0),(418,'dctf1337{examinership_fabella_jiboya_polymorphonuclear_runrounds}',1,0),(419,'dctf1337{self-complacently_concession_ecrustaceous_Lingwood_quotum_executant_leptospirosis_punyish_tumblerwise}',1,0),(420,'dctf1337{Blakeley_Philistinic_bolded_offscum_musclemen_Philoctetes}',1,0),(421,'dctf1337{Colesburg_chemoreceptive_God-sped_kaikara_Tenniel_installers}',1,0),(422,'dctf1337{Hospitaler_Kolk_loose-enrobed_topi_celioncus_packhorses_stragglers_subdue_valleylet}',1,0),(423,'dctf1337{creme_acetol_quasi-automatic_properitoneal_tissued}',1,0),(424,'dctf1337{unstimulative_jaygees_castory_synoecious_phenobarbital_H.I._uranin_benchboard}',1,0),(425,'dctf1337{chits_nymphet_Helbonnah_visoring_gamesome_prideweed_roentgenometries}',1,0),(426,'dctf1337{jacconot_undandiacal_smalto_physiotherapeutics_espringal}',1,0),(427,'dctf1337{Reki_semianatomical_chinked_spirit-boiling_doat_bielectrolysis_pavanne_acetates_redamaged_Yee}',1,0),(428,'dctf1337{clupeoid_orientalized_bacteriosolvent_Henke_Hippotigris_politico-social_Englify_linkedit_phonophorous_stemmatous}',1,0),(429,'dctf1337{smoke-bleared_unabolished_Pertusaria_nonreimbursement_refell}',1,0),(430,'dctf1337{oukia_messman_levolactic_molly-coddle_Colen_behammer_kench_ramigerous}',1,0),(431,'dctf1337{cloud-crossed_rewedded_braxies_dismarshall_angiopoietic_spinous-leaved}',1,0),(432,'dctf1337{wizzens_Nativity_tree-toad_identifications_unsustained_possiblest}',1,0),(433,'dctf1337{continuancy_harelipped_metopion_boers_drawback\'s_legrope_aquarial}',1,0),(434,'dctf1337{Listeria_Ligustrum_Machaerus_volatilisation_Cursa}',1,0),(435,'dctf1337{gymkhanas_enjambed_bhavan_anti-Freud_inconstantly_gleefully_aerocar_metageometry_SIMM}',1,0),(436,'dctf1337{chrisoms_unprefigured_relaunch_sinder_amphimictically_chromaturia_intercalary_unexculpated_duplication}',1,0),(437,'dctf1337{Maregos_papyrographer_Stephen_hay-colored_warly_radiolucency_passkeys_premixer_incompared_stupefactions}',1,0),(438,'dctf1337{exercise_Amite_jibba_light-bounding_peaker}',1,0),(439,'dctf1337{crimine_Overijssel_konked_unniggardly_umber-black_demonstrableness_NJ}',1,0),(440,'dctf1337{momme_stumpily_enkolpion_hyomandibula_undaringly_Tyrannides_skeletogenous_nontraversable_moodier}',1,0),(441,'dctf1337{trophonucleus_Gorgonacea_polyspast_cufflinks_muslins_thyroantitoxin}',1,0),(442,'dctf1337{westwork_tangental_Wycoff_gradatory_microlite_newtonite_hyperbrutally_solifluctional}',1,0),(443,'dctf1337{thin-rinded_overextend_subumbrellar_single-sheaved_eremiteship_dissemble_plumply_barlock_precedential_drug-using}',1,0),(444,'dctf1337{chandu_countermeasure_miniaceous_protectorian_telegram\'s_adscripted}',1,0),(445,'dctf1337{trunk\'s_thalassographic_metastable_ultrafeudal_nonfaculty_four-stringed_Michell_nonair_malady\'s_quasi-militaristic}',1,0),(446,'dctf1337{lupines_beliefs_ringed_blooded_apoquinine_tracklessness_bastardize_treadboard_soiledness_silkalene}',1,0),(447,'dctf1337{deplorableness_gentleman-agent_cupmaking_rubbing-stone_scuttling}',1,0),(448,'dctf1337{Animalivora_puberties_Budennovsk_squamosoparietal_enp-_irregulous_torrid_embroidered_theonomy_monadnock}',1,0),(449,'dctf1337{octene_dghaisa_Whipholt_rect._amidogen_cigarette-smoker_teamwise_pyelograph_many-stemmed}',1,0),(450,'dctf1337{shortness_rogations_immateriate_unenlivened_amentum_youthhead_picojoule_outsailed}',1,0),(451,'dctf1337{Arkwright_Leavelle_intrusion\'s_tougher_tautonyms_Fronde_vestigially_telencephala_buscarl_pesa}',1,0),(452,'dctf1337{Laestrygonians_diploblastic_eelshop_automatictacessing_rite\'s_square-bladed_spicousness_addedly}',1,0),(453,'dctf1337{salification_micropodal_senoufo_featherway_unstabilised_disparadise_unheathen}',1,0),(454,'dctf1337{astigmatical_podos_strandward_filicinian_viviparous_wortworm_anviltop}',1,0),(455,'dctf1337{Swedenborgism_pseudoprophetical_noneconomies_crumblet_Affra_homogeneousnesses_epilogized_maffias_cressed_theatrophobia}',1,0),(456,'dctf1337{irid-_fraternation_ichnolite_samaroid_fourposters_curiage_zipping_afreets_cutter-out_euphoniously}',1,0),(457,'dctf1337{alga_enneasepalous_unmews_jerseys_weird-fixed_ethnographic_creepmouse_Kephallenia_prelude\'s_Leif}',1,0),(458,'dctf1337{cast-by_teach-in_silkweed_Emydosauria_testimonializer}',1,0),(459,'dctf1337{pinnas_paillasse_retan_porch_exploded_talabon_preterite-present_coenoby}',1,0),(460,'dctf1337{Nectariniidae_pot-valliance_three-dayed_OE_Zellerbach_Halleck_Hugues}',1,0),(461,'dctf1337{superaccurateness_herehence_catelectrode_cassandras_crepitated_Mullane_swooner_venefic_superinference}',1,0),(462,'dctf1337{lithophagous_Ulphia_pre-enlightening_shepherdhood_Grimesland}',1,0),(463,'dctf1337{unrenowned_raveningly_entangle_theropod_MNS}',1,0),(464,'dctf1337{dormilona_inebriations_sober-blooded_inadvisableness_lissom_refortifies}',1,0),(465,'dctf1337{myristicivorous_impoliticalness_glaucodote_manarvel_intermingles_hammal_Otyak_dereliction}',1,0),(466,'dctf1337{specifies_arm-linked_cypresses_reassemblies_litigiousnesses_quadrigae_preseeing}',1,0),(467,'dctf1337{sternnesses_kl_Gradgrindism_conspiratory_trainload_V.W._franciscans_Ivana}',1,0),(468,'dctf1337{eyeletted_semi-industrially_areosystyle_untellable_stopway_uninterlarded_wheelworks_nonresonant_Brandice}',1,0),(469,'dctf1337{sematology_pendular_interimist_survivalism_bifistular_irenics_honey-stone}',1,0),(470,'dctf1337{anticathexis_anatomise_Hungary_subprofitable_Fadeyev_nudest}',1,0),(471,'dctf1337{thirteenth_pingrasses_taboparalysis_cantor\'s_epiphytal_sequest_heliomicrometer_polysensuousness_catawampus}',1,0),(472,'dctf1337{valhall_overstoring_mesaticephalous_interpenetrative_miching_Gerdye_myxedemas}',1,0),(473,'dctf1337{semmet_Vestaburg_Maskoi_prenodal_Bergen}',1,0),(474,'dctf1337{anticeremonially_sheiks_rimy_overlavishly_Clift_mezzograph}',1,0),(475,'dctf1337{well-harnessed_Peking_bibber_basifies_transcend_fizgig_staphyle}',1,0),(476,'dctf1337{bibliophobia_deashes_pursuit_bronchiole_Romney_NCCF_unviolent_codicillary_unrecoverably}',1,0),(477,'dctf1337{Ellata_furison_boloball_baked_fodder_dun-colored_clearness_kon_Candi}',1,0),(478,'dctf1337{prethoughtful_ankles_amazement_argument\'s_classiness_Molena_self-impedance_iron-handed_Ocilla_Pleurotus}',1,0),(479,'dctf1337{midsts_anchorets_darksum_Muse-inspired_refinements_droll_free-denizen_long-stalked}',1,0),(480,'dctf1337{postcaval_canephoroi_pseudohistoric_thankfully_straitsmen_riteless_Manon}',1,0),(481,'dctf1337{arcato_monotheisms_scientize_beseechment_discolor_literalizing}',1,0),(482,'dctf1337{disease-spreading_cairn-headed_condite_hand-printing_unaiming_ponderate_narrowest_Reeseville}',1,0),(483,'dctf1337{sloopman_aerohydrotherapy_hallali_volplanist_precipitation}',1,0),(484,'dctf1337{whipstick_logographer_noncovetously_Janiculan_signalities}',1,0),(485,'dctf1337{Lilia_gastrotomic_phany_tarradiddler_nonexhaustible_hocused_entities_outking_oxidable}',1,0),(486,'dctf1337{self-debasement_hoax_saltily_TM_Marinist_onager_appressor}',1,0),(487,'dctf1337{dowcote_Ailis_undersprout_unregressively_triangulate_Calamagrostis}',1,0),(488,'dctf1337{Godey_splanchnodynia_tryma_exuviable_daddled_moderns_mythologizing_Belsky_platier}',1,0),(489,'dctf1337{saveloys_shigram_fretless_cyclotomies_upbearer_deafeningly_familiarness_simpletonic}',1,0),(490,'dctf1337{Aquone_wrong-timed_festooned_requisitory_akepiros_kibbling_playgrounds_disannuller_mercurous_zygomas}',1,0),(491,'dctf1337{unrobbed_trigynous_featherbird_teres_Adrastus_potassic}',1,0),(492,'dctf1337{palewise_nectophore_uncoiling_concredit_ruler}',1,0),(493,'dctf1337{awes_butylated_CUSO_destructors_raisons_cooncan}',1,0),(494,'dctf1337{Wende_recrating_sennachie_periodic_Meece_enamelist}',1,0),(495,'dctf1337{nondiabetic_maint_furzier_trim-suited_diazid}',1,0),(496,'dctf1337{gliss_timar_intumescing_Nipissing_vespers_centralizers_geishas_templelike}',1,0),(497,'dctf1337{pantomnesic_bachelorhoods_Timmy_dessert\'s_collaborations_charkas_corynine_well-groomedness_frisked_cantors}',1,0),(498,'dctf1337{illations_Coire_two-pound_gambang_Jervis}',1,0),(499,'dctf1337{cross-examine_publications_hospitalism_king-pin_ammonocarbonic_flated_recriminate_immingling_ulatrophy}',1,0),(500,'dctf1337{Quashee_minitheaters_prasophagous_overfavorableness_God-forgetting}',1,0),(501,'dctf1337{exotery_bringed_metallide_bonemeal_Sogdianian_Muskogean}',1,0),(502,'dctf1337{blindcat_endermatic_barbell_alertnesses_coenamor_cocaines_precontemplated_extraregarding}',1,0),(503,'dctf1337{minsitive_skeppe_agriot_sithen_nullibiety_redback_conveyal}',1,0),(504,'dctf1337{proabolition_flexanimous_cylinder-dried_Anguidae_outdances_misserve_Lafleur_casque}',1,0),(505,'dctf1337{prespurring_Thesium_interknotting_Valletta_superheated_Monahans_haversine_unlimbered_epiderma}',1,0),(506,'dctf1337{paizing_dun-brown_heteroxenous_nombril_atrociously_axoneuron_womanhood_livers_MBWA_aldoheptose}',1,0),(507,'dctf1337{atomiferous_hypersophistication_shouter_Tenonian_circumantarctic_raptors_nonresponsibleness_Maurist_disproof_subinoculation}',1,0),(508,'dctf1337{Crinum_bunyah_Zeelander_lightboat_self-drown_subblock_damnified}',1,0),(509,'dctf1337{torturous_Pinchas_preglacial_gypsy-like_cabaho_housling_ladings}',1,0),(510,'dctf1337{quasi-fatally_big-gaited_praise-fed_spiranthic_incense-breathing_vivifiers}',1,0),(511,'dctf1337{panga_Ahmedabad_uninweaved_raw-wool_mouth-watering_owl-haunted_Halitheriidae_underbevelling}',1,0),(512,'dctf1337{afore-mentioned_posteriori_khulda_soul-infused_pseudodoxy_headmen_veredicto_sophomorically_leodicid}',1,0),(513,'dctf1337{orbitopalpebral_Praxithea_Berengaria_blurter_sanguification_unrecumbently_impressive_exchanges_meminna}',1,0),(514,'dctf1337{sin-concealing_ascertains_encyclopediac_hygrometers_evoking_inequidistant_banded_nonstock_goosetongue}',1,0),(515,'dctf1337{microluces_Pupillidae_water-living_calligrapha_meadowless_coccin}',1,0),(516,'dctf1337{stickboat_stative_intermeet_Dylana_Redig_unbeached}',1,0),(517,'dctf1337{fathoms_februation_Galium_nonhandicap_rubious_scrapmonger}',1,0),(518,'dctf1337{bolometer_dolefully_payout_asterospondylic_tilting_ringdoves_philomels_exertion_nicotize_Marjie}',1,0),(519,'dctf1337{Sabah_pshaws_halvahs_chance-hit_bootloader_refinedly_Zionward}',1,0),(520,'dctf1337{Pro-sardinian_neuraxis_Marcellian_unreposefully_hard-favouredness}',1,0),(521,'dctf1337{Acemetae_Mechelen_emittent_Kuska_Apachette_lyrism_Taxidea_garboil_spilly}',1,0),(522,'dctf1337{adelphic_gelatinising_unmooring_bariatrician_unnicely_well-scattered}',1,0),(523,'dctf1337{nota_categorem_dished_uplanders_pigout_topic_cuspidation_methoxide_pulmonectomy_Neo-Hegelianism}',1,0),(524,'dctf1337{fireweed_irresuscitable_heteros_trapezoidiform_Kansan_imambara_nuttery_Post-leibnitzian_spiceberries_revisionists}',1,0),(525,'dctf1337{Petromyzontes_compass_dandification_eyedropper_preintercession_twilight-loving}',1,0),(526,'dctf1337{inconfirmed_planographic_diesel-engined_duckbill_lugsail}',1,0),(527,'dctf1337{Hanksville_latices_azole_prerogative\'s_gypsy-like_rend_Brauronia_one-layered_literatist_Harunobu}',1,0),(528,'dctf1337{Kwapa_festinating_copper-leaf_garlopa_mailless_Chanhassen_acleistous_nescient_sphere-filled_Ramillie}',1,0),(529,'dctf1337{Archeptolemus_overdiscouraged_synomosy_Coleridge-Taylor_plenity_orbity_camsteary}',1,0),(530,'dctf1337{graphemes_yellower_delocalised_cardamom_possibilist_Equisetaceae_shood}',1,0),(531,'dctf1337{unmagnetic_Delmore_Physoclisti_kalians_phytochemistry_foreknows_nongraduation}',1,0),(532,'dctf1337{mankilling_monochloroacetic_pyrenin_all-depending_blousons_depair_armsful_pointways_conflation_mannerize}',1,0),(533,'dctf1337{pteraspid_extracellularly_paraquats_Guttiferae_redemonstrating_berakot_unauspiciously_preindication}',1,0),(534,'dctf1337{malady_akaroa_Christine_hexanitrodiphenylamine_cytisine_Djilas_Siegbahn_beautyship}',1,0),(535,'dctf1337{uncoy_unquit_VT_infamia_Zerubbabel_catalyzers_periphacitis_reorganise_Heteromya}',1,0),(536,'dctf1337{overweaponed_unwalkable_Gabunese_blepharosphincterectomy_snifting_a-stay_plumose_agonothete_unfoughten_angiectopia}',1,0),(537,'dctf1337{rebukefully_spheroidal_antipolitical_ingemination_ransackers_workouts_asynchronously}',1,0),(538,'dctf1337{Orferd_cubocalcaneal_battlefields_Psychean_impermeability_schola}',1,0),(539,'dctf1337{unamusably_orogenesis_Dyersburg_granola_expositively_watermen_perseveringly_reafforestation}',1,0),(540,'dctf1337{pseudococtate_dolours_near-adjoining_pressingly_Polybus_Krispin_Ratcliffe_haggeis_overservileness_coextensiveness}',1,0),(541,'dctf1337{hosepipe_morbose_underabyss_Haringey_snapper\'s_nails_Thomasville_Cressler}',1,0),(542,'dctf1337{hallmarks_diacetin_openmouthedness_unrelentable_nulled_waylaying_swinehead}',1,0),(543,'dctf1337{oneirocritical_imbittered_hemisymmetry_endocrinopathy_Idelia_mashrebeeyah}',1,0),(544,'dctf1337{Eberle_nettlesome_zimmy_monotonically_lithi_gallicolous_eudemonistical_Grae_vizzy}',1,0),(545,'dctf1337{torvous_toponymic_dittoing_Gonvick_midewiwin_Cynarra_anquera}',1,0),(546,'dctf1337{Quakership_voltinism_protosaurian_azilut_seditious_desireless_dithers_Boito_Necturidae_nonprogrammable}',1,0),(547,'dctf1337{normatively_Puinavi_Emesa_oraculum_paraesthesia_Charron_hypopselaphesia_weep_hooraying}',1,0),(548,'dctf1337{broodily_widowlike_compartmentalization_eimer_BSMet_Semiramize}',1,0),(549,'dctf1337{cofreighter_claudetite_much-engrossed_supercolumniation_crut_classed_ammoniacum}',1,0),(550,'dctf1337{trended_Krein_valuators_gentlewomanliness_flavescence_escopeta_cenospecies}',1,0),(551,'dctf1337{Pedro_impiousness_cawl_affectingly_peopler_sandgoby_medifixed_nonunions_foh}',1,0),(552,'dctf1337{decemuiri_anukabiet_well-screened_goodly_Stephenie_infeeble}',1,0),(553,'dctf1337{Landingville_autoinhibited_heterocyclic_thatchwood_Rocker_subalterns_thalamencephala_fabricative_spurreies_coronachs}',1,0),(554,'dctf1337{dadoing_bawdry_persuasive_nightwalkers_intralaryngeally_flixweed_Luckey_pacts_Sasserides_trifurcation}',1,0),(555,'dctf1337{dwells_templeful_onchocerciasis_nonconstructively_fertileness_knocker_consectary_mediastino-pericarditis_workbook\'s_imprests}',1,0),(556,'dctf1337{Barthol_cohabitant_ecocidal_precedential_adiactinic_foredays_anticoagulating_garnishee_tolan}',1,0),(557,'dctf1337{nonapportionable_hard-plucked_pataque_Tsiranana_lidderon}',1,0),(558,'dctf1337{free-bored_suprahistorical_burial-place_pars_pampharmacon_Gracia}',1,0),(559,'dctf1337{twice-accused_plebeianness_Pleione_morgay_inogenous_incumbered}',1,0),(560,'dctf1337{bidets_twaddlement_smrgs_Carthal_remittency_amalgamist_Aryo-dravidian_Acrotretidae_child-heartedness_sarinda}',1,0),(561,'dctf1337{psaltry_phoranthium_trothlessness_mishmosh_praetorianism_peachy_hypostasized}',1,0),(562,'dctf1337{phytomorphosis_Nimrud_underfootman_all-pervading_dardanarius_Beguin_fleabugs_unsanctioning_fulsomely_flambeing}',1,0),(563,'dctf1337{shrewd-brained_inchpin_orsel_grand-slammer_marquees_entocalcaneal_thronelike_otopharyngeal_self-felony_ethnodicy}',1,0),(564,'dctf1337{Buddhistic_culprits_solidify_coproduces_toccate_Tobies_OAT_unmilled_immigrator_Monoceros}',1,0),(565,'dctf1337{nonimmunity_solely_revisership_enigmaticalness_socialist}',1,0),(566,'dctf1337{P.W.D._Diploptera_parovarium_shickers_wreathingly_FTZ_dermasurgery_subpalmate_wire-hung}',1,0),(567,'dctf1337{prologi_byssine_dysluite_Markovian_totemists_secures_Ulla}',1,0),(568,'dctf1337{Puebla_sedating_unbladed_virilisms_internunciatory_uniquest_honeymoonstruck_free-spokenly_broguery}',1,0),(569,'dctf1337{subsequent_felsophyre_literalminded_parametrize_blepharoatheroma_Airliah_half-decked_duplicable}',1,0),(570,'dctf1337{kashruts_tommyrot_sties_vipresident_homoiothermal_levitant_octopods_happens_isopelletierine}',1,0),(571,'dctf1337{heaven-forsaken_engravement_monishing_Kellogg_Tomopteridae_precondition}',1,0),(572,'dctf1337{whitters_queenfishes_pretaste_spell-invoking_freezers_neopaganism_quink_clumpst_inequitably}',1,0),(573,'dctf1337{pretuberculous_botany_impatronize_disdar_Bochism_Miskolc_Mound}',1,0),(574,'dctf1337{sclerotomic_reintegrated_hemocytometer_intracostal_Thomasa_steenboks_Uriisa}',1,0),(575,'dctf1337{spined_evagation_pneumaticity_unreadableness_featish_acoria_ungrainable_bushelman_Polygynia}',1,0),(576,'dctf1337{mispointed_tremblement_Ocko_Rosa_froghood_yender_transpassional_well-favoredly_nymphaeum}',1,0),(577,'dctf1337{hyemal_igasuric_Lemoniinae_oscules_ouabains}',1,0),(578,'dctf1337{unshown_twelvemonths_corncobs_hability_straw-emboweled_skunkweed_succiniferous_Arries_ionogen_slidegroat}',1,0),(579,'dctf1337{pseudoacademic_deutochloride_cautivo_boot-leg_wandering}',1,0),(580,'dctf1337{watersider_Jillana_bourrelet_FPHA_crickey_Palco_preliberally_Ligularia}',1,0),(581,'dctf1337{Lashar_Suriana_anterioyancer_stormtight_resinol_decliners}',1,0),(582,'dctf1337{broking_choler_intitle_scrubs_trans-continental_firmnesses_crull_Poucher}',1,0),(583,'dctf1337{kafila_excrementitial_coupon_trypanolysis_mink-ranching_promise-making_Maurili_hypochondrial}',1,0),(584,'dctf1337{abacination_ladyfishes_rehydrating_swirlingly_baudrons_monorhine_suburbans_justices_nightime}',1,0),(585,'dctf1337{effectuates_Sungari_ceriferous_proliferation_phytoma}',1,0),(586,'dctf1337{saddleless_afluking_quadrauricular_pseudo-_sleever}',1,0),(587,'dctf1337{nonexultation_xenograft_injury_double-tongue_enwombs}',1,0),(588,'dctf1337{Elburn_subcircular_Urbanist_rollerman_noun\'s}',1,0),(589,'dctf1337{fo\'c\'sle_sulfarsphenamine_subcineritious_fallow_Paraclete_touchiest_enterodynia}',1,0),(590,'dctf1337{amphigam_khedives_wonga_balloonery_belchers_electroculture_contendingly_spadassin_Argyll_cloudlets}',1,0),(591,'dctf1337{xenagogy_disacknowledgements_Ebby_vitium_demitrain_pyruline_surveils}',1,0),(592,'dctf1337{geranin_humification_Mariological_greffotome_places_Engelhart_filtrations_Ceb_rope-bound_interpel}',1,0),(593,'dctf1337{stadle_micropenis_abutted_cracker-on_palookas_gonochorismal_subincandescent_decator}',1,0),(594,'dctf1337{tabled_jube_recook_incusing_aristocrats_Hunyadi_nondepreciatory_ballooner}',1,0),(595,'dctf1337{cenatory_orange-tree_bitch-kitty_unphoneticness_overholds_overspeaking_Phalangerinae}',1,0),(596,'dctf1337{notarially_ocean-severed_Victoire_inconquerable_dephlegmator_nightfowl_back-paddle_trout-colored_isophthalic}',1,0),(597,'dctf1337{Ebner_hyalocrystalline_overthriftily_deathtraps_disbursing_hoo-ha}',1,0),(598,'dctf1337{siphosome_spermogoniferous_incomprehension_gossoons_shellshake_chows}',1,0),(599,'dctf1337{Neelyville_proctodaedaea_sozin_new-risen_Kenelm}',1,0),(600,'dctf1337{proprieties_gluttoness_callo_resubscribes_inhabited_transubstantiating_provinciality_alternater_eurytopicity_disfeaturing}',1,0),(601,'dctf1337{blastic_relocates_wide-angle_crumming_Interim_Frederick_striction_rhine_vesicated_aldebaranium}',1,0),(602,'dctf1337{grindingly_phenomenologically_snow-besprinkled_neurectopy_ootocoid_misunderstanders}',1,0),(603,'dctf1337{tolly_Albric_wollop_OAU_Ornithorhynchidae_nosism_schizognathous}',1,0),(604,'dctf1337{pochettino_unfilched_declaration\'s_thermomotive_plantule_stringlike_reoccurring}',1,0),(605,'dctf1337{straik_postmaxillary_amphicarpium_inattention_scrofulorachitic_disinhuming_abusefulness_emissivity_sapropel_punished}',1,0),(606,'dctf1337{nonvacant_hydrofluate_Chiquito_counter-step_featheriness_ropemaker}',1,0),(607,'dctf1337{Binitarian_urbia_triapsidal_childbeds_Boaedon_Mutsuhito}',1,0),(608,'dctf1337{cauliflower-eared_gutta-gum_resurrect_Filipino_directeur_Dyche_braceros_chapattis}',1,0),(609,'dctf1337{soliterraneous_sidelang_bassarid_Viren_Clotilde_Lincroft_self-admission_Eliphalet_ready-witted}',1,0),(610,'dctf1337{desulphurizer_thorough-pin_time-served_punted_volubilities_triolets_stichidia}',1,0),(611,'dctf1337{ill-fitted_segmentation_gimp_Strassburg_throne-worthy_undersquare_resew_entoblastic}',1,0),(612,'dctf1337{butted_esculic_kichel_Sindhi_CSN_cigarette_rotors}',1,0),(613,'dctf1337{round-about-face_goaltending_curney_dehorned_blockman_fixations_sayid_Coronus_actressy}',1,0),(614,'dctf1337{commercialize_cement-covered_leaguers_Philo-teuton_dawing_fen-ting_I-go_simplexity}',1,0),(615,'dctf1337{montanans_fellowly_unmollifying_dietetically_orendite_phonocardiographic}',1,0),(616,'dctf1337{coattestator_dynamitical_Amend_Micaela_Blinni_wanness_qualify}',1,0),(617,'dctf1337{consignificator_Dorask_unsignifiable_trophema_hexachronous_nurturable_vagabonds}',1,0),(618,'dctf1337{topcap_Minorite_albines_otomassage_shivah_self-constituting_Pycnocoma_rly_Foucquet_devitalizing}',1,0),(619,'dctf1337{UWS_axiomatized_separators_trilingualism_corruptibility_symposiac_chancered}',1,0),(620,'dctf1337{plowboy_bateful_syenitic_armchaired_oraler_Tarsuss}',1,0),(621,'dctf1337{katalyst_sanguifluous_sorriness_Bhikku_matchboarding_liquates_mortgagor_Pseudomonas_endothecia}',1,0),(622,'dctf1337{subsume_unharboured_Madaras_endobronchial_day-clean_tidely_rejection\'s}',1,0),(623,'dctf1337{peewees_ganders_denationalize_ties_Oilville_ptinoid_unstress_Witbooi_windy-aisled_Chinookan}',1,0),(624,'dctf1337{testamentation_undamped_nonruminant_enherit_Turcic_unlikened_tremendous_seven-leaved_spice-fraught_beech-green}',1,0),(625,'dctf1337{Nonjuror_cirsomphalos_zingaro_pre-free-trade_contributorial_Decemberish_dungbird}',1,0),(626,'dctf1337{enshawl_passo_microspherical_green-crested_devel}',1,0),(627,'dctf1337{monothetic_mayn\'t_roseately_Hartzke_weird-fixed_Hunchakist_fibrillated}',1,0),(628,'dctf1337{tetrasporangia_minisystems_jordanon_asepsis_capless_cliquiest_lyricked_Nativity}',1,0),(629,'dctf1337{reflies_griddled_tiger-mouth_unnominal_sawnie_fungicidal_diploidic_Epiph_boa_maught}',1,0),(630,'dctf1337{bushing_crispening_redupl._Rizzo_coneflower_Solenopsis_childbirth_inglobe}',1,0),(631,'dctf1337{monoalphabetic_computability_implores_proclaimant_setose}',1,0),(632,'dctf1337{homochromy_dull-headed_body-guard_reinfiltrated_gooseboy_mentery}',1,0),(633,'dctf1337{wearingly_beamage_unassured_Klee_Tiberius_glyceral_wages-man_yemenites}',1,0),(634,'dctf1337{clew_unloosens_topsy-turvyize_tree-lined_nondeist_wiry_rambutans}',1,0),(635,'dctf1337{slimly_overburdensome_bowl-shaped_brawled_stoppeur_Gitanemuck_juts_cudgeler_Paulita}',1,0),(636,'dctf1337{taffrail_glossless_havelocks_implacableness_gorefish_rehoop_Torpedinidae_unpatterned_iare_umpirage}',1,0),(637,'dctf1337{dowless_styful_precious_Ivey_pompiloid_roll-cumulus}',1,0),(638,'dctf1337{geniohyoglossus_bursarship_archipterygium_Pseudo-brahman_imitable_supari_unsifted}',1,0),(639,'dctf1337{nonorientable_Zed_fortuitously_nonrepetition_serpent\'s_allottery_throatroot_manifestation_haunchless}',1,0),(640,'dctf1337{unpreventative_extirpated_phonetic_pertaining_vow_wistfully_Kingsport_Sully-Prudhomme}',1,0),(641,'dctf1337{hand-mill_outvie_Fresison_acock_urtite_hegari_commutation_Neisse}',1,0),(642,'dctf1337{submania_harmaline_causeuse_laryngorrhagia_chazzans_proctectomy_naturalesque_Pickelhaube_honey-drop}',1,0),(643,'dctf1337{Orran_cacomixls_Gaitskell_branchman_Lapeyrouse_veratrizing_galleylike}',1,0),(644,'dctf1337{flogster_expurgatorial_soul-humbling_Sierra_propunishment_bactericidal_disparagingly}',1,0),(645,'dctf1337{ramble_thurle_polygalin_Chi-tzu_ammiral_cowpie_malheur_Holub}',1,0),(646,'dctf1337{inconquerable_Kraft_reefing_pantisocratist_slurped_McGovern}',1,0),(647,'dctf1337{myomectomies_utriculiform_mixochromosome_trochite_synecdochically_despumation}',1,0),(648,'dctf1337{barbola_cattalos_unimodal_hoidening_behooves_five-ply_shake-up_clase}',1,0),(649,'dctf1337{scampavia_quotes_freshest_McFall_subvirate_worst-ruled_Clemons_grogshops}',1,0),(650,'dctf1337{dulcitol_Manzanola_gravel-blind_microchromosome_plot\'s}',1,0),(651,'dctf1337{tearcat_stactes_anniversalily_ophthalmocele_chilidogs_murmured}',1,0),(652,'dctf1337{FUSE_ultrabelieving_shadier_dimethylhydrazine_Grimbal}',1,0),(653,'dctf1337{snobocrat_far-traveled_recuperate_antimoral_technonomic_Frodi}',1,0),(654,'dctf1337{shapeliness_Saone_Bremerton_ICC_Cynodontia_undecimal_diversity_pompatic_microcopying}',1,0),(655,'dctf1337{buskers_griever_balanophorin_salesclerk_nakhoda_candescence_tunna_bayards_postparoxysmal_foozled}',1,0),(656,'dctf1337{disvaluing_ovispermary_colonette_unmelodramatically_passe-partout_unsagaciously_chevvy}',1,0),(657,'dctf1337{nonadventitiously_plank-sheer_ungloating_climatotherapies_Pence_nubilous_monasterial_Spisula_pail\'s_leviathans}',1,0),(658,'dctf1337{complying_malformation_nonassignability_xoanon_molts_Fissipedia_Embolomeri_re-etcher_colleague_zees}',1,0),(659,'dctf1337{strudel_inheritresses_red-tapist_atafter_epeirogeny_inundates_Sandemanism_Lauryn_Tokharian_homolography}',1,0),(660,'dctf1337{flokati_unassuredly_flaillike_faugh_philologue_Gilaki_hypsiliform_conserved_furlough}',1,0),(661,'dctf1337{subpass_nrarucu_superpatriotism_archhypocrisy_funnel-fashioned_roentgens_plank-shear}',1,0),(662,'dctf1337{polygarchy_stucken_debate_complicates_self-adjustment_bunglers_knoller}',1,0),(663,'dctf1337{contorting_airborne_hygric_ergonomically_pithecoid_gobline}',1,0),(664,'dctf1337{semiupright_Bannon_kitchenwife_chengal_Russia_foreplays_podlike}',1,0),(665,'dctf1337{puddingwife_metasedimentary_explorable_apricot\'s_forehall_extinguishable_pulverin_valiances}',1,0),(666,'dctf1337{parapsychologist_short-grained_top-sawyer_Greerson_datagrams_circumradius_iron-mooded_prosperer_scabriusculose}',1,0),(667,'dctf1337{affectedly_rye-bread_Tarheeler_whaps_langel_O-wave_condonations_unsucceeded_uroliths_cockneian}',1,0),(668,'dctf1337{strown_mollifications_objectlessly_chastest_traumata_doncy_intendancies}',1,0),(669,'dctf1337{by-dweller_rushwork_markless_haulm_sortilegy}',1,0),(670,'dctf1337{Welshery_intrinsicate_careenage_harbinger-of-spring_acidulously_overcheapness_Gorga_cowman_beback_semipunitory}',1,0),(671,'dctf1337{ionospherically_Tabanidae_skippered_NETBLT_BSDHyg}',1,0),(672,'dctf1337{cirrose_polymyoid_unflattered_interconnectedness_actinouranium_rimiform_hyphenation_saintology}',1,0),(673,'dctf1337{papalise_cambistry_conveyal_drawer-out_Farand}',1,0),(674,'dctf1337{unradically_esprise_worldbeater_amphithecium_semiconformity_semianaesthetic_unresurrected_supergroups_pompoleon_thoracomelus}',1,0),(675,'dctf1337{counter-riposte_star-shot_malisons_modifiable_Tencteri_carriageless_Tempter_aromaticity_waybung}',1,0),(676,'dctf1337{mabela_spouters_weft-knitted_Disney_leased_magnecrystallic}',1,0),(677,'dctf1337{jambee_promiscuities_Lavon_undercitizenries_anticonstitutionally_symphoniously_herniated}',1,0),(678,'dctf1337{tiewig_makuk_anaesthesis_rhomboides_Hysterophyta_tonalmatl_disorganizing_polyarthric}',1,0),(679,'dctf1337{ponderability_demyelinate_disputatively_copelidine_acerous_garce_Judaism_pseudopapaverine_wifeism_Tupman}',1,0),(680,'dctf1337{strainable_Abruzzi_undername_superabomination_deifier_flateria_nongenerative_imputability}',1,0),(681,'dctf1337{rug\'s_Chaiken_semipsychotic_Palaeoniscidae_abbreviatable_peat_testatorship_woodrush_duvetyne}',1,0),(682,'dctf1337{dust-counter_chining_chignons_claque_tetractine_angiorrhagia}',1,0),(683,'dctf1337{concoctor_prettified_half-lunged_unstrong_babyolatry_eudaemonistic_Fregger_Xenacanthini_pyroglazer_grassiness}',1,0),(684,'dctf1337{ineffably_capiteaux_unmeritable_detainingly_yeguita_harvester_myricas_signaturist_cirterion}',1,0),(685,'dctf1337{attitudinize_zendik_triparted_unactual_saxhorns}',1,0),(686,'dctf1337{petcocks_playgirl_snack_paraproctium_blow-hard_pockiest}',1,0),(687,'dctf1337{overshadowed_sluices_Lusatian_administration\'s_tasheriff_turkeybush_re-etcher_headle_tetty}',1,0),(688,'dctf1337{crooked_zillions_verjuice_nonparadoxicalness_hainberry_alkenes_backscattered_bombazet_Clairfield_Haarlem}',1,0),(689,'dctf1337{adenoviral_preboding_dimeran_unmoderately_unequalize_rollerskater_honk_vesiculopustular}',1,0),(690,'dctf1337{determinists_Denniston_schizocarpic_quackster_antonymous_dewaterer_overemotional}',1,0),(691,'dctf1337{papilliferous_bourgeons_nonnationalization_Bitburg_deadlines_roundups_taenicide}',1,0),(692,'dctf1337{morion_wolfskin_Tabebuia_flat-soled_open-roofed_reincluding_eslabon}',1,0),(693,'dctf1337{intellectualisation_sulphoselenium_colonette_Kummel_backhouse_soup}',1,0),(694,'FLAG{sh0rtest_yet_s1mpl3st}',1,0),(695,'dctf1337{prickier_purposively_Barbaraanne_hexammine_betonies_inflicting_condensable_taxonomist_unremitting}',1,0),(696,'dctf1337{acrotisms_Algoma_desoeuvre_Siculo-phoenician_impaneled_Itoland_batton_caroa_overstayed}',1,0),(697,'dctf1337{fullness_sawbill_gill-netter_Riccioli_divinise_physicomathematics_eflagelliferous_Karelia}',1,0),(698,'dctf1337{never-endingly_rainbowweed_satirize_lifestyles_piroplasms}',1,0),(699,'dctf1337{sunbonnets_clitelline_gem-fruit_straight-line_curtal-ax}',1,0),(700,'dctf1337{wheki_disnature_japishly_truebred_cerias_Turnheim_B.Arch._unthreads_polemarch}',1,0),(701,'dctf1337{bescorching_pillarwise_Selwin_intermedio-lateral_height-to-paper_Kirovograd}',1,0),(702,'dctf1337{disguises_tower-bearing_preaccomplish_indigent_horngeld_pertinent_missionization}',1,0),(703,'dctf1337{subventral_throwoff_fiscalization_condolence_digladiating_socializable_benchful_diazotic_crubeen}',1,0),(704,'dctf1337{fiery_palinodial_hippotomical_relaunches_Bekaa_nonblasphemy_rackateering_six-wheel}',1,0),(705,'dctf1337{gaining_ushered_vanquishing_scenarioize_noncommodious_stomal_tanklike_interfacing}',1,0),(706,'dctf1337{subvillain_introverts_fame-achieving_unsinuately_intuito_horsedom_signifiable_round-hoofed}',1,0),(707,'dctf1337{Bryanty_Kerianne_Gibb_triphane_Kasbah_forthcame_Moslemah_amebobacter_significate_Campobello}',1,0),(708,'dctf1337{sclerodermia_patrological_Non-swiss_mysid_dwalm_BSIE_unexplodable}',1,0),(709,'dctf1337{sarcel_Abigael_semisegment_spunkless_sourdine_goadlike_suborbitary_carbineers_osteomalacial}',1,0),(710,'dctf1337{epenthetic_hemimetabole_physicotheology_undisturbable_ill-composed_iceskate_demagnify_intagli}',1,0),(711,'dctf1337{tantalums_stockfather_Plimsoll_arduousness_strathspey_aluminoferric_clause}',1,0),(712,'dctf1337{binomialism_Edgell_unprelatic_white-woolly_octanol_unproverbially_blepharosymphysis_parageusic_Kennelly_bordures}',1,0),(713,'dctf1337{programing_salutations_Annunciation_Berenice_overexertion}',1,0),(714,'dctf1337{pseudosolution_unhappy-faced_sycoma_adenomeningeal_hydnaceous_argin_lariated_tussores_turb}',1,0),(715,'dctf1337{Reiko_pomoerium_disposers_Claudie_steerer_euphory_bolt-forging_Msgr_heterophemism_pyrobituminous}',1,0),(716,'dctf1337{intermitted_Kamin_hooty_Cupo_expos_biodyne_conventically_disfiguration_redout}',1,0),(717,'dctf1337{paronymic_Hyps_quarries_ax-shaped_unaggressiveness_trashless}',1,0),(718,'dctf1337{bronchiectatic_sirees_Kanorado_surmountable_Sherie_ephods}',1,0),(719,'dctf1337{half-sheathed_Olenellus_Hoshi_maximumly_psilosophy_eusteles_loxoclase_bump-start_illegalization}',1,0),(720,'dctf1337{n-ply_stipitiform_hephthemimeral_hygr-_cerebrosensorial_relisted_loggerheads_monocleide_plurivalent_enhort}',1,0),(721,'dctf1337{well-off_calamining_Dardanelle_gibbously_subgular_colporteurs_ramblingly_aerophagist_startlingness_divisions}',1,0),(722,'dctf1337{mismade_paranitraniline_tracheloacromialis_Oxfords_syrtic_metaprotein_cormoid}',1,0),(723,'dctf1337{Reeda_pragmaticist_preintelligently_subgit_unwearisome}',1,0),(724,'dctf1337{itherness_poley_uncrafty_half-timbered_Aruabea_hesperornithoid_sortilegy}',1,0),(725,'dctf1337{rehouse_Mandibulata_electronography_panpsychic_nonadventurously_Gesellschaft_insensibility_wrap_Marinna_demi-sang}',1,0),(726,'dctf1337{euodic_vapourers_demibath_refool_saussuritization}',1,0),(727,'dctf1337{polytungstic_impsonite_tardamente_clean-souled_barleymow_unburden_nectarlike_antenatalitial}',1,0),(728,'dctf1337{spur-toed_weathertight_tene-bricose_sceuophorion_chamal_Roget_quasi-honorably_insignificance_Notopterus_takeups}',1,0),(729,'dctf1337{paiwari_lathi_self-consistency_gonococcocci_twice-reconciled_admiration_antiphrasis_foxtailed}',1,0),(730,'dctf1337{ptochology_miliaria_desperado_cacur_odd-shaped}',1,0),(731,'dctf1337{Leptolepidae_Woodsville_Amb_anti-nebraska_featherbrain}',1,0),(732,'dctf1337{ivies_well-cured_sonography_sailmaker_satinets}',1,0),(733,'dctf1337{ungyve_palaeoniscid_hemikaryon_rotograph_foosterer_steamed}',1,0),(734,'dctf1337{nondeodorizing_Filix_outdrops_eichwaldite_nasab_sharecroping_spadilles}',1,0),(735,'dctf1337{typhlotomy_fine-draw_bifollicular_lavational_foliolose_aphaeresis_koftgar}',1,0),(736,'dctf1337{parer_overwarming_elitists_three-cleft_Dardan_funambulator_cacoepy_preprogrammed}',1,0),(737,'dctf1337{phrenicohepatic_cirsectomy_speciosity_simplicize_fidejussion_thereupon_unyouthful}',1,0),(738,'dctf1337{tekedye_uncovered_outgreen_Iridum_Madrepora_cajolement_Siddhanta_linefeed_insolubilized}',1,0),(739,'dctf1337{indicias_anthropocentric_fishways_handling_okehs_LCLOC_supracaudal}',1,0),(740,'dctf1337{headtire_protestors_dhutis_prefired_scorifying_bell-faced_gymnosoph_Japanolatry}',1,0),(741,'dctf1337{penicils_nobleheartedly_brises_shurf_cohost_eudaemonize_assi_uniped_geeing}',1,0),(742,'dctf1337{Lecoma_ozophen_busload_dodgems_Gobiesox}',1,0),(743,'dctf1337{relatch_recounsel_footwalls_under-king_FTP}',1,0),(744,'dctf1337{escrows_playmates_Songhai_cowyard_half-price_Darragh_self-hardening}',1,0),(745,'dctf1337{Culebra_turbidimetrically_sulphoarsenite_obstruction_sasarara_baklawas_hypermagical_mediators_petit-maftre_vicuda}',1,0),(746,'dctf1337{handshaking_sea-bred_petitioned_evetide_absent-mindedness_silicam_rugose-leaved_forlet_tittuped}',1,0),(747,'dctf1337{suricates_heedlessnesses_timbales_nonvindication_phenates_nonmodificatory}',1,0),(748,'dctf1337{earthworm_antiburglar_dacrya_unmiraculously_argentometry_stearins_mid-life}',1,0),(749,'dctf1337{disimpassioned_oddlegs_chorically_BUF_Tamaulipas_romanceless}',1,0),(750,'dctf1337{isopurpurin_pleistoseist_loosest_pseudoyohimbine_bichir_spright_pyritize}',1,0),(751,'dctf1337{kippeen_stegosauri_Thrale_selfness_bolsterers_effigurate_phonocamptic_goldminer_fizzier_physcioid}',1,0),(752,'dctf1337{Arriba_ablepsia_clavicembalist_quasi-compromising_pseudoanemic_clarshech_raftsmen_solenoconch}',1,0),(753,'dctf1337{Isabelle_aphonia_mouillation_paleencephalon_SVR4_fistular}',1,0),(754,'dctf1337{licentious_moonport_Pennatula_tundra_excussing_cystenchymatous_toluols}',1,0),(755,'dctf1337{nonempty_Lilliput_equiponderous_unmarking_retroject_felliducous_demoiselles_quinti-_Carbonari}',1,0),(756,'dctf1337{tardiloquy_unrevenging_unapprovingly_arrided_pantle_phytogeny_pedophilia_unsurvived_frontomental_endostracal}',1,0),(757,'dctf1337{bacquet_fancies_enterostenosis_seabird_Kitasato_Glenus_supranasal_rangefinder}',1,0),(758,'dctf1337{immanental_rufous-buff_nonextortive_assessionary_much-hunger_snob_mechanism_antheridia_alebench_Ashling}',1,0),(759,'dctf1337{caum_prilling_rods_ranklingly_superfinanced_monacidic_heat-radiating_sleaved}',1,0),(760,'dctf1337{mushrooms_acritude_Polystomata_self-valuation_phillipeener_copywriting_indoles}',1,0),(761,'dctf1337{osseins_will-lessly_sacerdocy_goddize_Crocodilidae}',1,0),(762,'dctf1337{setting_disagreed_angelographer_owl-light_undiscording_kenspeckle_swift-foot_coaxy_maceraters}',1,0),(763,'dctf1337{Cordell_stratovision_unsettledness_hormic_oasal_extrapopular_yellow-splotched}',1,0),(764,'dctf1337{liberating_paletot_unflock_ASS_weedier_pipecolinic_efficiencies}',1,0),(765,'dctf1337{undevout_Postverta_unstickingness_hepatolenticular_cumbrousness_pastils}',1,0),(766,'dctf1337{pro-Denmark_forthcomingness_grave-faced_ploughmell_demonry}',1,0),(767,'dctf1337{botanised_Lemanea_pseudoregally_unfeminised_warehouser_hegumenes}',1,0),(768,'dctf1337{Centraxonia_twice-dyed_patriotics_spathe_unsimilar_Lak_brechan_blarneys}',1,0),(769,'dctf1337{overwetness_mudcapping_fraudulentness_unimpeding_bothsidedness_pluteutei_vacuometer}',1,0),(770,'dctf1337{Callimachus_appealing_battle-slain_integrals_Pellston}',1,0),(771,'dctf1337{duodecastyle_undotted_Oktoberfest_robes_etherism_catholic\'s_grievance\'s}',1,0),(772,'dctf1337{finalizations_inducibility_symbolry_engulf_machicolating_Elvaston_hematomphalocele_sipe_Rhyne_comparison}',1,0),(773,'dctf1337{kl_theremins_mammati_semishady_firebug_crizzle}',1,0),(774,'dctf1337{bangalay_turbulentness_wire-cloth_valleyite_withewood_untraceable}',1,0),(775,'dctf1337{Eleusine_underpinning_deboistly_flap-dragon_Acipenseridae_Swedish-owned_sorrily_pseudopregnancy}',1,0),(776,'dctf1337{deposure_sternites_sea-island_pitcher-shaped_verbally}',1,0),(777,'dctf1337{vangs_swiping_dosses_ruff-coat_onymous_canceleer_syncline_prickado_repiqued}',1,0),(778,'dctf1337{interknit_silicononane_carnal-minded_amylocellulose_orthogonalize}',1,0),(779,'dctf1337{mammonite_Catalonian_borty_kyats_Ansted}',1,0),(780,'dctf1337{station-house_teammates_shangy_ribband_negativity_October_incused}',1,0),(781,'dctf1337{genesic_sequentialize_archmachine_rationment_escorting_cilice_semiprofane}',1,0),(782,'dctf1337{kabaragoya_Reste_Bernadette_shoveller_triatomic_tenaille_Urd}',1,0),(783,'dctf1337{heterosexually_unplacid_granulative_swartzite_stumpier_stero_incognizance}',1,0),(784,'dctf1337{half-forward_staphyloma_beefin_glandules_prepolish_still-vexed_cuckolds_Hijra_challote_styfziekte}',1,0),(785,'dctf1337{adnumber_pilocarpin_forcaria_hinderingly_broomed_illiberally_MMM}',1,0),(786,'dctf1337{Minneota_counterbattery_unperspiring_dilatant_hereof_howf_Ronica}',1,0),(787,'dctf1337{sarcoderma_sphering_massacring_munge_mitosome_swatting_underarms_self-afflictive}',1,0),(788,'dctf1337{slabbing_neoplasties_circularizer_sensitization_repandousness_litigations}',1,0),(789,'dctf1337{dealings_musk-ox_synsporous_oligomer_fucuses}',1,0),(790,'dctf1337{nurd_Lockyer_montigeneous_Hilary_maddening_matzos_wrangler_Spector_statelet_hallion}',1,0),(791,'dctf1337{self-retired_masticator_emparadise_Scheherazade_mouser_sniffier_plantigrady_degust}',1,0),(792,'dctf1337{wingseed_Mady_winier_regreasing_whole-bound_Berkeleianism_Orcinus_sinfonie_flchette_icicles}',1,0),(793,'dctf1337{underload_knowableness_addressee\'s_brevets_stammerer_purposefully_anthracometric_caesuras}',1,0),(794,'dctf1337{overgambled_splats_misdeal_hardens_threne_goose-neck_Jutlander_Shoshone}',1,0),(795,'dctf1337{triduam_bugaboos_mammonitish_seventy-eight_Barbica}',1,0),(796,'dctf1337{deglaciation_reserene_unavailingly_waise_perturbedly_counter-passant}',1,0),(797,'dctf1337{Pholcus_poodleship_unglove_estimably_quinsies_cacumination_goatsbane_momento}',1,0),(798,'dctf1337{jogglety_monocratic_azymous_astrol_quacks_demagogues_pizzazz_overheaviness}',1,0),(799,'dctf1337{edifices_ladies\'-tobaccos_hecks_Mimosaceae_ichthyophagi_intervertebrally_proleptics_Pachuca_Antigo}',1,0),(800,'dctf1337{frogbit_fusionless_lumpers_Tanzania_conflab_speaking_enweb_salmonellae}',1,0),(801,'dctf1337{vocalizes_whiskylike_knife-grinder_\'tween_vapourish_weedling_flippity-flop_eunuchs}',1,0),(802,'dctf1337{tectospondylous_cheville_slovenwood_postdiluvial_orange-sized_Arleng_brabblement_Harmothoe_Roget_tensegrity}',1,0),(803,'dctf1337{maskoid_unendorsed_abelmosks_Penna_ureylene_maniac\'s_ringbolts_relationary_cedarbird_clapstick}',1,0),(804,'dctf1337{Americanistic_claiver_superorbital_Aestatis_uninspiringly}',1,0),(805,'dctf1337{pubourethral_minislump_monstrate_crumper_policemanship_Tiphiidae_Sulfonal_etiolates_fine-haired}',1,0),(806,'dctf1337{springle_atropinize_coimmense_anthrahydroquinone_Randolph_becomes_abysms_interestless_cask-shaped_Bothnian}',1,0),(807,'dctf1337{counterthrusts_Swabian_brass-tipped_uninstinctively_Powderhorn_MSPH_polyscope_freewheelingness_pujahs_sternest}',1,0),(808,'dctf1337{multiseated_great-grandchild_Apatela_syllabary_teetan}',1,0),(809,'dctf1337{unopaque_brocoli_othmany_cystomorphous_humdrumminess}',1,0),(810,'dctf1337{yttrialite_ukiyoe_maxillopremaxillary_idiopathically_Mandaic_nonspiritualness_chawer_sciaenid}',1,0),(811,'dctf1337{Anthesterion_Poictesme_NESC_counter-off_powerfulness_phoresis}',1,0),(812,'dctf1337{xref_cultrate_forecatharping_revete_aerage_Lorain_galoot}',1,0),(813,'dctf1337{foredawn_denoted_clarifiers_sagaciate_Loachapoka_bouldered_hard-learned_rough-hobbed_prehorizon_pentagynian}',1,0),(814,'dctf1337{nonthinker_nonveracious_thermosensitive_Afg_outflinging_antihydropin_Hayesville}',1,0),(815,'dctf1337{Aristolochiaceae_overeffusiveness_isopachous_dabble_well-mettled_cnemides_hyperbulia_yerbas_underaldermen}',1,0),(816,'dctf1337{rotten-red_cleveites_onocentaur_rhabdite_Akeylah_nonaffirmance_potsy_conchyliated}',1,0),(817,'dctf1337{inseverable_clogwheel_rompishly_Thjatsi_rescusser_Mentor_jantu}',1,0),(818,'dctf1337{headcheese_two-phaser_reducement_incalver_Hulen}',1,0),(819,'dctf1337{snow-clad_phellogenetic_Gaspard_Ptychoparia_goldylocks_glaserite_asterioid_mosque_Inst_Mammon}',1,0),(820,'dctf1337{gnarliness_veligers_chewing-out_Flemming_fleshers}',1,0),(821,'dctf1337{nonimaginary_preconise_intubationist_Nazarate_alleniate_garrotes_tourbe_ananter_nonattainability}',1,0),(822,'dctf1337{nonpsychologically_bullhead_acopyrin_Mee_reinvasion_zoochem_mogo_modernish_firmance}',1,0),(823,'dctf1337{disentrainment_nonvegetatively_interangular_sheepdip_nicer_unmistaking_enteroischiocele_haematozoon}',1,0),(824,'dctf1337{dwelt_substitutability_scioterical_sillandar_imbricately_preclassically}',1,0),(825,'dctf1337{viznomy_Faith_Iacchos_ketapang_feff_spewers_herself}',1,0),(826,'dctf1337{duende_subtle-souled_diacidic_multifarous_thin-headed_rushes_actinopraxis_Adonis_Tomoyuki}',1,0),(827,'dctf1337{Aubert_antihalation_protocone_anay_Immortals_subtilty_gem-bespangled_gibbles_superingenuity_Sovietization}',1,0),(828,'dctf1337{Solera_all-potential_unreprobative_pulpitish_hyperimmunization}',1,0),(829,'dctf1337{moly_murasakite_uranine_haffets_cowberries}',1,0),(830,'dctf1337{microbium_Ofo_panosteitis_cock-a-leekie_versionize_earthslide_rachial}',1,0),(831,'dctf1337{fumaroid_organically_herbarize_transdesert_Julius_unscattered_backdrops}',1,0),(832,'dctf1337{bionic_theognostic_indexically_shirtings_savings}',1,0),(833,'dctf1337{buckjumper_Smitane_inspan_precalculations_noncollectivistic_prenoon}',1,0),(834,'dctf1337{dourer_Triplex_availers_nonaccidentally_dakoities_Thomaston_nonbiological_agnatical_suer_microlux}',1,0),(835,'dctf1337{climograph_untreed_crare_P3_uvulotomy_dojo_labialised}',1,0),(836,'dctf1337{eucharistized_schnecken_jaunty_udaler_speakings_Nava_multilamellous}',1,0),(837,'dctf1337{prepolitically_oosporiferous_retreat_appetition_ascertains_solarising_smudgy}',1,0),(838,'dctf1337{Kyra_nose-dive_huddling_crown-scab_connections_cloudiest_undergroundness_underripe_saddle-billed_Grignolino}',1,0),(839,'dctf1337{eglestonite_sorcerers_preenrollment_buckeroo_trainload}',1,0),(840,'dctf1337{swaddles_merling_desentimentalize_diuranate_colorize_purple-tipped}',1,0),(841,'dctf1337{nephrolytic_marliest_corpuscular_doggereler_anti-intellectualism_gnetums}',1,0),(842,'dctf1337{rope-yarn_Kartvelian_Osiandrian_well-deservingness_agathist_wound-marked_tubaphone_hookwise_point-on}',1,0),(843,'dctf1337{cassioberry_Steenie_Blucher_unmajestic_audibly_Juno_long-termer_occlusiveness}',1,0),(844,'dctf1337{sermoniser_Brixey_Sagai_acclimatizing_hyalines_unadjunctively_discardment_auxobody_manioc_pseudopodium}',1,0),(845,'dctf1337{time-measuring_bathroom_jazzily_backbend_butcherer_Amlin_workhorse\'s}',1,0),(846,'dctf1337{covert_devitalizing_benzo_bromizes_thought-peopled_fairyship_turn-tree_thermo_uncensured_necrophilic}',1,0),(847,'dctf1337{relegated_plecopteran_music-flowing_Cinnamodendron_nonprovocatively_Urien_Jeniece_Durst_bluffed_Cochrane}',1,0),(848,'dctf1337{misallot_acronycally_Somis_Brahminism_spodiosite}',1,0),(849,'dctf1337{effervescence_carfuffle_confidential_miotic_Lavi_Podsnap_philocynicism_reblock_leucophane}',1,0),(850,'dctf1337{forbidals_aburban_ambulatories_squamoparietal_eagernesses_unaspiringness_podomeres}',1,0),(851,'dctf1337{nobleheartedness_hyperconservatively_Oradell_beboppers_aurify_undegenerating_Russo-swedish_coups_keyslot}',1,0),(852,'dctf1337{rebed_antitragicus_Prophetico-messianic_churchwarden_dismemberer_lieberkuhn_unbroached_semipopular}',1,0),(853,'dctf1337{semeiology_splenetically_cyclogenesis_sequencing_Cortland_interrobang_clonked}',1,0),(854,'dctf1337{neuroblast_blacking_proximolabial_reigns_rose-breasted_renably_reassimilates_nudes}',1,0),(855,'dctf1337{Pelmatozoa_Amargo_boscage_tresillo_shard-born_Wanchuan}',1,0),(856,'dctf1337{unweb_disassembles_old-worldism_sutleress_rozzers_calomels}',1,0),(857,'dctf1337{photo-_formulistic_observanda_homosexually_micropathological_kakogenic_healthy-minded_siecle_Seres}',1,0),(858,'dctf1337{Haloragidaceae_sailor-train_Mihail_ravellers_presuggest_well-staged_repressurizes_recentest}',1,0),(859,'dctf1337{skiagram_hemochromatotic_nonpreparatory_CONUS_popal_Waite_oaritic_subadministrative_oddly_Dede}',1,0),(860,'dctf1337{nou_lx_long-handed_house-place_perfects}',1,0),(861,'dctf1337{cell-blockade_Polypterus_loinguard_Sarcopsylla_pre-contract_Mekinock_unstatued_underplant_icterogenic}',1,0),(862,'dctf1337{presspack_aftermast_LPN_futtocks_combustibly_podothecal_occupative_willow-shaded}',1,0),(863,'dctf1337{night-dress_infratrochanteric_chitose_preconsidered_Ibadan_Kuantan}',1,0),(864,'dctf1337{untumultuously_recapped_footslogging_backcast_defence}',1,0),(865,'dctf1337{doggonedest_snobbishly_travel-spent_velocipedic_yellowish-brown_reteaches}',1,0),(866,'dctf1337{self-canceled_twalpenny_betattered_tusky_dacryosolenitis_gruellings}',1,0),(867,'dctf1337{cheveret_incorporeal_andronitis_howardite_antiboss_complaisantly_enticeful_Maretta}',1,0),(868,'dctf1337{cognacs_Centunculus_Wilmont_Geoglossum_wotted_putter-through_archpoet_hopcrease_slow-gaited_wood-hooped}',1,0),(869,'dctf1337{vincristines_deleterious_trugmallion_storywork_Parthenolatry_nonsacrilegiously_Udale_Woodlawn_sharp-freezing_faham}',1,0),(870,'dctf1337{Lupita_topographist_methodized_velocious_synclastic_taharah_apocatastasis_intendment_presentment_haunters}',1,0),(871,'dctf1337{sunburning_oomycetous_honeycup_applanate_bivouaced}',1,0),(872,'dctf1337{trifid_rattlemouse_Olivero_breathseller_compinge}',1,0),(873,'dctf1337{lactocele_jeer\'s_dephased_luxuriated_dicyemid_nonimmunization}',1,0),(874,'dctf1337{Cactales_Ernst_spiritualiser_semipiscine_notanencephalia_diapirs}',1,0),(875,'dctf1337{insalivating_Burnett_nonabusiveness_she-god_cleated_Evadale}',1,0),(876,'dctf1337{Kinosternidae_downdale_veratrylidene_dimmers_uncleft_astrochronological_Akanekunik_mixture_katabothron_sedanier}',1,0),(877,'dctf1337{celiosalpingectomy_two-row_anti-isolationist_gouts_schoenobatist_Megarensian_gaucher_predictability_signifies}',1,0),(878,'dctf1337{itatartaric_surfcaster_murderish_inoccupation_tollages}',1,0),(879,'dctf1337{twalt_gurnet_coctoprecipitin_Ellerslie_eyne_hemocoele}',1,0),(880,'dctf1337{presentment_philatelical_aminolytic_keenly_promodernist_hauflin_Adelbert_antichlor}',1,0),(881,'dctf1337{carvol_sudatoria_vindicating_Dunham_Olax_Goala_unquickened_gin\'s_Dimphia}',1,0),(882,'dctf1337{tideful_Paulson_xeroxes_backpacks_workbank_numbats_MCN_grantedly_bowls_garrupa}',1,0),(883,'dctf1337{Rhamnales_deckel_alloantibody_soprano_chilling_grangerize}',1,0),(884,'dctf1337{incubatory_resounder_engrosses_ratably_dodecahedral_demeans_incenseless_marishes}',1,0),(885,'dctf1337{underpaid_unsuspectingness_BCP_loveling_repatronizing}',1,0),(886,'dctf1337{disencharm_supple-jack_remanage_jolly_institory_divisive_theyaou}',1,0),(887,'dctf1337{thallodic_extraparochial_well-tamed_small-bore_recreatable_authorhood_supralocally_funnel-necked_nonpositivistic}',1,0),(888,'dctf1337{papistically_dummy\'s_ental_unshaped_artmobile_scenewright}',1,0),(889,'dctf1337{rizzomed_Glaux_seawaters_objectizing_glozer_laryngectomizing_illative_unglazed_unpenalised_Wesermde}',1,0),(890,'dctf1337{bowline\'s_privy\'s_alleyway_mediumize_lockup\'s_doodle_snafuing}',1,0),(891,'dctf1337{externalization_nonregeneration_catalyzes_miscopied_air-threatening_landgates_estafette}',1,0),(892,'dctf1337{galleine_overtalk_unintentionalness_brazilins_majored_hydrocracking_unincriminating_acidy_chastisable}',1,0),(893,'dctf1337{polysiphonic_Caricaceae_Smartt_soiled_aphrodisiomaniac}',1,0),(894,'dctf1337{Marsilia_ever-white_strictures_rime-frosted_blennocystitis_nine-spot_plenitide_genuflectory_endleaves_instructing}',1,0),(895,'dctf1337{inwalled_heightens_Poulter_maudlinness_presaging_overseers_determine}',1,0),(896,'dctf1337{overdrawer_gizzened_Recurvirostridae_pollenless_presurmise_Zambezi_overdiscouraging}',1,0),(897,'dctf1337{acceptee_derrises_langel_Galbreath_chargeably}',1,0),(898,'dctf1337{maudlinize_Tursiops_tetramethyl_uranographical_tripletail}',1,0),(899,'dctf1337{microradiographical_preeducational_Hallouf_obligatos_prerelated_cherubimic_tremulant_disgarland_bangkoks}',1,0),(900,'dctf1337{snowberg_sheriffcies_straddle_gluepot_subteraqueous_rheumiest}',1,0),(901,'dctf1337{Achatinidae_stamin_Gati_antimagnetic_Buckley_dogtrots_qui-hi_undefeasible_Sinopic}',1,0),(902,'dctf1337{ponderousness_Arundell_escobita_Lakeview_philopig_Crestline}',1,0),(903,'dctf1337{ondule_amphipodal_spiraled_derated_unsepulchre}',1,0),(904,'dctf1337{vacationless_paregorical_onymal_scriptoria_repaved_preplanned_ante-ecclesiastical_crackerjack_oatfowl_uncondoning}',1,0),(905,'dctf1337{fittable_thick-barked_Gordo_re-sound_moulding-board}',1,0),(906,'dctf1337{thingummy_inquestual_spoon-feed_dogwoods_imperatorian_drawer-up_proxenus_scodgy}',1,0),(907,'dctf1337{Hersch_quick-flowing_balsamroot_sibship_Memlinc_TCPIP_small-acred}',1,0),(908,'dctf1337{unforthright_unwares_geno-_surface-coated_hyperovarism_lampadaire_Roann_quarter-decker_woodboxes}',1,0),(909,'dctf1337{dustbins_many-fountained_ankylos_all-encompassing_half-monthly_prediminishment_rainsquall}',1,0),(910,'dctf1337{focalising_abominability_Bouake_repped_unmellifluous_hiemation_puissantness_Aedon_enwound}',1,0),(911,'dctf1337{Cressy_cocoon\'s_thraves_Pleurotomidae_musculocellular_anastaltic}',1,0),(912,'dctf1337{Boehmenism_skycraft_Satsuma_cabbagelike_Tamasine_Linzy_reccy_difficileness_Pulaski_creatorhood}',1,0),(913,'dctf1337{misstyled_reperuse_pockmark_lumbo-iliac_jam-up_slurping_antiskidding_Martell_SQA}',1,0),(914,'dctf1337{cobishop_dehull_scrapiness_viperine_sapphired_intercentra}',1,0),(915,'dctf1337{toothflower_half-miseducated_hereon_Cal_wanned_onstanding_Rion_punnigram_unensouled_taboparesis}',1,0),(916,'dctf1337{outraced_ceratopsian_matrons_pantherlike_full_underdo_de-excite_ensnarled_stiff-rimmed}',1,0),(917,'dctf1337{gargler_Brittani_Anzanian_trucked_actinotherapy_heteromastigate_byzants_meed_nomotheism_pleasantness}',1,0),(918,'dctf1337{transmittible_nonprotrusively_soft-colored_bilsh_temperate_boronatrocalcite_coracobrachialis_ivory-tinted}',1,0),(919,'dctf1337{suedes_monodize_ungeneralizing_unideating_insheathing_latexes_mandatum_onomasiological_phantasmatography_interstrial}',1,0),(920,'dctf1337{knobstick_exchequers_dimplement_indiscriminatory_quintocubital_stenorhyncous_asarite_gaberlunzie_earth-wrecking_strongness}',1,0),(921,'dctf1337{co-agency_zonelet_mitigators_Adey_soul-subduing_sitting}',1,0),(922,'dctf1337{Vladimir_vulgarizers_Styxian_juddock_madril_liberals_twice-preferred}',1,0),(923,'dctf1337{electrotrephine_Octodontidae_unintruding_pseudopodium_exhausts_hampers_silver-winged_nonredemptible}',1,0),(924,'dctf1337{PETA_turnip\'s_trotol_ministered_genospecies_turbanwise}',1,0),(925,'dctf1337{boun_sauld_TRW_misdeems_ferthumlungur}',1,0),(926,'dctf1337{imparadised_nonrelapsed_Kaya_unmangled_alife_cutinise_postpones_Masorah_tophous}',1,0),(927,'dctf1337{houndsberry_rebutter_semivoluntary_curiouser_Chelton_plastered}',1,0),(928,'dctf1337{canroyer_boattail_cysticercerci_pat-pat_posttrial}',1,0),(929,'dctf1337{Waldport_singult_entozoological_Jaures_reiving_torpedoproof_thoracoplasty_weirdful}',1,0),(930,'dctf1337{flosses_Myrmecobiinae_galateas_peckhamite_redundantly}',1,0),(931,'dctf1337{unpatristical_foster-nurse_billions_medifixed_autocratship_two-woods_CVO_warworker}',1,0),(932,'dctf1337{unpetulant_disbodied_Nobie_accessioning_unprickled_implacability_undefaulting}',1,0),(933,'dctf1337{curl-flowered_noncharismatic_soul-racking_scopuliferous_Edgeworth_archaeologies}',1,0),(934,'dctf1337{nucleli_pathogeneses_longtail_premillennial_nondecisive_Marvell_septemvious_importunate_unresolve_visitator}',1,0),(935,'dctf1337{illegitimately_split-_snow-rigged_pyroligneous_screak}',1,0),(936,'dctf1337{adorations_miscreants_adneural_dephlegm_afterdecks_Pedroza}',1,0),(937,'dctf1337{worldlinesses_superdesirous_ectoblastic_obdurateness_vintlite}',1,0),(938,'dctf1337{annual_Southey_iconography_thrones_Romans_polyhemia_kiekie}',1,0),(939,'dctf1337{self-defended_Cellvibrio_glass-paper_homesteaders_millionairedom_creches_epitaphize_wamefuls_embarricado}',1,0),(940,'dctf1337{tunicary_paltock_prezygapophysis_protoleucocyte_paratrimma}',1,0),(941,'dctf1337{undealt_protogenist_sokemen_tradership_frivolous_crosscrosslet_lictorian_refinage_Andromede}',1,0),(942,'dctf1337{mesaortitis_pacificistic_octactine_thornhead_Ethiope}',1,0),(943,'dctf1337{tripple_bedwarfed_unadjudged_dueled_Selago_biopyribole_Ravensara_multivitamin_euphemizing}',1,0),(944,'dctf1337{foozler_unfruitfully_phenosafranine_predomestically_woman-daunted_horn-eyed_watchmate_opthalmoplegy_unepitaphed_buyback}',1,0),(945,'dctf1337{knuckle-dusters_contangos_agedness_perbromide_Maybloom}',1,0),(946,'dctf1337{chitterling_thoracohumeral_joy-ride_conspiratorial_gourmandise_oftentime_lagoons}',1,0),(947,'dctf1337{Spartacist_mesepisternal_pocketknives_Kleenex_puncturing_opsimath_Goering}',1,0),(948,'dctf1337{pompelmoose_perfluent_adelphogamy_lumbricid_chairing_Sithole_Rauschenburg_unspuriously_carnage}',1,0),(949,'dctf1337{otxi_mitered_non-Biblically_raveinelike_clorinator_Miohippus_inleakage_zygo-_shantymen_zesting}',1,0),(950,'dctf1337{pilocarpidine_semiquaver_ambi-_imageless_Crises_intervolve_dialectologically_Alayne_baker-leg}',1,0),(951,'dctf1337{metallurgists_facioplegia_maught_wax-erected_quinela_conglobately}',1,0),(952,'dctf1337{deportees_degusting_Bovista_Ewall_nonfactual_unpictorialise_proficiency_packsaddle_willow-wood}',1,0),(953,'dctf1337{really_heterozygote_Antarctogaea_Silicospongiae_Laharpe}',1,0),(954,'dctf1337{hazel-hooped_self-willed_pioned_vitellins_nonesthetic_teinoscope_bombe_superinfusing_piazzaless_predegenerate}',1,0),(955,'dctf1337{southmost_tetragrid_emphrensy_nondepreciatory_quagginess}',1,0),(956,'dctf1337{prevernal_Homalopsinae_stinted_amusee_septcentenary_jagrata_self-sterile_pelvimetric}',1,0),(957,'dctf1337{choledochostomy_misarrangements_gewgawry_unmelt_Shickshinny_doges_cotyloidal_laniariform_hemidome}',1,0),(958,'dctf1337{myography_hydrorhizal_rod-healing_apostasy_fire-pan_undead}',1,0),(959,'dctf1337{analyze_circumnutation_carrotiest_sanitarium_instants_monticulus_exotoxins_symphonised_dumb-cane_cotemporarily}',1,0),(960,'dctf1337{uncases_renocutaneous_allemand_Danite_joyfullest_hypoglycaemia_postnaris_arecas_inosculating_re-escort}',1,0),(961,'dctf1337{bullrings_uptosses_Dichapetalaceae_micrometers_nightwear_disparpled_felicitous_aurar}',1,0),(962,'dctf1337{Wallace_multivitamin_diedric_resynchronize_parsonese_hogger_Haematophilina_saccharobutyric_Klayman_Anglo-persian}',1,0),(963,'dctf1337{Nazlini_arguers_shallower_delegator_relationism}',1,0),(964,'dctf1337{tortuous_weaknesses_supercredit_diseurs_concrescence_unimpregnate}',1,0),(965,'dctf1337{Waddenzee_Nondalton_kallitype_intext_Terti_taxpaid_wrapperer_frost-fettered_mud-splashed_Stalder}',1,0),(966,'dctf1337{spleen-pained_arolia_craniography_heresiologist_windjamming_semidecadent_misdesignate_Landers_shroudlike}',1,0),(967,'dctf1337{wattless_arranger_incompendious_Welcomed_blurry_fluffiest_Jenkinsburg_goutiest}',1,0),(968,'dctf1337{Bikukulla_homotypic_segathy_self-maceration_cylindrodendrite}',1,0),(969,'dctf1337{treewards_Escoffier_Krigia_electioneering_capture_jostles}',1,0),(970,'dctf1337{unemployed_sacrocostal_guachipilin_warm-reeking_ensignhood_metallorganic_Fordizing}',1,0),(971,'dctf1337{fond_sidemen_Chrysops_all-abhorred_remenace}',1,0),(972,'dctf1337{Hecuba_gliffy_Kennet_coambassador_hypermeter_overcontract_thilk_illusible_methoxyflurane_Sarelon}',1,0),(973,'dctf1337{Edny_hostry_wapinschaw_lattens_legua_dridder_Herodian}',1,0),(974,'dctf1337{Payni_Marlborough_untaxing_outstares_spectrological_alderliefest_Parcel-latin_intempestively}',1,0),(975,'dctf1337{disrank_archsacrificer_uneternized_cithren_Chalonnais_Dagusmines_ethnobiology_Spironema}',1,0),(976,'dctf1337{spin_pneumohydropericardium_IAB_Tenthredinoidea_unnegated_statorhab_supratrochlear_insatiety_baccilla_diphtheria}',1,0),(977,'dctf1337{nonremuneratively_posthepatic_budgerigah_phantasmogenetic_subvertically_waggonry_punishable_phosph-}',1,0),(978,'dctf1337{crural_hotlines_maltworm_unrowelled_world-overcoming_emblossom_undoffed}',1,0),(979,'dctf1337{frequenting_resow_sacrificing_clusterberry_asideness_dry-looking_liamba_transubstantiation}',1,0),(980,'dctf1337{baidarka_Velasco_machined_stopers_Tomi_Tindal_cutters}',1,0),(981,'dctf1337{jinglebob_Perelman_subpena_silvern_intercolumnar_jinkle_excitatory}',1,0),(982,'dctf1337{derbukka_Shelta_collieshangie_politically_outbustling_canvas-back_Huk_antieducationalist_contributively}',1,0),(983,'dctf1337{Yami_infusible_Vulpes_envisaging_Bienne_self-annealing_ministered_rucky_differers_fungiform}',1,0),(984,'dctf1337{antiquing_pelerin_photodisintegrate_injucundity_dictyostele_monestrous_ruralise_Xenopteri_said}',1,0),(985,'dctf1337{figurette_implausibility_Non-government_cumay_high-sea_baggage_paranephritic_unmannishly_tilth}',1,0),(986,'dctf1337{woadwaxes_aerophotography_Talisheek_meropodite_megacephalia_Honeywell_foreguts_outstrut_anaplasia_de-ethicization}',1,0),(987,'dctf1337{pharyngography_nugify_envelope_Climacium_Ifugao_Hsining_unfulgently_ever-smiling}',1,0),(988,'dctf1337{Elasmotherium_existences_primatological_refractivities_anthropogenetic_arfvedsonite_prejudicious_Trout}',1,0),(989,'dctf1337{emulous_felsophyre_reconfuse_tubboe_spuggy_riming_Garamond}',1,0),(990,'dctf1337{Aroostook_noncombustibles_caulocarpic_Non-pythagorean_leptoprosopous_remittable_gausterer_nulla-nulla_niding}',1,0),(991,'dctf1337{atsara_Conilurus_Olivet_SFRPG_Sonoita_manioc}',1,0),(992,'dctf1337{schoolmaster\'s_coffeeberries_possessivenesses_craneway_Komsomol_cystorrhaphy_encircles_impawn_bechatter}',1,0),(993,'dctf1337{indivinity_limpsy_pelioma_dalk_testudo_Rimsky-Korsakoff_nonpervertedly_pinacoline}',1,0),(994,'dctf1337{temadau_taeniae_superevangelical_potherb_strike-out_physogastrism}',1,0),(995,'dctf1337{epifaunal_fable-framing_homicides_praising_appanages_O\'Connor}',1,0),(996,'dctf1337{ATT_aphanesite_homeoplasia_henad_Sallyanne}',1,0),(997,'dctf1337{Suboscines_fog-blue_uncognized_day-flying_myelobrachium_Hanfurd_VDC_vestmentary_Juneflower}',1,0),(998,'dctf1337{winter-reared_mawkin_fonder_postposition_malshapen}',1,0),(999,'dctf1337{station-to-station_birefraction_pretranscribing_metacarpi_Allhallowtide_Coeloglossum_image-breaking}',1,0),(1000,'dctf1337{semball_uninflectedness_type\'s_dendrolater_refinding_chasing_swanhood_wringing-wet_half-wit}',1,0),(1001,'tweedling_lingered',1,1),(1002,'Deweyan',1,1),(1003,'overfalling',1,1),(1004,'Allisan',1,1),(1005,'leavening',1,1),(1006,'tiswin_Shaharith',1,1),(1007,'Pottiaceae',1,1),(1008,'pistoled_impersonalize',1,1),(1009,'imprisonable',1,1),(1010,'grippleness',1,1),(1011,'dosimeters_unconcluded',1,1),(1012,'matriculating_Dukas',1,1),(1013,'re-enjoin_Kerouac',1,1),(1014,'bluffness',1,1),(1015,'self-primed_Vannuys',1,1),(1016,'superpositions',1,1),(1017,'larynx_slow-combustion',1,1),(1018,'Feola_monoclinous',1,1),(1019,'mason\'s_mirex',1,1),(1020,'obols',1,1),(1021,'subway_ultraists',1,1),(1022,'Sauk',1,1),(1023,'bestiaries_unprescinded',1,1),(1024,'Temple_Celosia',1,1),(1025,'semispinalis',1,1),(1026,'Hatchechubbee',1,1),(1027,'manicate',1,1),(1028,'alts',1,1),(1029,'sinistrin',1,1),(1030,'unriveting',1,1),(1031,'crombec_semianarchistic',1,1),(1032,'Sanaa_integumation',1,1),(1033,'opinative',1,1),(1034,'convenientness',1,1),(1035,'suints_rearrive',1,1),(1036,'daemonistic_maftirs',1,1),(1037,'shunt',1,1),(1038,'embodiments',1,1),(1039,'ochlocracy',1,1),(1040,'fibrocrystalline_sades',1,1),(1041,'Frenchly',1,1),(1042,'chavibetol',1,1),(1043,'tamponage',1,1),(1044,'dogsbody',1,1),(1045,'mortorio_Damayanti',1,1),(1046,'intrenches_Morganne',1,1),(1047,'acleistocardia_MSgt',1,1),(1048,'washerwoman_matzoh',1,1),(1049,'sojas_belie-ve',1,1),(1050,'metabolon_self-disgracing',1,1),(1051,'Wodan_itineracy',1,1),(1052,'appliques_confest',1,1),(1053,'Psittacus_regrease',1,1),(1054,'amissibility',1,1),(1055,'jumbles_Karol',1,1),(1056,'neobotany_Middelburg',1,1),(1057,'cerebellocortex',1,1),(1058,'Acanthaceae_axemaster',1,1),(1059,'pseudobenefactory',1,1),(1060,'contraproposal',1,1),(1061,'ultrahot',1,1),(1062,'honestly',1,1),(1063,'overfee_phrasiness',1,1),(1064,'gesning_congenerous',1,1),(1065,'mucroniform',1,1),(1066,'Non-cymric',1,1),(1067,'reflow',1,1),(1068,'Englishwoman_Nereidae',1,1),(1069,'protiums',1,1),(1070,'Sybaritic_brainworker',1,1),(1071,'thiefproof',1,1),(1072,'Lophornis_plagiocephaly',1,1),(1073,'preterit-present',1,1),(1074,'pseudovum',1,1),(1075,'Emmen',1,1),(1076,'trade-off_geophones',1,1),(1077,'pericholecystitis',1,1),(1078,'Eucharistic_unretentiveness',1,1),(1079,'narcotism_postmaster-generalship',1,1),(1080,'foray\'s',1,1),(1081,'hydromagnetics_Tiffie',1,1),(1082,'hobblingly',1,1),(1083,'disadvantaged_collarinos',1,1),(1084,'debriefing_nonlethal',1,1),(1085,'ichorrhoea_hifalutin\'',1,1),(1086,'hazle',1,1),(1087,'intersonant_Latinising',1,1),(1088,'surfacedly_Daedalic',1,1),(1089,'mucronulatous',1,1),(1090,'foreanswer_upturn',1,1),(1091,'piquant',1,1),(1092,'Donell_deep-searching',1,1),(1093,'three-syllable_sugar-candy',1,1),(1094,'unassimilated',1,1),(1095,'cogweel_sneaker',1,1),(1096,'flittingly_self-maintenance',1,1),(1097,'Salpiglossis',1,1),(1098,'nonappendicular_Bigner',1,1),(1099,'six-chambered_subecho',1,1),(1100,'lapidaries_apertured',1,1),(1101,'prenaris',1,1),(1102,'immunising',1,1),(1103,'golach_statoscope',1,1),(1104,'flabby-cheeked_Gassville',1,1),(1105,'nuncioship_scoliometer',1,1),(1106,'oneirologist_needlewomen',1,1),(1107,'Uranoscopidae',1,1),(1108,'hayshock',1,1),(1109,'suffragial_longness',1,1),(1110,'mise-en-scene_Ardeae',1,1),(1111,'unequivocalness_quasi-cordial',1,1),(1112,'snuffman',1,1),(1113,'britons',1,1),(1114,'mosaicked_hodden',1,1),(1115,'wuthering',1,1),(1116,'steam-ridden',1,1),(1117,'shortcomer_bedunced',1,1),(1118,'pulmonectomy_aurae',1,1),(1119,'well-counselled',1,1),(1120,'eschaunge_ravelin',1,1),(1121,'chlorophenothane_fuze',1,1),(1122,'aldoheptose',1,1),(1123,'dolite_Royston',1,1),(1124,'impetrate',1,1),(1125,'atelostomia_juggernauts',1,1),(1126,'unslashed',1,1),(1127,'unpleasantry',1,1),(1128,'cloudburst_ferine',1,1),(1129,'IMarE',1,1),(1130,'Bunche',1,1),(1131,'unreported',1,1),(1132,'rubbery_innominata',1,1),(1133,'two-beat',1,1),(1134,'hyphopdia',1,1),(1135,'gay-hued',1,1),(1136,'unstorminess',1,1),(1137,'wolf-gray',1,1),(1138,'crenelles_chaff-weed',1,1),(1139,'superindustrious_nonmechanical',1,1),(1140,'ensnarer',1,1),(1141,'vaultiest_specific',1,1),(1142,'Skagway',1,1),(1143,'poorhouses_Pluviose',1,1),(1144,'Bolivar_capped',1,1),(1145,'straight-bodied_Ciliata',1,1),(1146,'Abkhasia_spavied',1,1),(1147,'noop',1,1),(1148,'unparty_deflorate',1,1),(1149,'botts',1,1),(1150,'Towbin_Rhizoflagellata',1,1),(1151,'leaflet_heroisms',1,1),(1152,'sextantal_burgus',1,1),(1153,'west-southwest_invigorations',1,1),(1154,'dissimulation_endosmotically',1,1),(1155,'Podargidae',1,1),(1156,'pollutes_romaunt',1,1),(1157,'hemaspectroscope',1,1),(1158,'evolutionistically',1,1),(1159,'Disini_Antarctogaean',1,1),(1160,'denitrificator',1,1),(1161,'Armado',1,1),(1162,'orthopsychiatric_crotchets',1,1),(1163,'cunt',1,1),(1164,'unliberalized',1,1),(1165,'carien',1,1),(1166,'Fables',1,1),(1167,'Derbies_mouse-eared',1,1),(1168,'Pega_autotype',1,1),(1169,'straightforwardest',1,1),(1170,'Babelic',1,1),(1171,'dallying',1,1),(1172,'rhombi_towght',1,1),(1173,'Vorster',1,1),(1174,'dopey_arduousness',1,1),(1175,'residuation_ejectamenta',1,1),(1176,'melanopathia_challengeful',1,1),(1177,'econometrician_can-cleaning',1,1),(1178,'undismissed',1,1),(1179,'Sorcha',1,1),(1180,'frampold_hiphuggers',1,1),(1181,'mealock_deceased',1,1),(1182,'robeless_philomathic',1,1),(1183,'seraskier_externalism',1,1),(1184,'Langhian',1,1),(1185,'Sobranje_asrama',1,1),(1186,'go-as-you-please_daddums',1,1),(1187,'stern-looking_golem',1,1),(1188,'appliance\'s',1,1),(1189,'militarism',1,1),(1190,'plaintail',1,1),(1191,'cubists_fastball',1,1),(1192,'carfour_Non-paninean',1,1),(1193,'derride',1,1),(1194,'categorical',1,1),(1195,'submeeting_reserviced',1,1),(1196,'scaups_well-contrived',1,1),(1197,'playing_mioplasmia',1,1),(1198,'knotweed_barratrous',1,1),(1199,'Ockham_agonistics',1,1),(1200,'crimpiness_hydrospace',1,1),(1201,'mimically_Asbury',1,1),(1202,'felicific',1,1),(1203,'wees',1,1),(1204,'uroptysis',1,1),(1205,'rackett_demonstrably',1,1),(1206,'spookery_turbogenerator',1,1),(1207,'bandle',1,1),(1208,'rebraced_prehensiveness',1,1),(1209,'denazification',1,1),(1210,'meese_brightest',1,1),(1211,'arrhenotoky',1,1),(1212,'enchaser_sulphureous',1,1),(1213,'electrically',1,1),(1214,'blamingly',1,1),(1215,'a-height',1,1),(1216,'mismeeting_world-deaf',1,1),(1217,'neurotoxic_Michey',1,1),(1218,'Pneumatomachist',1,1),(1219,'iconomatography',1,1),(1220,'slim-spired_upvalley',1,1),(1221,'well-lent_Ald',1,1),(1222,'warriorhood_gonfanon',1,1),(1223,'time-white',1,1),(1224,'unpleated_nullipara',1,1),(1225,'Ichneumonoidea_echolocation',1,1),(1226,'jasperize',1,1),(1227,'medicommissure_discolour',1,1),(1228,'nonpassenger',1,1),(1229,'reformeress_Zachariah',1,1),(1230,'unrequested',1,1),(1231,'ephemeromorphic',1,1),(1232,'Un-fenian',1,1),(1233,'unridableness',1,1),(1234,'grandisonous_usques',1,1),(1235,'defibrillatory_punctuationist',1,1),(1236,'tetanomotor_myzostomid',1,1),(1237,'CBEL',1,1),(1238,'snap-brim',1,1),(1239,'voltage_illegibleness',1,1),(1240,'tissue\'s',1,1),(1241,'septillion',1,1),(1242,'Assiniboine_thorascope',1,1),(1243,'worrywart',1,1),(1244,'reflow',1,1),(1245,'condictious_Malaysian',1,1),(1246,'ornamentalism',1,1),(1247,'allantiasis_unenglished',1,1),(1248,'preengagement_semisaturation',1,1),(1249,'profligacy',1,1),(1250,'Kentucky',1,1),(1251,'archdiocesan_IPDU',1,1),(1252,'overhaughtiness',1,1),(1253,'postexist',1,1),(1254,'Chaunce',1,1),(1255,'cocksuredom_Franco-american',1,1),(1256,'bead_panic-stricken',1,1),(1257,'ombrophile',1,1),(1258,'sable-suited_deliberated',1,1),(1259,'obelizing_ukases',1,1),(1260,'astrophotographic',1,1),(1261,'machin',1,1),(1262,'polypus',1,1),(1263,'backscratcher',1,1),(1264,'bursting',1,1),(1265,'meteorologists',1,1),(1266,'Procter_obsecrationary',1,1),(1267,'donor',1,1),(1268,'eloquentness_va-et-vien',1,1),(1269,'fairydom',1,1),(1270,'Tapaj',1,1),(1271,'gliadin_Nonius',1,1),(1272,'BPE',1,1),(1273,'Hokaltecan',1,1),(1274,'EOS_Bonduel',1,1),(1275,'fellmongering',1,1),(1276,'fordoing_borstall',1,1),(1277,'ill-treat',1,1),(1278,'fellage_octupling',1,1),(1279,'Weinstein_thermy',1,1),(1280,'undenunciatory_Cesena',1,1),(1281,'softhorn_slaky',1,1),(1282,'cryptanalysis',1,1),(1283,'tree-fringed_ravelproof',1,1),(1284,'micrograver_Westmorland',1,1),(1285,'Dagupan',1,1),(1286,'balladeroyal',1,1),(1287,'merosomatous',1,1),(1288,'theriacal',1,1),(1289,'ambivalences',1,1),(1290,'emulatory_unvolitioned',1,1),(1291,'emoloa',1,1),(1292,'Platycephalus_Minyades',1,1),(1293,'dustups_ocydromine',1,1),(1294,'bio-_inunctuosity',1,1),(1295,'tawpi',1,1),(1296,'rebreed_playsuit',1,1),(1297,'hydrologic_Lichas',1,1),(1298,'Jedda',1,1),(1299,'turf-spread',1,1),(1300,'dysrhythmia_Branchus',1,1),(1301,'secularisation',1,1),(1302,'topicalities',1,1),(1303,'Antido_reaggravate',1,1),(1304,'sitotoxism_stiction',1,1),(1305,'unimprinted',1,1),(1306,'disperser_tympanotomy',1,1),(1307,'glacialize_horse-dealing',1,1),(1308,'pistol_hypnograph',1,1),(1309,'algal-algal_cirro-cumular',1,1),(1310,'armbands_thirds',1,1),(1311,'deer\'s-tongue',1,1),(1312,'misbias',1,1),(1313,'unprospering',1,1),(1314,'chaetophoraceous',1,1),(1315,'duxelles_monophthongal',1,1),(1316,'rabbiters',1,1),(1317,'conciliationist',1,1),(1318,'Salix',1,1),(1319,'imbordure_Lithea',1,1),(1320,'phrased_jesuitries',1,1),(1321,'uncomputably_ornithomimid',1,1),(1322,'trawlerman',1,1),(1323,'unrestingness_vorticosely',1,1),(1324,'locustberry',1,1),(1325,'demiatheism',1,1),(1326,'simplicially_preinscribe',1,1),(1327,'Cemal',1,1),(1328,'curtate',1,1),(1329,'agoraphobiac',1,1),(1330,'paramorphism',1,1),(1331,'bourrasque',1,1),(1332,'wingier',1,1),(1333,'logwise_retractability',1,1),(1334,'structural-steel_Shepherdia',1,1),(1335,'pleurotyphoid_shole',1,1),(1336,'FLAG{its_',1,1),(1337,'Post-marxian',1,1),(1338,'unchattering_serpentinely',1,1),(1339,'philogenitiveness',1,1),(1340,'Dyane',1,1),(1341,'mishitting_Raquela',1,1),(1342,'discarded_ungainfulness',1,1),(1343,'pernor_spirit-fallen',1,1),(1344,'self-disgraced',1,1),(1345,'murines_shiphire',1,1),(1346,'ephebeibeia',1,1),(1347,'introgressant_postneuritic',1,1),(1348,'chasmy',1,1),(1349,'Italo-slav_stalked',1,1),(1350,'techily',1,1),(1351,'Dorinda',1,1),(1352,'hotsprings',1,1),(1353,'crooned',1,1),(1354,'Carleen_scuppernong',1,1),(1355,'overdecadent',1,1),(1356,'really_',1,1),(1357,'unstressedness_wordsmith',1,1),(1358,'menders',1,1),(1359,'diktat_backscatter',1,1),(1360,'really_',1,1),(1361,'misshapes_statutory',1,1),(1362,'trochees_catty-corner',1,1),(1363,'ruridecanal',1,1),(1364,'griffonne',1,1),(1365,'camouflager_Serjania',1,1),(1366,'Siphonata_weensier',1,1),(1367,'gilts_practicalize',1,1),(1368,'thester_allodiaries',1,1),(1369,'nonqualities_Carpathia',1,1),(1370,'lecherousnesses',1,1),(1371,'bureaucrat',1,1),(1372,'contemned_lactodensimeter',1,1),(1373,'decayedness',1,1),(1374,'ketohexose_spheroidic',1,1),(1375,'logo_midspace',1,1),(1376,'damning_thought-humbled',1,1),(1377,'dismembrated',1,1),(1378,'stranglement_preperfect',1,1),(1379,'sprawlers',1,1),(1380,'simplisms_strewed',1,1),(1381,'well-knit_amidid',1,1),(1382,'Ptarmica',1,1),(1383,'stroygood',1,1),(1384,'tromometry_hemodystrophy',1,1),(1385,'comforting',1,1),(1386,'woolies',1,1),(1387,'cattlemen_husbandman',1,1),(1388,'cellist',1,1),(1389,'exorcizes_rifledom',1,1),(1390,'undeferrably_chort',1,1),(1391,'splotched_cynopithecoid',1,1),(1392,'Binitarian',1,1),(1393,'nonfastidious_Blakeslee',1,1),(1394,'instiller_foreseat',1,1),(1395,'letting_flitterbat',1,1),(1396,'Anthon',1,1),(1397,'dehydratase_palatoglossus',1,1),(1398,'forehold',1,1),(1399,'midverse',1,1),(1400,'hercynite',1,1),(1401,'asexualise_hydroxycorticosterone',1,1),(1402,'sess_Bhutan',1,1),(1403,'Carvey',1,1),(1404,'Pitts_gunnies',1,1),(1405,'reinvestigation',1,1),(1406,'hilt',1,1),(1407,'terrane',1,1),(1408,'overdepend',1,1),(1409,'whirlpool\'s_saprobic',1,1),(1410,'Gradgrindism_petrifies',1,1),(1411,'garblings',1,1),(1412,'swannish',1,1),(1413,'exec_modicums',1,1),(1414,'amplexation',1,1),(1415,'guessy_',1,1),(1416,'Tennessean',1,1),(1417,'behoove_Peltigera',1,1),(1418,'orthodoxies_organizes',1,1),(1419,'gnawable_unstrap',1,1),(1420,'Tontobasin_thrums',1,1),(1421,'Maskell_subpodophyllous',1,1),(1422,'pisay_tapaderas',1,1),(1423,'tetricity_Auburndale',1,1),(1424,'garnetiferous',1,1),(1425,'bluffable',1,1),(1426,'direct-acting_stenochrome',1,1),(1427,'electromyogram_minchen',1,1),(1428,'extranatural',1,1),(1429,'Rifi',1,1),(1430,'sporocarp_Milvus',1,1),(1431,'glens',1,1),(1432,'oscula_washroad',1,1),(1433,'unmeritedness_quick-firing',1,1),(1434,'Gothurd_under-garment',1,1),(1435,'superduplication_fazing',1,1),(1436,'blanketry_venenose',1,1),(1437,'oilometer',1,1),(1438,'incensation',1,1),(1439,'twint_venging',1,1),(1440,'laparosplenectomy',1,1),(1441,'vilipends_bow-dyer',1,1),(1442,'morseled_amalgamist',1,1),(1443,'almond-leaved',1,1),(1444,'unwhimsicalness_paintably',1,1),(1445,'zwieselite_Pseudo-vergilian',1,1),(1446,'Anglo-spanish_pohutukawa',1,1),(1447,'unfeminising',1,1),(1448,'bite-sheep_deep-froze',1,1),(1449,'rippit_juncat',1,1),(1450,'myxobacteriaceous_louchettes',1,1),(1451,'figgiest',1,1),(1452,'oculopalpebral',1,1),(1453,'nonfashionably_saviours',1,1),(1454,'aardvarks_bescorched',1,1),(1455,'lymphogranuloma',1,1),(1456,'best-resolved',1,1),(1457,'daitya',1,1),(1458,'but_',1,1),(1459,'troper_netmen',1,1),(1460,'circlewise_sublet',1,1),(1461,'participations',1,1),(1462,'intendantship_anti-hog-cholera',1,1),(1463,'cordobas_unemended',1,1),(1464,'asset\'s',1,1),(1465,'recriticized_surrebutter',1,1),(1466,'Elka',1,1),(1467,'joists_wall-eyed',1,1),(1468,'odoriferous_eremites',1,1),(1469,'lotuslike',1,1),(1470,'echinuliform_chamal',1,1),(1471,'finnan_out-country',1,1),(1472,'endorsee',1,1),(1473,'goodnight_thiocarbamide',1,1),(1474,'once_',1,1),(1475,'unalloyed_precontrive',1,1),(1476,'jaunt_unosculated',1,1),(1477,'snooled_clethrionomys',1,1),(1478,'Sturmer_Pringle',1,1),(1479,'Flippin',1,1),(1480,'withstandingness',1,1),(1481,'Dordrecht_chiliomb',1,1),(1482,'antipornographic',1,1),(1483,'shapers',1,1),(1484,'reeking',1,1),(1485,'ketones',1,1),(1486,'prorevolutionary_differer',1,1),(1487,'Weapemeoc',1,1),(1488,'pits_Belzoni',1,1),(1489,'P.I.',1,1),(1490,'Dewart_onefold',1,1),(1491,'heart\'s-ease_viscously',1,1),(1492,'unlovableness',1,1),(1493,'Austell',1,1),(1494,'Caswell',1,1),(1495,'waise_archigastrula',1,1),(1496,'a_',1,1),(1497,'tallyho_cimcumvention',1,1),(1498,'segments',1,1),(1499,'spavied',1,1),(1500,'speronaras_Valonia',1,1),(1501,'Barron',1,1),(1502,'join-',1,1),(1503,'exposedness',1,1),(1504,'Morogoro',1,1),(1505,'apteran',1,1),(1506,'quadroons',1,1),(1507,'owl-wide_nosehole',1,1),(1508,'narcotico-acrid',1,1),(1509,'metaled',1,1),(1510,'Cariamae_untextural',1,1),(1511,'Talcott',1,1),(1512,'acetabulous_selectiveness',1,1),(1513,'perineural_refreshful',1,1),(1514,'fusil_pacifiers',1,1),(1515,'flag_',1,1),(1516,'alburnum_buzzing',1,1),(1517,'barba_fribblery',1,1),(1518,'larruped',1,1),(1519,'marikina',1,1),(1520,'Euclid',1,1),(1521,'incudectomy',1,1),(1522,'Slotnick',1,1),(1523,'will_',1,1),(1524,'remonstration_solider',1,1),(1525,'mesially',1,1),(1526,'Rainsville',1,1),(1527,'front-paged_Un-germanize',1,1),(1528,'half-one_VIC',1,1),(1529,'unabsent_ante-temple',1,1),(1530,'vacationed_endocondensation',1,1),(1531,'Kalamazoo',1,1),(1532,'promenader',1,1),(1533,'haustoria_B.C.L.',1,1),(1534,'mity_misgivings',1,1),(1535,'Iliac',1,1),(1536,'overcredulousness',1,1),(1537,'mininations_antiprojectivity',1,1),(1538,'ephemerist',1,1),(1539,'Dorri',1,1),(1540,'prefortunately',1,1),(1541,'tundras',1,1),(1542,'Strongyloides',1,1),(1543,'incumber',1,1),(1544,'appendix',1,1),(1545,'maxwells_bairns',1,1),(1546,'cuvies_dulse',1,1),(1547,'Alain',1,1),(1548,'Kelliher',1,1),(1549,'kisses_ralstonite',1,1),(1550,'fevertrap_pertinate',1,1),(1551,'lumpmen',1,1),(1552,'biogeochemical',1,1),(1553,'mickies_lymphs',1,1),(1554,'mandril',1,1),(1555,'bee-butt',1,1),(1556,'sick-brained',1,1),(1557,'uniaxal',1,1),(1558,'shepstare_eclat',1,1),(1559,'always_',1,1),(1560,'unjaded_wiry-stemmed',1,1),(1561,'dekagram',1,1),(1562,'agonize_Tammanyize',1,1),(1563,'antimonial_contemplator',1,1),(1564,'cannibals_nettlefoot',1,1),(1565,'collaborator\'s',1,1),(1566,'paradoxist',1,1),(1567,'wombside_sprinters',1,1),(1568,'arace_regimes',1,1),(1569,'consortial',1,1),(1570,'sea-driven',1,1),(1571,'Norby',1,1),(1572,'hittable_postgame',1,1),(1573,'Megaceros_villenage',1,1),(1574,'diphosgene_Boghazkoy',1,1),(1575,'semideific_mazedness',1,1),(1576,'dichotomous_bicarb',1,1),(1577,'brucine',1,1),(1578,'saimin_orthotomic',1,1),(1579,'pneumatogram_Aetna',1,1),(1580,'peripherical',1,1),(1581,'postpaludal_nonnihilism',1,1),(1582,'Papp',1,1),(1583,'omental',1,1),(1584,'phyllopodan_particularised',1,1),(1585,'biospheres_jef',1,1),(1586,'delibate',1,1),(1587,'englacially',1,1),(1588,'approve',1,1),(1589,'preaching_separte',1,1),(1590,'Achab_splanchnesthesia',1,1),(1591,'home-brew',1,1),(1592,'suppedanea_Pathrusim',1,1),(1593,'caucussed',1,1),(1594,'ringbone',1,1),(1595,'pretortured_scabia',1,1),(1596,'lineameter_raphide',1,1),(1597,'agilawood_descriptivism',1,1),(1598,'hydradephagous',1,1),(1599,'kinsfolk_Chirac',1,1),(1600,'half-whispered_Breeding',1,1),(1601,'overgentle_expatiators',1,1),(1602,'pseudapostle_pigstick',1,1),(1603,'Sankara',1,1),(1604,'pseudopagan',1,1),(1605,'Behmenism',1,1),(1606,'SMSA_orenda',1,1),(1607,'paleontography',1,1),(1608,'fine-threaded',1,1),(1609,'S.R.O.',1,1),(1610,'embrasure',1,1),(1611,'Hollywood_modiation',1,1),(1612,'caesaropapist',1,1),(1613,'relented_miosis',1,1),(1614,'homotaxic_lightface',1,1),(1615,'remain_',1,1),(1616,'cachets',1,1),(1617,'herd-boy',1,1),(1618,'unclimaxed_bepimples',1,1),(1619,'nimble-heeled',1,1),(1620,'quixotic',1,1),(1621,'dyskinetic_pechay',1,1),(1622,'psilosophy',1,1),(1623,'manoir_between-deck',1,1),(1624,'adoptedly',1,1),(1625,'Docetist',1,1),(1626,'hecatomped',1,1),(1627,'motherhoods',1,1),(1628,'Pasteurelleae_Chichester',1,1),(1629,'hylarchic_contenders',1,1),(1630,'contrastive_unluxuriant',1,1),(1631,'jughead_incompossible',1,1),(1632,'tarryiest_As-yakh',1,1),(1633,'drownds',1,1),(1634,'ductilized_wisking',1,1),(1635,'unfanciful',1,1),(1636,'uncalumniously_isoalloxazine',1,1),(1637,'safeguarded_bimbil',1,1),(1638,'glycerine_low-lying',1,1),(1639,'unspit_cochlitis',1,1),(1640,'Yates',1,1),(1641,'overcommendation',1,1),(1642,'electroresection',1,1),(1643,'rackett_inspissation',1,1),(1644,'sleep-walker_cladoniaceous',1,1),(1645,'nidificated_well-knowledged',1,1),(1646,'gromil',1,1),(1647,'Wassyngton_miscurvature',1,1),(1648,'shivah',1,1),(1649,'geosphere_expound',1,1),(1650,'undercanopy_fixed',1,1),(1651,'obstination',1,1),(1652,'raspberriade',1,1),(1653,'rose-colorist',1,1),(1654,'semihaness',1,1),(1655,'Blinni_chlorotrifluoroethylene',1,1),(1656,'Aktiengesellschaft_jambarts',1,1),(1657,'Oswegan_scyphate',1,1),(1658,'graven',1,1),(1659,'ovals',1,1),(1660,'collegians_periodontitis',1,1),(1661,'sailmaker_hyperessence',1,1),(1662,'cerebroside_foolish-wise',1,1),(1663,'resistlessly_badges',1,1),(1664,'transboard',1,1),(1665,'escadrille',1,1),(1666,'to_',1,1),(1667,'laser\'s',1,1),(1668,'halal',1,1),(1669,'arbusterol',1,1),(1670,'thinned_malurine',1,1),(1671,'be_',1,1),(1672,'addable',1,1),(1673,'BAMusEd_pride-bloated',1,1),(1674,'onery',1,1),(1675,'cupreine_seroprotease',1,1),(1676,'Micronesian',1,1),(1677,'imboldens_jacksnipes',1,1),(1678,'asserve_Watala',1,1),(1679,'crustier_derabbinize',1,1),(1680,'shiftingly_arcuated',1,1),(1681,'suivante_dwining',1,1),(1682,'teleosaur',1,1),(1683,'pyrexia_Isla',1,1),(1684,'indivisible_wide-shaped',1,1),(1685,'brevities_unbar',1,1),(1686,'charlatan',1,1),(1687,'Kraemer_precaval',1,1),(1688,'administrator',1,1),(1689,'truthy',1,1),(1690,'empanada_Tollmann',1,1),(1691,'Kilpatrick',1,1),(1692,'pf.',1,1),(1693,'lysimetric_heighth',1,1),(1694,'rickstaddle',1,1),(1695,'lamelli-',1,1),(1696,'Compoboard_Rittman',1,1),(1697,'proboscidiform',1,1),(1698,'tempest-scoffing',1,1),(1699,'voyaged',1,1),(1700,'acuating',1,1),(1701,'chaperon_launderess',1,1),(1702,'cryptaesthesia',1,1),(1703,'inculture',1,1),(1704,'monilethrix_Boronia',1,1),(1705,'coroplasta_discoloring',1,1),(1706,'habitualize_dish-crowned',1,1),(1707,'Alternaria',1,1),(1708,'over-train_prognose',1,1),(1709,'contracivil_antifeudalistic',1,1),(1710,'readaptable_root-neck',1,1),(1711,'linkedness_all-jarred',1,1),(1712,'unhardness_grandparentage',1,1),(1713,'postfertilizations_cappelenite',1,1),(1714,'trophism_Vyborg',1,1),(1715,'Corrinne_taeniacide',1,1),(1716,'Bros_soarings',1,1),(1717,'Ignatia_nymphets',1,1),(1718,'chairmanning_dauntless',1,1),(1719,'Kans.',1,1),(1720,'south-facing',1,1),(1721,'smutchin',1,1),(1722,'re-reflection_unprismatic',1,1),(1723,'chilblains',1,1),(1724,'prioritized_sclereid',1,1),(1725,'naphtol',1,1),(1726,'LISA',1,1),(1727,'bravade_halyard',1,1),(1728,'organy_appriser',1,1),(1729,'rutting_cuspidors',1,1),(1730,'unreasoningly_melolonthid',1,1),(1731,'ravellings_disannulment',1,1),(1732,'wennebergite',1,1),(1733,'babbly',1,1),(1734,'Deut',1,1),(1735,'windwardmost_Satsuma',1,1),(1736,'scrives_musting',1,1),(1737,'whate\'er_gastroenteritis',1,1),(1738,'peris_squarishness',1,1),(1739,'flag}',1,1),(1740,'percent_depressions',1,1),(1741,'square-bottomed',1,1),(1742,'Anti_parietoquadrate',1,1),(1743,'mesally_outcompass',1,1),(1744,'preapproved_rebosos',1,1),(1745,'Oschophoria_wyclifian',1,1),(1746,'aweband_undefatigable',1,1),(1747,'Tedder',1,1),(1748,'rainspout',1,1),(1749,'Ehretiaceae',1,1),(1750,'autarchist_sulphin',1,1),(1751,'flatwash',1,1),(1752,'duppa_world-moving',1,1),(1753,'cephalopathy',1,1),(1754,'plebeianise_Malebranchism',1,1),(1755,'weened_bog',1,1),(1756,'revary_defigure',1,1),(1757,'cephalomyitis_schematism',1,1),(1758,'bandages',1,1),(1759,'UT_Seamus',1,1),(1760,'exheredation_guitarist',1,1),(1761,'Micromeria',1,1),(1762,'Thamora_quartenylic',1,1),(1763,'re-evolution',1,1),(1764,'myology',1,1),(1765,'peritoneums_gratuitousness',1,1),(1766,'dextrorotary',1,1),(1767,'succeeding',1,1),(1768,'mouslingly_functionaries',1,1),(1769,'unpossibleness',1,1),(1770,'halsfang',1,1),(1771,'Mingrelian',1,1),(1772,'quadrivalve',1,1),(1773,'Avan_toilinet',1,1),(1774,'roadability',1,1),(1775,'pre-Jewish',1,1),(1776,'unendured',1,1),(1777,'Gladsheim_retroreflector',1,1),(1778,'fern-leaved_Avonne',1,1),(1779,'Hughett',1,1),(1780,'caning_runround',1,1),(1781,'harborough',1,1),(1782,'photoluminescent_brothier',1,1),(1783,'monomyarian',1,1),(1784,'overanalyzely',1,1),(1785,'penuries_Arbyrd',1,1),(1786,'dunner_demasculinize',1,1),(1787,'intercept_Gerius',1,1),(1788,'refrigerated_odoriferant',1,1),(1789,'undoctrinal_dichroic',1,1),(1790,'vales_Mullane',1,1),(1791,'initialness_spaders',1,1),(1792,'epidemic',1,1),(1793,'unstainableness',1,1),(1794,'nonstudents_missuses',1,1),(1795,'nonfossiliferous_facette',1,1),(1796,'yodelist',1,1),(1797,'strange-colored',1,1),(1798,'helcology',1,1),(1799,'unsoporiferous_lazurites',1,1),(1800,'rhymer',1,1),(1801,'pastness_avile',1,1),(1802,'gutturally_xylems',1,1),(1803,'one-many',1,1),(1804,'overwroth_chondrogenesis',1,1),(1805,'Priapulida',1,1),(1806,'rosy-tinted',1,1),(1807,'grungy_forecovert',1,1),(1808,'nonambulaties',1,1),(1809,'siting_downtake',1,1),(1810,'pothooks_preteen',1,1),(1811,'straphanger',1,1),(1812,'untracted_reportage',1,1),(1813,'bocasin_sharp-sighted',1,1),(1814,'trpset_amblypod',1,1),(1815,'fenester',1,1),(1816,'frailly',1,1),(1817,'immunodiffusion',1,1),(1818,'melon-laden',1,1),(1819,'misspent_sitcoms',1,1),(1820,'unladled_zibethone',1,1),(1821,'rhyparographic_sphincteroscopy',1,1),(1822,'skrike',1,1),(1823,'earners',1,1),(1824,'senate\'s',1,1),(1825,'papize_dreamy-minded',1,1),(1826,'redbug',1,1),(1827,'metabolites_issite',1,1),(1828,'bierkeller',1,1),(1829,'segmented_flogged',1,1),(1830,'ich_kermesic',1,1),(1831,'pentagynian',1,1),(1832,'septendecillions_oftener',1,1),(1833,'Epilobiaceae',1,1),(1834,'Adorantes_cachinnation',1,1),(1835,'crude',1,1),(1836,'rebate\'s',1,1),(1837,'analphabetism_vitaminic',1,1),(1838,'ESPEC_Gusba',1,1),(1839,'prepositional',1,1),(1840,'rebroadcasted_helleries',1,1),(1841,'Tilli',1,1),(1842,'melicerous',1,1),(1843,'oligemia_caviling',1,1),(1844,'shintoists_great-spirited',1,1),(1845,'seized_disseise',1,1),(1846,'sprightlier_FACOM',1,1),(1847,'trompe',1,1),(1848,'trochocephaly',1,1),(1849,'shikasta',1,1),(1850,'Kaye_desaturation',1,1),(1851,'sonobuoy_antigropelos',1,1),(1852,'telesthetic_Wenzel',1,1),(1853,'neurokeratin_bacchiuchii',1,1),(1854,'willowweed_uneugenic',1,1),(1855,'cystidicolous_asthmatically',1,1),(1856,'reparked',1,1),(1857,'investigation_switched',1,1),(1858,'life-bringing_Limnorchis',1,1),(1859,'provident',1,1),(1860,'nondisruptive',1,1),(1861,'soulheal',1,1),(1862,'minuetic',1,1),(1863,'twice-chosen',1,1),(1864,'avos_spends',1,1),(1865,'Hinduize',1,1),(1866,'unlifelike',1,1),(1867,'rug-cutting',1,1),(1868,'Sinaloa_strongmen',1,1),(1869,'cystophthisis_misnomed',1,1),(1870,'tractor\'s_nonopprobriously',1,1),(1871,'Venutian_ragery',1,1),(1872,'Luddism_twitchiest',1,1),(1873,'nun-buoy_lentils',1,1),(1874,'extenuatingly',1,1),(1875,'elegiambic',1,1),(1876,'turves_Stowell',1,1),(1877,'lacuna',1,1),(1878,'coregnancy',1,1),(1879,'rediae_langrels',1,1),(1880,'colpohysterotomy',1,1),(1881,'false-plighted_life-lorn',1,1),(1882,'hobbyhorses',1,1),(1883,'geoplagiotropism_lepidoblastic',1,1),(1884,'phytome',1,1),(1885,'inebriant_stiller',1,1),(1886,'narrow-headed_adinole',1,1),(1887,'wakandas',1,1),(1888,'retinophore',1,1),(1889,'VDM_phloro-',1,1),(1890,'Velquez_unclassifiable',1,1),(1891,'untantalized_rumpot',1,1),(1892,'nongilled',1,1),(1893,'Ricki_fixures',1,1),(1894,'abuzz',1,1),(1895,'photoelectric_tubuli',1,1),(1896,'scrap-book',1,1),(1897,'appetitiveness',1,1),(1898,'delivery_backstromite',1,1),(1899,'truller_aleurometer',1,1),(1900,'scioptics',1,1),(1901,'hookweed',1,1),(1902,'guardrooms',1,1),(1903,'Mariel_indoor',1,1),(1904,'antepileptic',1,1),(1905,'theomachia_ground-floor',1,1),(1906,'Homadus',1,1),(1907,'altaite',1,1),(1908,'impinge_frizzing',1,1),(1909,'billets-doux',1,1),(1910,'undereate_rough-and-readiness',1,1),(1911,'sponger',1,1),(1912,'limbered_praise-fed',1,1),(1913,'Bundoora_postpycnotic',1,1),(1914,'organized_pseudospermic',1,1),(1915,'God-sped_hysterotome',1,1),(1916,'vibrated',1,1),(1917,'subfunctional_assemblages',1,1),(1918,'sinapine_hyperbaric',1,1),(1919,'misadapted',1,1),(1920,'laceless',1,1),(1921,'thought-laden',1,1),(1922,'dugs',1,1),(1923,'Acalypha',1,1),(1924,'yald',1,1),(1925,'Owlshead',1,1),(1926,'prodigalize_life-devouring',1,1),(1927,'Bulfinch',1,1),(1928,'unsmoothness',1,1),(1929,'enlargeableness',1,1),(1930,'Karaism',1,1),(1931,'Cinnamomum',1,1),(1932,'nonfricative',1,1),(1933,'Nietzscheism_masterproof',1,1),(1934,'Yarborough_epigonos',1,1),(1935,'tallowing_porosimeter',1,1),(1936,'ichnite_decoyed',1,1),(1937,'Magalensia_prescan',1,1),(1938,'nonsentient_fluemen',1,1),(1939,'Maceio',1,1),(1940,'anointed',1,1),(1941,'Caelian',1,1),(1942,'overline',1,1),(1943,'Pickford',1,1),(1944,'rageless',1,1),(1945,'paraffiner',1,1),(1946,'octothorpe',1,1),(1947,'greenskeeper_veratrina',1,1),(1948,'Tetrandria_soul-delighting',1,1),(1949,'proxeny',1,1),(1950,'niggardliness',1,1),(1951,'indure_parkee',1,1),(1952,'macrencephalous',1,1),(1953,'ureterolithotomies_bow-legged',1,1),(1954,'eaten_Althee',1,1),(1955,'homoiothermal',1,1),(1956,'hondling',1,1),(1957,'quila_mentimeter',1,1),(1958,'multicolored_ballonnes',1,1),(1959,'Tallahassee_place-kick',1,1),(1960,'taper-headed',1,1),(1961,'prevenances',1,1),(1962,'kionectomies_Kiel',1,1),(1963,'Grubbs',1,1),(1964,'epilept-',1,1),(1965,'cockhorses_Heraclitus',1,1),(1966,'woodsheddi',1,1),(1967,'unwarlike',1,1),(1968,'quaintness',1,1),(1969,'quasi-internationally_twice-garbed',1,1),(1970,'agaric',1,1),(1971,'nontenable_overobediently',1,1),(1972,'squidgier',1,1),(1973,'defeat',1,1),(1974,'supernumerous',1,1),(1975,'citrination',1,1),(1976,'incommunicated',1,1),(1977,'unwithstanding',1,1),(1978,'subtitles_placebos',1,1),(1979,'supermini_hurleys',1,1),(1980,'coldong_microphysics',1,1),(1981,'emptive_huffaker',1,1),(1982,'oleorefractometer',1,1),(1983,'photographee_booley',1,1),(1984,'unrepresentation',1,1),(1985,'parergic',1,1),(1986,'imbedding',1,1),(1987,'logic\'s_bonetta',1,1),(1988,'arm-linked_unscored',1,1),(1989,'trifanious',1,1),(1990,'papable',1,1),(1991,'guru_Bath-sheba',1,1),(1992,'abstersive_paronomasian',1,1),(1993,'Sudetes',1,1),(1994,'archhypocrisy',1,1),(1995,'rootlessness_tanwood',1,1),(1996,'netherstone',1,1),(1997,'brachycephalies',1,1),(1998,'quasi-compliantly',1,1),(1999,'Alaster',1,1),(2000,'Donoho_Damle',1,1);
/*!40000 ALTER TABLE `FL4GH0LD3R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FMY2P8H7KU`
--

DROP TABLE IF EXISTS `FMY2P8H7KU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FMY2P8H7KU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FMY2P8H7KU`
--

LOCK TABLES `FMY2P8H7KU` WRITE;
/*!40000 ALTER TABLE `FMY2P8H7KU` DISABLE KEYS */;
/*!40000 ALTER TABLE `FMY2P8H7KU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FN81G7A19T`
--

DROP TABLE IF EXISTS `FN81G7A19T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FN81G7A19T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FN81G7A19T`
--

LOCK TABLES `FN81G7A19T` WRITE;
/*!40000 ALTER TABLE `FN81G7A19T` DISABLE KEYS */;
/*!40000 ALTER TABLE `FN81G7A19T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FODF2ULKWQ`
--

DROP TABLE IF EXISTS `FODF2ULKWQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FODF2ULKWQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FODF2ULKWQ`
--

LOCK TABLES `FODF2ULKWQ` WRITE;
/*!40000 ALTER TABLE `FODF2ULKWQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `FODF2ULKWQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FOV2JCKPY7`
--

DROP TABLE IF EXISTS `FOV2JCKPY7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FOV2JCKPY7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FOV2JCKPY7`
--

LOCK TABLES `FOV2JCKPY7` WRITE;
/*!40000 ALTER TABLE `FOV2JCKPY7` DISABLE KEYS */;
/*!40000 ALTER TABLE `FOV2JCKPY7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FPLUGOVD05`
--

DROP TABLE IF EXISTS `FPLUGOVD05`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FPLUGOVD05` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FPLUGOVD05`
--

LOCK TABLES `FPLUGOVD05` WRITE;
/*!40000 ALTER TABLE `FPLUGOVD05` DISABLE KEYS */;
/*!40000 ALTER TABLE `FPLUGOVD05` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FQUDERITJZ`
--

DROP TABLE IF EXISTS `FQUDERITJZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FQUDERITJZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FQUDERITJZ`
--

LOCK TABLES `FQUDERITJZ` WRITE;
/*!40000 ALTER TABLE `FQUDERITJZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `FQUDERITJZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSXTJ6YDCT`
--

DROP TABLE IF EXISTS `FSXTJ6YDCT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FSXTJ6YDCT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSXTJ6YDCT`
--

LOCK TABLES `FSXTJ6YDCT` WRITE;
/*!40000 ALTER TABLE `FSXTJ6YDCT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FSXTJ6YDCT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FT07WWYS5X`
--

DROP TABLE IF EXISTS `FT07WWYS5X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FT07WWYS5X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FT07WWYS5X`
--

LOCK TABLES `FT07WWYS5X` WRITE;
/*!40000 ALTER TABLE `FT07WWYS5X` DISABLE KEYS */;
/*!40000 ALTER TABLE `FT07WWYS5X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FTE3X3U3YB`
--

DROP TABLE IF EXISTS `FTE3X3U3YB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FTE3X3U3YB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FTE3X3U3YB`
--

LOCK TABLES `FTE3X3U3YB` WRITE;
/*!40000 ALTER TABLE `FTE3X3U3YB` DISABLE KEYS */;
/*!40000 ALTER TABLE `FTE3X3U3YB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FWOLJ993ZB`
--

DROP TABLE IF EXISTS `FWOLJ993ZB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FWOLJ993ZB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FWOLJ993ZB`
--

LOCK TABLES `FWOLJ993ZB` WRITE;
/*!40000 ALTER TABLE `FWOLJ993ZB` DISABLE KEYS */;
/*!40000 ALTER TABLE `FWOLJ993ZB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FWZUY819R7`
--

DROP TABLE IF EXISTS `FWZUY819R7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FWZUY819R7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FWZUY819R7`
--

LOCK TABLES `FWZUY819R7` WRITE;
/*!40000 ALTER TABLE `FWZUY819R7` DISABLE KEYS */;
/*!40000 ALTER TABLE `FWZUY819R7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FZ3PA9N3VE`
--

DROP TABLE IF EXISTS `FZ3PA9N3VE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FZ3PA9N3VE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FZ3PA9N3VE`
--

LOCK TABLES `FZ3PA9N3VE` WRITE;
/*!40000 ALTER TABLE `FZ3PA9N3VE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FZ3PA9N3VE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `G00A4JBD2U`
--

DROP TABLE IF EXISTS `G00A4JBD2U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `G00A4JBD2U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `G00A4JBD2U`
--

LOCK TABLES `G00A4JBD2U` WRITE;
/*!40000 ALTER TABLE `G00A4JBD2U` DISABLE KEYS */;
/*!40000 ALTER TABLE `G00A4JBD2U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `G0LGSSB5HN`
--

DROP TABLE IF EXISTS `G0LGSSB5HN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `G0LGSSB5HN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `G0LGSSB5HN`
--

LOCK TABLES `G0LGSSB5HN` WRITE;
/*!40000 ALTER TABLE `G0LGSSB5HN` DISABLE KEYS */;
/*!40000 ALTER TABLE `G0LGSSB5HN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `G1YE1A9A63`
--

DROP TABLE IF EXISTS `G1YE1A9A63`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `G1YE1A9A63` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `G1YE1A9A63`
--

LOCK TABLES `G1YE1A9A63` WRITE;
/*!40000 ALTER TABLE `G1YE1A9A63` DISABLE KEYS */;
/*!40000 ALTER TABLE `G1YE1A9A63` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `G4CW3Z0375`
--

DROP TABLE IF EXISTS `G4CW3Z0375`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `G4CW3Z0375` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `G4CW3Z0375`
--

LOCK TABLES `G4CW3Z0375` WRITE;
/*!40000 ALTER TABLE `G4CW3Z0375` DISABLE KEYS */;
/*!40000 ALTER TABLE `G4CW3Z0375` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `G6NW6E4QHY`
--

DROP TABLE IF EXISTS `G6NW6E4QHY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `G6NW6E4QHY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `G6NW6E4QHY`
--

LOCK TABLES `G6NW6E4QHY` WRITE;
/*!40000 ALTER TABLE `G6NW6E4QHY` DISABLE KEYS */;
/*!40000 ALTER TABLE `G6NW6E4QHY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GB6CW3I7TC`
--

DROP TABLE IF EXISTS `GB6CW3I7TC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GB6CW3I7TC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GB6CW3I7TC`
--

LOCK TABLES `GB6CW3I7TC` WRITE;
/*!40000 ALTER TABLE `GB6CW3I7TC` DISABLE KEYS */;
/*!40000 ALTER TABLE `GB6CW3I7TC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GBKWB6D4XN`
--

DROP TABLE IF EXISTS `GBKWB6D4XN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GBKWB6D4XN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GBKWB6D4XN`
--

LOCK TABLES `GBKWB6D4XN` WRITE;
/*!40000 ALTER TABLE `GBKWB6D4XN` DISABLE KEYS */;
/*!40000 ALTER TABLE `GBKWB6D4XN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GBN7FXENLG`
--

DROP TABLE IF EXISTS `GBN7FXENLG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GBN7FXENLG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GBN7FXENLG`
--

LOCK TABLES `GBN7FXENLG` WRITE;
/*!40000 ALTER TABLE `GBN7FXENLG` DISABLE KEYS */;
/*!40000 ALTER TABLE `GBN7FXENLG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GCGNVS6MI4`
--

DROP TABLE IF EXISTS `GCGNVS6MI4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GCGNVS6MI4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GCGNVS6MI4`
--

LOCK TABLES `GCGNVS6MI4` WRITE;
/*!40000 ALTER TABLE `GCGNVS6MI4` DISABLE KEYS */;
/*!40000 ALTER TABLE `GCGNVS6MI4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GE2E2QW11H`
--

DROP TABLE IF EXISTS `GE2E2QW11H`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GE2E2QW11H` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GE2E2QW11H`
--

LOCK TABLES `GE2E2QW11H` WRITE;
/*!40000 ALTER TABLE `GE2E2QW11H` DISABLE KEYS */;
/*!40000 ALTER TABLE `GE2E2QW11H` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GG8FB7SVVJ`
--

DROP TABLE IF EXISTS `GG8FB7SVVJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GG8FB7SVVJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GG8FB7SVVJ`
--

LOCK TABLES `GG8FB7SVVJ` WRITE;
/*!40000 ALTER TABLE `GG8FB7SVVJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `GG8FB7SVVJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GLV5TTQW0I`
--

DROP TABLE IF EXISTS `GLV5TTQW0I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GLV5TTQW0I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GLV5TTQW0I`
--

LOCK TABLES `GLV5TTQW0I` WRITE;
/*!40000 ALTER TABLE `GLV5TTQW0I` DISABLE KEYS */;
/*!40000 ALTER TABLE `GLV5TTQW0I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GMO9XIN7XZ`
--

DROP TABLE IF EXISTS `GMO9XIN7XZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GMO9XIN7XZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GMO9XIN7XZ`
--

LOCK TABLES `GMO9XIN7XZ` WRITE;
/*!40000 ALTER TABLE `GMO9XIN7XZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `GMO9XIN7XZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GPIXX0OQWA`
--

DROP TABLE IF EXISTS `GPIXX0OQWA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GPIXX0OQWA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPIXX0OQWA`
--

LOCK TABLES `GPIXX0OQWA` WRITE;
/*!40000 ALTER TABLE `GPIXX0OQWA` DISABLE KEYS */;
/*!40000 ALTER TABLE `GPIXX0OQWA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GPUGNMK2WL`
--

DROP TABLE IF EXISTS `GPUGNMK2WL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GPUGNMK2WL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPUGNMK2WL`
--

LOCK TABLES `GPUGNMK2WL` WRITE;
/*!40000 ALTER TABLE `GPUGNMK2WL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GPUGNMK2WL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GRF0E9Y1BR`
--

DROP TABLE IF EXISTS `GRF0E9Y1BR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GRF0E9Y1BR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GRF0E9Y1BR`
--

LOCK TABLES `GRF0E9Y1BR` WRITE;
/*!40000 ALTER TABLE `GRF0E9Y1BR` DISABLE KEYS */;
/*!40000 ALTER TABLE `GRF0E9Y1BR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GS2CQYBQ42`
--

DROP TABLE IF EXISTS `GS2CQYBQ42`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GS2CQYBQ42` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GS2CQYBQ42`
--

LOCK TABLES `GS2CQYBQ42` WRITE;
/*!40000 ALTER TABLE `GS2CQYBQ42` DISABLE KEYS */;
/*!40000 ALTER TABLE `GS2CQYBQ42` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GTC8QBR537`
--

DROP TABLE IF EXISTS `GTC8QBR537`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GTC8QBR537` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GTC8QBR537`
--

LOCK TABLES `GTC8QBR537` WRITE;
/*!40000 ALTER TABLE `GTC8QBR537` DISABLE KEYS */;
/*!40000 ALTER TABLE `GTC8QBR537` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GTWDSOZKYB`
--

DROP TABLE IF EXISTS `GTWDSOZKYB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GTWDSOZKYB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GTWDSOZKYB`
--

LOCK TABLES `GTWDSOZKYB` WRITE;
/*!40000 ALTER TABLE `GTWDSOZKYB` DISABLE KEYS */;
/*!40000 ALTER TABLE `GTWDSOZKYB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GUPEKBO4EE`
--

DROP TABLE IF EXISTS `GUPEKBO4EE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GUPEKBO4EE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GUPEKBO4EE`
--

LOCK TABLES `GUPEKBO4EE` WRITE;
/*!40000 ALTER TABLE `GUPEKBO4EE` DISABLE KEYS */;
/*!40000 ALTER TABLE `GUPEKBO4EE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GVV02UZQE8`
--

DROP TABLE IF EXISTS `GVV02UZQE8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GVV02UZQE8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GVV02UZQE8`
--

LOCK TABLES `GVV02UZQE8` WRITE;
/*!40000 ALTER TABLE `GVV02UZQE8` DISABLE KEYS */;
/*!40000 ALTER TABLE `GVV02UZQE8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GWYA1RL6HT`
--

DROP TABLE IF EXISTS `GWYA1RL6HT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GWYA1RL6HT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GWYA1RL6HT`
--

LOCK TABLES `GWYA1RL6HT` WRITE;
/*!40000 ALTER TABLE `GWYA1RL6HT` DISABLE KEYS */;
/*!40000 ALTER TABLE `GWYA1RL6HT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GXAWWLTFR4`
--

DROP TABLE IF EXISTS `GXAWWLTFR4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GXAWWLTFR4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GXAWWLTFR4`
--

LOCK TABLES `GXAWWLTFR4` WRITE;
/*!40000 ALTER TABLE `GXAWWLTFR4` DISABLE KEYS */;
/*!40000 ALTER TABLE `GXAWWLTFR4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GXQZS71K2K`
--

DROP TABLE IF EXISTS `GXQZS71K2K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GXQZS71K2K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GXQZS71K2K`
--

LOCK TABLES `GXQZS71K2K` WRITE;
/*!40000 ALTER TABLE `GXQZS71K2K` DISABLE KEYS */;
/*!40000 ALTER TABLE `GXQZS71K2K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GZACV91Z3E`
--

DROP TABLE IF EXISTS `GZACV91Z3E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GZACV91Z3E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GZACV91Z3E`
--

LOCK TABLES `GZACV91Z3E` WRITE;
/*!40000 ALTER TABLE `GZACV91Z3E` DISABLE KEYS */;
/*!40000 ALTER TABLE `GZACV91Z3E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H1K88HPUF6`
--

DROP TABLE IF EXISTS `H1K88HPUF6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H1K88HPUF6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H1K88HPUF6`
--

LOCK TABLES `H1K88HPUF6` WRITE;
/*!40000 ALTER TABLE `H1K88HPUF6` DISABLE KEYS */;
/*!40000 ALTER TABLE `H1K88HPUF6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H1NFZD51MK`
--

DROP TABLE IF EXISTS `H1NFZD51MK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H1NFZD51MK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H1NFZD51MK`
--

LOCK TABLES `H1NFZD51MK` WRITE;
/*!40000 ALTER TABLE `H1NFZD51MK` DISABLE KEYS */;
/*!40000 ALTER TABLE `H1NFZD51MK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H32QOIM02S`
--

DROP TABLE IF EXISTS `H32QOIM02S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H32QOIM02S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H32QOIM02S`
--

LOCK TABLES `H32QOIM02S` WRITE;
/*!40000 ALTER TABLE `H32QOIM02S` DISABLE KEYS */;
/*!40000 ALTER TABLE `H32QOIM02S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H35K0VQGZQ`
--

DROP TABLE IF EXISTS `H35K0VQGZQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H35K0VQGZQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H35K0VQGZQ`
--

LOCK TABLES `H35K0VQGZQ` WRITE;
/*!40000 ALTER TABLE `H35K0VQGZQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `H35K0VQGZQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H3H9VY9WMI`
--

DROP TABLE IF EXISTS `H3H9VY9WMI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H3H9VY9WMI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H3H9VY9WMI`
--

LOCK TABLES `H3H9VY9WMI` WRITE;
/*!40000 ALTER TABLE `H3H9VY9WMI` DISABLE KEYS */;
/*!40000 ALTER TABLE `H3H9VY9WMI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H3VS83X0U9`
--

DROP TABLE IF EXISTS `H3VS83X0U9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H3VS83X0U9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H3VS83X0U9`
--

LOCK TABLES `H3VS83X0U9` WRITE;
/*!40000 ALTER TABLE `H3VS83X0U9` DISABLE KEYS */;
/*!40000 ALTER TABLE `H3VS83X0U9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H5DIM1DIIJ`
--

DROP TABLE IF EXISTS `H5DIM1DIIJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H5DIM1DIIJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H5DIM1DIIJ`
--

LOCK TABLES `H5DIM1DIIJ` WRITE;
/*!40000 ALTER TABLE `H5DIM1DIIJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `H5DIM1DIIJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H6EJDMTHSW`
--

DROP TABLE IF EXISTS `H6EJDMTHSW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H6EJDMTHSW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H6EJDMTHSW`
--

LOCK TABLES `H6EJDMTHSW` WRITE;
/*!40000 ALTER TABLE `H6EJDMTHSW` DISABLE KEYS */;
/*!40000 ALTER TABLE `H6EJDMTHSW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H6FVDXWIN5`
--

DROP TABLE IF EXISTS `H6FVDXWIN5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H6FVDXWIN5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H6FVDXWIN5`
--

LOCK TABLES `H6FVDXWIN5` WRITE;
/*!40000 ALTER TABLE `H6FVDXWIN5` DISABLE KEYS */;
/*!40000 ALTER TABLE `H6FVDXWIN5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `H78VFGHTZ6`
--

DROP TABLE IF EXISTS `H78VFGHTZ6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `H78VFGHTZ6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `H78VFGHTZ6`
--

LOCK TABLES `H78VFGHTZ6` WRITE;
/*!40000 ALTER TABLE `H78VFGHTZ6` DISABLE KEYS */;
/*!40000 ALTER TABLE `H78VFGHTZ6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HABNC2IMUE`
--

DROP TABLE IF EXISTS `HABNC2IMUE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HABNC2IMUE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HABNC2IMUE`
--

LOCK TABLES `HABNC2IMUE` WRITE;
/*!40000 ALTER TABLE `HABNC2IMUE` DISABLE KEYS */;
/*!40000 ALTER TABLE `HABNC2IMUE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HD2GX3EPYS`
--

DROP TABLE IF EXISTS `HD2GX3EPYS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HD2GX3EPYS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HD2GX3EPYS`
--

LOCK TABLES `HD2GX3EPYS` WRITE;
/*!40000 ALTER TABLE `HD2GX3EPYS` DISABLE KEYS */;
/*!40000 ALTER TABLE `HD2GX3EPYS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HF0SGX7Q27`
--

DROP TABLE IF EXISTS `HF0SGX7Q27`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HF0SGX7Q27` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HF0SGX7Q27`
--

LOCK TABLES `HF0SGX7Q27` WRITE;
/*!40000 ALTER TABLE `HF0SGX7Q27` DISABLE KEYS */;
/*!40000 ALTER TABLE `HF0SGX7Q27` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HIBVH5OP0T`
--

DROP TABLE IF EXISTS `HIBVH5OP0T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HIBVH5OP0T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HIBVH5OP0T`
--

LOCK TABLES `HIBVH5OP0T` WRITE;
/*!40000 ALTER TABLE `HIBVH5OP0T` DISABLE KEYS */;
/*!40000 ALTER TABLE `HIBVH5OP0T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HIW0IO32ON`
--

DROP TABLE IF EXISTS `HIW0IO32ON`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HIW0IO32ON` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HIW0IO32ON`
--

LOCK TABLES `HIW0IO32ON` WRITE;
/*!40000 ALTER TABLE `HIW0IO32ON` DISABLE KEYS */;
/*!40000 ALTER TABLE `HIW0IO32ON` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HMDVDSHFH6`
--

DROP TABLE IF EXISTS `HMDVDSHFH6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HMDVDSHFH6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HMDVDSHFH6`
--

LOCK TABLES `HMDVDSHFH6` WRITE;
/*!40000 ALTER TABLE `HMDVDSHFH6` DISABLE KEYS */;
/*!40000 ALTER TABLE `HMDVDSHFH6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HMW6BNKPPL`
--

DROP TABLE IF EXISTS `HMW6BNKPPL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HMW6BNKPPL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HMW6BNKPPL`
--

LOCK TABLES `HMW6BNKPPL` WRITE;
/*!40000 ALTER TABLE `HMW6BNKPPL` DISABLE KEYS */;
/*!40000 ALTER TABLE `HMW6BNKPPL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HN66XEG2O9`
--

DROP TABLE IF EXISTS `HN66XEG2O9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HN66XEG2O9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HN66XEG2O9`
--

LOCK TABLES `HN66XEG2O9` WRITE;
/*!40000 ALTER TABLE `HN66XEG2O9` DISABLE KEYS */;
/*!40000 ALTER TABLE `HN66XEG2O9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HNGRHI6HAR`
--

DROP TABLE IF EXISTS `HNGRHI6HAR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HNGRHI6HAR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HNGRHI6HAR`
--

LOCK TABLES `HNGRHI6HAR` WRITE;
/*!40000 ALTER TABLE `HNGRHI6HAR` DISABLE KEYS */;
/*!40000 ALTER TABLE `HNGRHI6HAR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HOAAVK1UWY`
--

DROP TABLE IF EXISTS `HOAAVK1UWY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HOAAVK1UWY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HOAAVK1UWY`
--

LOCK TABLES `HOAAVK1UWY` WRITE;
/*!40000 ALTER TABLE `HOAAVK1UWY` DISABLE KEYS */;
/*!40000 ALTER TABLE `HOAAVK1UWY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HOSWG4K5A1`
--

DROP TABLE IF EXISTS `HOSWG4K5A1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HOSWG4K5A1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HOSWG4K5A1`
--

LOCK TABLES `HOSWG4K5A1` WRITE;
/*!40000 ALTER TABLE `HOSWG4K5A1` DISABLE KEYS */;
/*!40000 ALTER TABLE `HOSWG4K5A1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HQYHPI2Y3W`
--

DROP TABLE IF EXISTS `HQYHPI2Y3W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HQYHPI2Y3W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HQYHPI2Y3W`
--

LOCK TABLES `HQYHPI2Y3W` WRITE;
/*!40000 ALTER TABLE `HQYHPI2Y3W` DISABLE KEYS */;
/*!40000 ALTER TABLE `HQYHPI2Y3W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HZW5NAHEEL`
--

DROP TABLE IF EXISTS `HZW5NAHEEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `HZW5NAHEEL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HZW5NAHEEL`
--

LOCK TABLES `HZW5NAHEEL` WRITE;
/*!40000 ALTER TABLE `HZW5NAHEEL` DISABLE KEYS */;
/*!40000 ALTER TABLE `HZW5NAHEEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I0HM338LG4`
--

DROP TABLE IF EXISTS `I0HM338LG4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I0HM338LG4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I0HM338LG4`
--

LOCK TABLES `I0HM338LG4` WRITE;
/*!40000 ALTER TABLE `I0HM338LG4` DISABLE KEYS */;
/*!40000 ALTER TABLE `I0HM338LG4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I0IODGV7RG`
--

DROP TABLE IF EXISTS `I0IODGV7RG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I0IODGV7RG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I0IODGV7RG`
--

LOCK TABLES `I0IODGV7RG` WRITE;
/*!40000 ALTER TABLE `I0IODGV7RG` DISABLE KEYS */;
/*!40000 ALTER TABLE `I0IODGV7RG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I0YDV3I4LD`
--

DROP TABLE IF EXISTS `I0YDV3I4LD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I0YDV3I4LD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I0YDV3I4LD`
--

LOCK TABLES `I0YDV3I4LD` WRITE;
/*!40000 ALTER TABLE `I0YDV3I4LD` DISABLE KEYS */;
/*!40000 ALTER TABLE `I0YDV3I4LD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I176I9A66K`
--

DROP TABLE IF EXISTS `I176I9A66K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I176I9A66K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I176I9A66K`
--

LOCK TABLES `I176I9A66K` WRITE;
/*!40000 ALTER TABLE `I176I9A66K` DISABLE KEYS */;
/*!40000 ALTER TABLE `I176I9A66K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I2D5TRVCY7`
--

DROP TABLE IF EXISTS `I2D5TRVCY7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I2D5TRVCY7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I2D5TRVCY7`
--

LOCK TABLES `I2D5TRVCY7` WRITE;
/*!40000 ALTER TABLE `I2D5TRVCY7` DISABLE KEYS */;
/*!40000 ALTER TABLE `I2D5TRVCY7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I3AGNBYXID`
--

DROP TABLE IF EXISTS `I3AGNBYXID`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I3AGNBYXID` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I3AGNBYXID`
--

LOCK TABLES `I3AGNBYXID` WRITE;
/*!40000 ALTER TABLE `I3AGNBYXID` DISABLE KEYS */;
/*!40000 ALTER TABLE `I3AGNBYXID` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I3YQ2JOPMK`
--

DROP TABLE IF EXISTS `I3YQ2JOPMK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I3YQ2JOPMK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I3YQ2JOPMK`
--

LOCK TABLES `I3YQ2JOPMK` WRITE;
/*!40000 ALTER TABLE `I3YQ2JOPMK` DISABLE KEYS */;
/*!40000 ALTER TABLE `I3YQ2JOPMK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I475TSEQ6X`
--

DROP TABLE IF EXISTS `I475TSEQ6X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I475TSEQ6X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I475TSEQ6X`
--

LOCK TABLES `I475TSEQ6X` WRITE;
/*!40000 ALTER TABLE `I475TSEQ6X` DISABLE KEYS */;
/*!40000 ALTER TABLE `I475TSEQ6X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I62HDW6CAJ`
--

DROP TABLE IF EXISTS `I62HDW6CAJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I62HDW6CAJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I62HDW6CAJ`
--

LOCK TABLES `I62HDW6CAJ` WRITE;
/*!40000 ALTER TABLE `I62HDW6CAJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `I62HDW6CAJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `I7MPESIPEK`
--

DROP TABLE IF EXISTS `I7MPESIPEK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `I7MPESIPEK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `I7MPESIPEK`
--

LOCK TABLES `I7MPESIPEK` WRITE;
/*!40000 ALTER TABLE `I7MPESIPEK` DISABLE KEYS */;
/*!40000 ALTER TABLE `I7MPESIPEK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IAWWV7OCF5`
--

DROP TABLE IF EXISTS `IAWWV7OCF5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IAWWV7OCF5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IAWWV7OCF5`
--

LOCK TABLES `IAWWV7OCF5` WRITE;
/*!40000 ALTER TABLE `IAWWV7OCF5` DISABLE KEYS */;
/*!40000 ALTER TABLE `IAWWV7OCF5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ICRET9CGL7`
--

DROP TABLE IF EXISTS `ICRET9CGL7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ICRET9CGL7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ICRET9CGL7`
--

LOCK TABLES `ICRET9CGL7` WRITE;
/*!40000 ALTER TABLE `ICRET9CGL7` DISABLE KEYS */;
/*!40000 ALTER TABLE `ICRET9CGL7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ID7VVSA3PI`
--

DROP TABLE IF EXISTS `ID7VVSA3PI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ID7VVSA3PI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ID7VVSA3PI`
--

LOCK TABLES `ID7VVSA3PI` WRITE;
/*!40000 ALTER TABLE `ID7VVSA3PI` DISABLE KEYS */;
/*!40000 ALTER TABLE `ID7VVSA3PI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDF6LVHGBH`
--

DROP TABLE IF EXISTS `IDF6LVHGBH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDF6LVHGBH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDF6LVHGBH`
--

LOCK TABLES `IDF6LVHGBH` WRITE;
/*!40000 ALTER TABLE `IDF6LVHGBH` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDF6LVHGBH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IE8NTDCNYB`
--

DROP TABLE IF EXISTS `IE8NTDCNYB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IE8NTDCNYB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IE8NTDCNYB`
--

LOCK TABLES `IE8NTDCNYB` WRITE;
/*!40000 ALTER TABLE `IE8NTDCNYB` DISABLE KEYS */;
/*!40000 ALTER TABLE `IE8NTDCNYB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IEIYMH4GLB`
--

DROP TABLE IF EXISTS `IEIYMH4GLB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IEIYMH4GLB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IEIYMH4GLB`
--

LOCK TABLES `IEIYMH4GLB` WRITE;
/*!40000 ALTER TABLE `IEIYMH4GLB` DISABLE KEYS */;
/*!40000 ALTER TABLE `IEIYMH4GLB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IETU8ZFNXZ`
--

DROP TABLE IF EXISTS `IETU8ZFNXZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IETU8ZFNXZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IETU8ZFNXZ`
--

LOCK TABLES `IETU8ZFNXZ` WRITE;
/*!40000 ALTER TABLE `IETU8ZFNXZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `IETU8ZFNXZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IGQ4G3NZ8B`
--

DROP TABLE IF EXISTS `IGQ4G3NZ8B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IGQ4G3NZ8B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IGQ4G3NZ8B`
--

LOCK TABLES `IGQ4G3NZ8B` WRITE;
/*!40000 ALTER TABLE `IGQ4G3NZ8B` DISABLE KEYS */;
/*!40000 ALTER TABLE `IGQ4G3NZ8B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IIRDNYNAIJ`
--

DROP TABLE IF EXISTS `IIRDNYNAIJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IIRDNYNAIJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IIRDNYNAIJ`
--

LOCK TABLES `IIRDNYNAIJ` WRITE;
/*!40000 ALTER TABLE `IIRDNYNAIJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `IIRDNYNAIJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IJCCJIYS2G`
--

DROP TABLE IF EXISTS `IJCCJIYS2G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IJCCJIYS2G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IJCCJIYS2G`
--

LOCK TABLES `IJCCJIYS2G` WRITE;
/*!40000 ALTER TABLE `IJCCJIYS2G` DISABLE KEYS */;
/*!40000 ALTER TABLE `IJCCJIYS2G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IK3OQNFPJX`
--

DROP TABLE IF EXISTS `IK3OQNFPJX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IK3OQNFPJX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IK3OQNFPJX`
--

LOCK TABLES `IK3OQNFPJX` WRITE;
/*!40000 ALTER TABLE `IK3OQNFPJX` DISABLE KEYS */;
/*!40000 ALTER TABLE `IK3OQNFPJX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IKZ4Q7VXCH`
--

DROP TABLE IF EXISTS `IKZ4Q7VXCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IKZ4Q7VXCH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IKZ4Q7VXCH`
--

LOCK TABLES `IKZ4Q7VXCH` WRITE;
/*!40000 ALTER TABLE `IKZ4Q7VXCH` DISABLE KEYS */;
/*!40000 ALTER TABLE `IKZ4Q7VXCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IL9J9U0REC`
--

DROP TABLE IF EXISTS `IL9J9U0REC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IL9J9U0REC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IL9J9U0REC`
--

LOCK TABLES `IL9J9U0REC` WRITE;
/*!40000 ALTER TABLE `IL9J9U0REC` DISABLE KEYS */;
/*!40000 ALTER TABLE `IL9J9U0REC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ILNH3M04G1`
--

DROP TABLE IF EXISTS `ILNH3M04G1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ILNH3M04G1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ILNH3M04G1`
--

LOCK TABLES `ILNH3M04G1` WRITE;
/*!40000 ALTER TABLE `ILNH3M04G1` DISABLE KEYS */;
/*!40000 ALTER TABLE `ILNH3M04G1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ILV9AXAPTW`
--

DROP TABLE IF EXISTS `ILV9AXAPTW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ILV9AXAPTW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ILV9AXAPTW`
--

LOCK TABLES `ILV9AXAPTW` WRITE;
/*!40000 ALTER TABLE `ILV9AXAPTW` DISABLE KEYS */;
/*!40000 ALTER TABLE `ILV9AXAPTW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INUW3SS85Y`
--

DROP TABLE IF EXISTS `INUW3SS85Y`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INUW3SS85Y` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INUW3SS85Y`
--

LOCK TABLES `INUW3SS85Y` WRITE;
/*!40000 ALTER TABLE `INUW3SS85Y` DISABLE KEYS */;
/*!40000 ALTER TABLE `INUW3SS85Y` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IOUEKODAOU`
--

DROP TABLE IF EXISTS `IOUEKODAOU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IOUEKODAOU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IOUEKODAOU`
--

LOCK TABLES `IOUEKODAOU` WRITE;
/*!40000 ALTER TABLE `IOUEKODAOU` DISABLE KEYS */;
/*!40000 ALTER TABLE `IOUEKODAOU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IQ1OCXDNIF`
--

DROP TABLE IF EXISTS `IQ1OCXDNIF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IQ1OCXDNIF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IQ1OCXDNIF`
--

LOCK TABLES `IQ1OCXDNIF` WRITE;
/*!40000 ALTER TABLE `IQ1OCXDNIF` DISABLE KEYS */;
/*!40000 ALTER TABLE `IQ1OCXDNIF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IQ1OYRDIUY`
--

DROP TABLE IF EXISTS `IQ1OYRDIUY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IQ1OYRDIUY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IQ1OYRDIUY`
--

LOCK TABLES `IQ1OYRDIUY` WRITE;
/*!40000 ALTER TABLE `IQ1OYRDIUY` DISABLE KEYS */;
/*!40000 ALTER TABLE `IQ1OYRDIUY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IQ7HRIYAR4`
--

DROP TABLE IF EXISTS `IQ7HRIYAR4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IQ7HRIYAR4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IQ7HRIYAR4`
--

LOCK TABLES `IQ7HRIYAR4` WRITE;
/*!40000 ALTER TABLE `IQ7HRIYAR4` DISABLE KEYS */;
/*!40000 ALTER TABLE `IQ7HRIYAR4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ISP675TXGX`
--

DROP TABLE IF EXISTS `ISP675TXGX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ISP675TXGX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ISP675TXGX`
--

LOCK TABLES `ISP675TXGX` WRITE;
/*!40000 ALTER TABLE `ISP675TXGX` DISABLE KEYS */;
/*!40000 ALTER TABLE `ISP675TXGX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ISUIOIZVJ0`
--

DROP TABLE IF EXISTS `ISUIOIZVJ0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ISUIOIZVJ0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ISUIOIZVJ0`
--

LOCK TABLES `ISUIOIZVJ0` WRITE;
/*!40000 ALTER TABLE `ISUIOIZVJ0` DISABLE KEYS */;
/*!40000 ALTER TABLE `ISUIOIZVJ0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IUKN67M5PA`
--

DROP TABLE IF EXISTS `IUKN67M5PA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IUKN67M5PA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IUKN67M5PA`
--

LOCK TABLES `IUKN67M5PA` WRITE;
/*!40000 ALTER TABLE `IUKN67M5PA` DISABLE KEYS */;
/*!40000 ALTER TABLE `IUKN67M5PA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IUNWFUT9WK`
--

DROP TABLE IF EXISTS `IUNWFUT9WK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IUNWFUT9WK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IUNWFUT9WK`
--

LOCK TABLES `IUNWFUT9WK` WRITE;
/*!40000 ALTER TABLE `IUNWFUT9WK` DISABLE KEYS */;
/*!40000 ALTER TABLE `IUNWFUT9WK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IW0DO9AUH9`
--

DROP TABLE IF EXISTS `IW0DO9AUH9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IW0DO9AUH9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IW0DO9AUH9`
--

LOCK TABLES `IW0DO9AUH9` WRITE;
/*!40000 ALTER TABLE `IW0DO9AUH9` DISABLE KEYS */;
/*!40000 ALTER TABLE `IW0DO9AUH9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IX8PZWBCZ1`
--

DROP TABLE IF EXISTS `IX8PZWBCZ1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IX8PZWBCZ1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IX8PZWBCZ1`
--

LOCK TABLES `IX8PZWBCZ1` WRITE;
/*!40000 ALTER TABLE `IX8PZWBCZ1` DISABLE KEYS */;
/*!40000 ALTER TABLE `IX8PZWBCZ1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IY2AJT4EJN`
--

DROP TABLE IF EXISTS `IY2AJT4EJN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IY2AJT4EJN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IY2AJT4EJN`
--

LOCK TABLES `IY2AJT4EJN` WRITE;
/*!40000 ALTER TABLE `IY2AJT4EJN` DISABLE KEYS */;
/*!40000 ALTER TABLE `IY2AJT4EJN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IY51PT72M9`
--

DROP TABLE IF EXISTS `IY51PT72M9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IY51PT72M9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IY51PT72M9`
--

LOCK TABLES `IY51PT72M9` WRITE;
/*!40000 ALTER TABLE `IY51PT72M9` DISABLE KEYS */;
/*!40000 ALTER TABLE `IY51PT72M9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IYL5SMRKWS`
--

DROP TABLE IF EXISTS `IYL5SMRKWS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IYL5SMRKWS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IYL5SMRKWS`
--

LOCK TABLES `IYL5SMRKWS` WRITE;
/*!40000 ALTER TABLE `IYL5SMRKWS` DISABLE KEYS */;
/*!40000 ALTER TABLE `IYL5SMRKWS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J0EVJI4B5D`
--

DROP TABLE IF EXISTS `J0EVJI4B5D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J0EVJI4B5D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J0EVJI4B5D`
--

LOCK TABLES `J0EVJI4B5D` WRITE;
/*!40000 ALTER TABLE `J0EVJI4B5D` DISABLE KEYS */;
/*!40000 ALTER TABLE `J0EVJI4B5D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J0YVLHN1W3`
--

DROP TABLE IF EXISTS `J0YVLHN1W3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J0YVLHN1W3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J0YVLHN1W3`
--

LOCK TABLES `J0YVLHN1W3` WRITE;
/*!40000 ALTER TABLE `J0YVLHN1W3` DISABLE KEYS */;
/*!40000 ALTER TABLE `J0YVLHN1W3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J10TPCODOC`
--

DROP TABLE IF EXISTS `J10TPCODOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J10TPCODOC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J10TPCODOC`
--

LOCK TABLES `J10TPCODOC` WRITE;
/*!40000 ALTER TABLE `J10TPCODOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `J10TPCODOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J18ULEWMBF`
--

DROP TABLE IF EXISTS `J18ULEWMBF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J18ULEWMBF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J18ULEWMBF`
--

LOCK TABLES `J18ULEWMBF` WRITE;
/*!40000 ALTER TABLE `J18ULEWMBF` DISABLE KEYS */;
/*!40000 ALTER TABLE `J18ULEWMBF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J24JV21YF9`
--

DROP TABLE IF EXISTS `J24JV21YF9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J24JV21YF9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J24JV21YF9`
--

LOCK TABLES `J24JV21YF9` WRITE;
/*!40000 ALTER TABLE `J24JV21YF9` DISABLE KEYS */;
/*!40000 ALTER TABLE `J24JV21YF9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J3EUXVXY66`
--

DROP TABLE IF EXISTS `J3EUXVXY66`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J3EUXVXY66` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J3EUXVXY66`
--

LOCK TABLES `J3EUXVXY66` WRITE;
/*!40000 ALTER TABLE `J3EUXVXY66` DISABLE KEYS */;
/*!40000 ALTER TABLE `J3EUXVXY66` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J3GA98GXUE`
--

DROP TABLE IF EXISTS `J3GA98GXUE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J3GA98GXUE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J3GA98GXUE`
--

LOCK TABLES `J3GA98GXUE` WRITE;
/*!40000 ALTER TABLE `J3GA98GXUE` DISABLE KEYS */;
/*!40000 ALTER TABLE `J3GA98GXUE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J52PBFRRCU`
--

DROP TABLE IF EXISTS `J52PBFRRCU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J52PBFRRCU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J52PBFRRCU`
--

LOCK TABLES `J52PBFRRCU` WRITE;
/*!40000 ALTER TABLE `J52PBFRRCU` DISABLE KEYS */;
/*!40000 ALTER TABLE `J52PBFRRCU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `J8RJWLW2P3`
--

DROP TABLE IF EXISTS `J8RJWLW2P3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `J8RJWLW2P3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `J8RJWLW2P3`
--

LOCK TABLES `J8RJWLW2P3` WRITE;
/*!40000 ALTER TABLE `J8RJWLW2P3` DISABLE KEYS */;
/*!40000 ALTER TABLE `J8RJWLW2P3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JCDF27Y07P`
--

DROP TABLE IF EXISTS `JCDF27Y07P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JCDF27Y07P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JCDF27Y07P`
--

LOCK TABLES `JCDF27Y07P` WRITE;
/*!40000 ALTER TABLE `JCDF27Y07P` DISABLE KEYS */;
/*!40000 ALTER TABLE `JCDF27Y07P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JD3KGZ5SVX`
--

DROP TABLE IF EXISTS `JD3KGZ5SVX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JD3KGZ5SVX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JD3KGZ5SVX`
--

LOCK TABLES `JD3KGZ5SVX` WRITE;
/*!40000 ALTER TABLE `JD3KGZ5SVX` DISABLE KEYS */;
/*!40000 ALTER TABLE `JD3KGZ5SVX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JD7GL42IR5`
--

DROP TABLE IF EXISTS `JD7GL42IR5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JD7GL42IR5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JD7GL42IR5`
--

LOCK TABLES `JD7GL42IR5` WRITE;
/*!40000 ALTER TABLE `JD7GL42IR5` DISABLE KEYS */;
/*!40000 ALTER TABLE `JD7GL42IR5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JELNZT0LPZ`
--

DROP TABLE IF EXISTS `JELNZT0LPZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JELNZT0LPZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JELNZT0LPZ`
--

LOCK TABLES `JELNZT0LPZ` WRITE;
/*!40000 ALTER TABLE `JELNZT0LPZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `JELNZT0LPZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JHPWG711B4`
--

DROP TABLE IF EXISTS `JHPWG711B4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JHPWG711B4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JHPWG711B4`
--

LOCK TABLES `JHPWG711B4` WRITE;
/*!40000 ALTER TABLE `JHPWG711B4` DISABLE KEYS */;
/*!40000 ALTER TABLE `JHPWG711B4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JI7U7ZTGM9`
--

DROP TABLE IF EXISTS `JI7U7ZTGM9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JI7U7ZTGM9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JI7U7ZTGM9`
--

LOCK TABLES `JI7U7ZTGM9` WRITE;
/*!40000 ALTER TABLE `JI7U7ZTGM9` DISABLE KEYS */;
/*!40000 ALTER TABLE `JI7U7ZTGM9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JIRUZL0TI8`
--

DROP TABLE IF EXISTS `JIRUZL0TI8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JIRUZL0TI8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JIRUZL0TI8`
--

LOCK TABLES `JIRUZL0TI8` WRITE;
/*!40000 ALTER TABLE `JIRUZL0TI8` DISABLE KEYS */;
/*!40000 ALTER TABLE `JIRUZL0TI8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JITOXHV5UX`
--

DROP TABLE IF EXISTS `JITOXHV5UX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JITOXHV5UX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JITOXHV5UX`
--

LOCK TABLES `JITOXHV5UX` WRITE;
/*!40000 ALTER TABLE `JITOXHV5UX` DISABLE KEYS */;
/*!40000 ALTER TABLE `JITOXHV5UX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JLCAWBNU95`
--

DROP TABLE IF EXISTS `JLCAWBNU95`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JLCAWBNU95` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JLCAWBNU95`
--

LOCK TABLES `JLCAWBNU95` WRITE;
/*!40000 ALTER TABLE `JLCAWBNU95` DISABLE KEYS */;
/*!40000 ALTER TABLE `JLCAWBNU95` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JQOTU8XM9L`
--

DROP TABLE IF EXISTS `JQOTU8XM9L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JQOTU8XM9L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JQOTU8XM9L`
--

LOCK TABLES `JQOTU8XM9L` WRITE;
/*!40000 ALTER TABLE `JQOTU8XM9L` DISABLE KEYS */;
/*!40000 ALTER TABLE `JQOTU8XM9L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JSBI0U2CZQ`
--

DROP TABLE IF EXISTS `JSBI0U2CZQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JSBI0U2CZQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JSBI0U2CZQ`
--

LOCK TABLES `JSBI0U2CZQ` WRITE;
/*!40000 ALTER TABLE `JSBI0U2CZQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `JSBI0U2CZQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JT8FA24RA5`
--

DROP TABLE IF EXISTS `JT8FA24RA5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JT8FA24RA5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JT8FA24RA5`
--

LOCK TABLES `JT8FA24RA5` WRITE;
/*!40000 ALTER TABLE `JT8FA24RA5` DISABLE KEYS */;
/*!40000 ALTER TABLE `JT8FA24RA5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JU94RVXYTZ`
--

DROP TABLE IF EXISTS `JU94RVXYTZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JU94RVXYTZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JU94RVXYTZ`
--

LOCK TABLES `JU94RVXYTZ` WRITE;
/*!40000 ALTER TABLE `JU94RVXYTZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `JU94RVXYTZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JVIMKLT7QY`
--

DROP TABLE IF EXISTS `JVIMKLT7QY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JVIMKLT7QY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JVIMKLT7QY`
--

LOCK TABLES `JVIMKLT7QY` WRITE;
/*!40000 ALTER TABLE `JVIMKLT7QY` DISABLE KEYS */;
/*!40000 ALTER TABLE `JVIMKLT7QY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JW5YRZH6JB`
--

DROP TABLE IF EXISTS `JW5YRZH6JB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JW5YRZH6JB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JW5YRZH6JB`
--

LOCK TABLES `JW5YRZH6JB` WRITE;
/*!40000 ALTER TABLE `JW5YRZH6JB` DISABLE KEYS */;
/*!40000 ALTER TABLE `JW5YRZH6JB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JWOCE3RHGO`
--

DROP TABLE IF EXISTS `JWOCE3RHGO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JWOCE3RHGO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JWOCE3RHGO`
--

LOCK TABLES `JWOCE3RHGO` WRITE;
/*!40000 ALTER TABLE `JWOCE3RHGO` DISABLE KEYS */;
/*!40000 ALTER TABLE `JWOCE3RHGO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JXSN5AY68S`
--

DROP TABLE IF EXISTS `JXSN5AY68S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JXSN5AY68S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JXSN5AY68S`
--

LOCK TABLES `JXSN5AY68S` WRITE;
/*!40000 ALTER TABLE `JXSN5AY68S` DISABLE KEYS */;
/*!40000 ALTER TABLE `JXSN5AY68S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JYBRR2ZO14`
--

DROP TABLE IF EXISTS `JYBRR2ZO14`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JYBRR2ZO14` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JYBRR2ZO14`
--

LOCK TABLES `JYBRR2ZO14` WRITE;
/*!40000 ALTER TABLE `JYBRR2ZO14` DISABLE KEYS */;
/*!40000 ALTER TABLE `JYBRR2ZO14` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JZNCUYFNN5`
--

DROP TABLE IF EXISTS `JZNCUYFNN5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `JZNCUYFNN5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JZNCUYFNN5`
--

LOCK TABLES `JZNCUYFNN5` WRITE;
/*!40000 ALTER TABLE `JZNCUYFNN5` DISABLE KEYS */;
/*!40000 ALTER TABLE `JZNCUYFNN5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K1LXSISX1X`
--

DROP TABLE IF EXISTS `K1LXSISX1X`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K1LXSISX1X` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K1LXSISX1X`
--

LOCK TABLES `K1LXSISX1X` WRITE;
/*!40000 ALTER TABLE `K1LXSISX1X` DISABLE KEYS */;
/*!40000 ALTER TABLE `K1LXSISX1X` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K2DRVC3C1C`
--

DROP TABLE IF EXISTS `K2DRVC3C1C`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K2DRVC3C1C` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K2DRVC3C1C`
--

LOCK TABLES `K2DRVC3C1C` WRITE;
/*!40000 ALTER TABLE `K2DRVC3C1C` DISABLE KEYS */;
/*!40000 ALTER TABLE `K2DRVC3C1C` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K664AUHTHN`
--

DROP TABLE IF EXISTS `K664AUHTHN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K664AUHTHN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K664AUHTHN`
--

LOCK TABLES `K664AUHTHN` WRITE;
/*!40000 ALTER TABLE `K664AUHTHN` DISABLE KEYS */;
/*!40000 ALTER TABLE `K664AUHTHN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K86DKSAY27`
--

DROP TABLE IF EXISTS `K86DKSAY27`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K86DKSAY27` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K86DKSAY27`
--

LOCK TABLES `K86DKSAY27` WRITE;
/*!40000 ALTER TABLE `K86DKSAY27` DISABLE KEYS */;
/*!40000 ALTER TABLE `K86DKSAY27` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K8YYJJ1N4F`
--

DROP TABLE IF EXISTS `K8YYJJ1N4F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K8YYJJ1N4F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K8YYJJ1N4F`
--

LOCK TABLES `K8YYJJ1N4F` WRITE;
/*!40000 ALTER TABLE `K8YYJJ1N4F` DISABLE KEYS */;
/*!40000 ALTER TABLE `K8YYJJ1N4F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `K980HBW2O9`
--

DROP TABLE IF EXISTS `K980HBW2O9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K980HBW2O9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `K980HBW2O9`
--

LOCK TABLES `K980HBW2O9` WRITE;
/*!40000 ALTER TABLE `K980HBW2O9` DISABLE KEYS */;
/*!40000 ALTER TABLE `K980HBW2O9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KAHOBNRNI6`
--

DROP TABLE IF EXISTS `KAHOBNRNI6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KAHOBNRNI6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KAHOBNRNI6`
--

LOCK TABLES `KAHOBNRNI6` WRITE;
/*!40000 ALTER TABLE `KAHOBNRNI6` DISABLE KEYS */;
/*!40000 ALTER TABLE `KAHOBNRNI6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KASHFNI57R`
--

DROP TABLE IF EXISTS `KASHFNI57R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KASHFNI57R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KASHFNI57R`
--

LOCK TABLES `KASHFNI57R` WRITE;
/*!40000 ALTER TABLE `KASHFNI57R` DISABLE KEYS */;
/*!40000 ALTER TABLE `KASHFNI57R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEGQ0FPE9O`
--

DROP TABLE IF EXISTS `KEGQ0FPE9O`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KEGQ0FPE9O` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEGQ0FPE9O`
--

LOCK TABLES `KEGQ0FPE9O` WRITE;
/*!40000 ALTER TABLE `KEGQ0FPE9O` DISABLE KEYS */;
/*!40000 ALTER TABLE `KEGQ0FPE9O` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KFBNLJONCZ`
--

DROP TABLE IF EXISTS `KFBNLJONCZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KFBNLJONCZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KFBNLJONCZ`
--

LOCK TABLES `KFBNLJONCZ` WRITE;
/*!40000 ALTER TABLE `KFBNLJONCZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `KFBNLJONCZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KFEK6RS8PG`
--

DROP TABLE IF EXISTS `KFEK6RS8PG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KFEK6RS8PG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KFEK6RS8PG`
--

LOCK TABLES `KFEK6RS8PG` WRITE;
/*!40000 ALTER TABLE `KFEK6RS8PG` DISABLE KEYS */;
/*!40000 ALTER TABLE `KFEK6RS8PG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KG1MAR81HI`
--

DROP TABLE IF EXISTS `KG1MAR81HI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KG1MAR81HI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KG1MAR81HI`
--

LOCK TABLES `KG1MAR81HI` WRITE;
/*!40000 ALTER TABLE `KG1MAR81HI` DISABLE KEYS */;
/*!40000 ALTER TABLE `KG1MAR81HI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KIUB9HEFIY`
--

DROP TABLE IF EXISTS `KIUB9HEFIY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KIUB9HEFIY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KIUB9HEFIY`
--

LOCK TABLES `KIUB9HEFIY` WRITE;
/*!40000 ALTER TABLE `KIUB9HEFIY` DISABLE KEYS */;
/*!40000 ALTER TABLE `KIUB9HEFIY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KLA0RMYK9V`
--

DROP TABLE IF EXISTS `KLA0RMYK9V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KLA0RMYK9V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KLA0RMYK9V`
--

LOCK TABLES `KLA0RMYK9V` WRITE;
/*!40000 ALTER TABLE `KLA0RMYK9V` DISABLE KEYS */;
/*!40000 ALTER TABLE `KLA0RMYK9V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KLWS4ZDNIU`
--

DROP TABLE IF EXISTS `KLWS4ZDNIU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KLWS4ZDNIU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KLWS4ZDNIU`
--

LOCK TABLES `KLWS4ZDNIU` WRITE;
/*!40000 ALTER TABLE `KLWS4ZDNIU` DISABLE KEYS */;
/*!40000 ALTER TABLE `KLWS4ZDNIU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KORQ0Q8QHM`
--

DROP TABLE IF EXISTS `KORQ0Q8QHM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KORQ0Q8QHM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KORQ0Q8QHM`
--

LOCK TABLES `KORQ0Q8QHM` WRITE;
/*!40000 ALTER TABLE `KORQ0Q8QHM` DISABLE KEYS */;
/*!40000 ALTER TABLE `KORQ0Q8QHM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KU5T7PP010`
--

DROP TABLE IF EXISTS `KU5T7PP010`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KU5T7PP010` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KU5T7PP010`
--

LOCK TABLES `KU5T7PP010` WRITE;
/*!40000 ALTER TABLE `KU5T7PP010` DISABLE KEYS */;
/*!40000 ALTER TABLE `KU5T7PP010` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KU6QVFS6RI`
--

DROP TABLE IF EXISTS `KU6QVFS6RI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KU6QVFS6RI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KU6QVFS6RI`
--

LOCK TABLES `KU6QVFS6RI` WRITE;
/*!40000 ALTER TABLE `KU6QVFS6RI` DISABLE KEYS */;
/*!40000 ALTER TABLE `KU6QVFS6RI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KULZOJFUQH`
--

DROP TABLE IF EXISTS `KULZOJFUQH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KULZOJFUQH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KULZOJFUQH`
--

LOCK TABLES `KULZOJFUQH` WRITE;
/*!40000 ALTER TABLE `KULZOJFUQH` DISABLE KEYS */;
/*!40000 ALTER TABLE `KULZOJFUQH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KVGYUCY6E9`
--

DROP TABLE IF EXISTS `KVGYUCY6E9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KVGYUCY6E9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KVGYUCY6E9`
--

LOCK TABLES `KVGYUCY6E9` WRITE;
/*!40000 ALTER TABLE `KVGYUCY6E9` DISABLE KEYS */;
/*!40000 ALTER TABLE `KVGYUCY6E9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L0IXVLUVJ0`
--

DROP TABLE IF EXISTS `L0IXVLUVJ0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L0IXVLUVJ0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L0IXVLUVJ0`
--

LOCK TABLES `L0IXVLUVJ0` WRITE;
/*!40000 ALTER TABLE `L0IXVLUVJ0` DISABLE KEYS */;
/*!40000 ALTER TABLE `L0IXVLUVJ0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L27IIGN01O`
--

DROP TABLE IF EXISTS `L27IIGN01O`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L27IIGN01O` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L27IIGN01O`
--

LOCK TABLES `L27IIGN01O` WRITE;
/*!40000 ALTER TABLE `L27IIGN01O` DISABLE KEYS */;
/*!40000 ALTER TABLE `L27IIGN01O` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L2LO6TSFBL`
--

DROP TABLE IF EXISTS `L2LO6TSFBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L2LO6TSFBL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L2LO6TSFBL`
--

LOCK TABLES `L2LO6TSFBL` WRITE;
/*!40000 ALTER TABLE `L2LO6TSFBL` DISABLE KEYS */;
/*!40000 ALTER TABLE `L2LO6TSFBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L3O83F2W4P`
--

DROP TABLE IF EXISTS `L3O83F2W4P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L3O83F2W4P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L3O83F2W4P`
--

LOCK TABLES `L3O83F2W4P` WRITE;
/*!40000 ALTER TABLE `L3O83F2W4P` DISABLE KEYS */;
/*!40000 ALTER TABLE `L3O83F2W4P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L7526YPMXT`
--

DROP TABLE IF EXISTS `L7526YPMXT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L7526YPMXT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L7526YPMXT`
--

LOCK TABLES `L7526YPMXT` WRITE;
/*!40000 ALTER TABLE `L7526YPMXT` DISABLE KEYS */;
/*!40000 ALTER TABLE `L7526YPMXT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L7DU76LRCG`
--

DROP TABLE IF EXISTS `L7DU76LRCG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L7DU76LRCG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L7DU76LRCG`
--

LOCK TABLES `L7DU76LRCG` WRITE;
/*!40000 ALTER TABLE `L7DU76LRCG` DISABLE KEYS */;
/*!40000 ALTER TABLE `L7DU76LRCG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L8WT9GONZ6`
--

DROP TABLE IF EXISTS `L8WT9GONZ6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L8WT9GONZ6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L8WT9GONZ6`
--

LOCK TABLES `L8WT9GONZ6` WRITE;
/*!40000 ALTER TABLE `L8WT9GONZ6` DISABLE KEYS */;
/*!40000 ALTER TABLE `L8WT9GONZ6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L92QJ5IY7N`
--

DROP TABLE IF EXISTS `L92QJ5IY7N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L92QJ5IY7N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L92QJ5IY7N`
--

LOCK TABLES `L92QJ5IY7N` WRITE;
/*!40000 ALTER TABLE `L92QJ5IY7N` DISABLE KEYS */;
/*!40000 ALTER TABLE `L92QJ5IY7N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `L9WRY8FY73`
--

DROP TABLE IF EXISTS `L9WRY8FY73`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `L9WRY8FY73` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `L9WRY8FY73`
--

LOCK TABLES `L9WRY8FY73` WRITE;
/*!40000 ALTER TABLE `L9WRY8FY73` DISABLE KEYS */;
/*!40000 ALTER TABLE `L9WRY8FY73` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDJH5FRU3`
--

DROP TABLE IF EXISTS `LEDJH5FRU3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDJH5FRU3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDJH5FRU3`
--

LOCK TABLES `LEDJH5FRU3` WRITE;
/*!40000 ALTER TABLE `LEDJH5FRU3` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDJH5FRU3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEF9NK3DM5`
--

DROP TABLE IF EXISTS `LEF9NK3DM5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEF9NK3DM5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEF9NK3DM5`
--

LOCK TABLES `LEF9NK3DM5` WRITE;
/*!40000 ALTER TABLE `LEF9NK3DM5` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEF9NK3DM5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LFETBPV0P8`
--

DROP TABLE IF EXISTS `LFETBPV0P8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LFETBPV0P8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LFETBPV0P8`
--

LOCK TABLES `LFETBPV0P8` WRITE;
/*!40000 ALTER TABLE `LFETBPV0P8` DISABLE KEYS */;
/*!40000 ALTER TABLE `LFETBPV0P8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LGL8AWOIRV`
--

DROP TABLE IF EXISTS `LGL8AWOIRV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LGL8AWOIRV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LGL8AWOIRV`
--

LOCK TABLES `LGL8AWOIRV` WRITE;
/*!40000 ALTER TABLE `LGL8AWOIRV` DISABLE KEYS */;
/*!40000 ALTER TABLE `LGL8AWOIRV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LNKVIK6SQ5`
--

DROP TABLE IF EXISTS `LNKVIK6SQ5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LNKVIK6SQ5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LNKVIK6SQ5`
--

LOCK TABLES `LNKVIK6SQ5` WRITE;
/*!40000 ALTER TABLE `LNKVIK6SQ5` DISABLE KEYS */;
/*!40000 ALTER TABLE `LNKVIK6SQ5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LO8Q0AL33W`
--

DROP TABLE IF EXISTS `LO8Q0AL33W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LO8Q0AL33W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LO8Q0AL33W`
--

LOCK TABLES `LO8Q0AL33W` WRITE;
/*!40000 ALTER TABLE `LO8Q0AL33W` DISABLE KEYS */;
/*!40000 ALTER TABLE `LO8Q0AL33W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LRKSMBDZGZ`
--

DROP TABLE IF EXISTS `LRKSMBDZGZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LRKSMBDZGZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LRKSMBDZGZ`
--

LOCK TABLES `LRKSMBDZGZ` WRITE;
/*!40000 ALTER TABLE `LRKSMBDZGZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `LRKSMBDZGZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LUUMTTMKOP`
--

DROP TABLE IF EXISTS `LUUMTTMKOP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LUUMTTMKOP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LUUMTTMKOP`
--

LOCK TABLES `LUUMTTMKOP` WRITE;
/*!40000 ALTER TABLE `LUUMTTMKOP` DISABLE KEYS */;
/*!40000 ALTER TABLE `LUUMTTMKOP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LY4HD9UMMD`
--

DROP TABLE IF EXISTS `LY4HD9UMMD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LY4HD9UMMD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LY4HD9UMMD`
--

LOCK TABLES `LY4HD9UMMD` WRITE;
/*!40000 ALTER TABLE `LY4HD9UMMD` DISABLE KEYS */;
/*!40000 ALTER TABLE `LY4HD9UMMD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LY8CW9JLGD`
--

DROP TABLE IF EXISTS `LY8CW9JLGD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LY8CW9JLGD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LY8CW9JLGD`
--

LOCK TABLES `LY8CW9JLGD` WRITE;
/*!40000 ALTER TABLE `LY8CW9JLGD` DISABLE KEYS */;
/*!40000 ALTER TABLE `LY8CW9JLGD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LYMNSVAB4N`
--

DROP TABLE IF EXISTS `LYMNSVAB4N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LYMNSVAB4N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LYMNSVAB4N`
--

LOCK TABLES `LYMNSVAB4N` WRITE;
/*!40000 ALTER TABLE `LYMNSVAB4N` DISABLE KEYS */;
/*!40000 ALTER TABLE `LYMNSVAB4N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M00JBB4B1V`
--

DROP TABLE IF EXISTS `M00JBB4B1V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M00JBB4B1V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M00JBB4B1V`
--

LOCK TABLES `M00JBB4B1V` WRITE;
/*!40000 ALTER TABLE `M00JBB4B1V` DISABLE KEYS */;
/*!40000 ALTER TABLE `M00JBB4B1V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M2SPV5JB6M`
--

DROP TABLE IF EXISTS `M2SPV5JB6M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M2SPV5JB6M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M2SPV5JB6M`
--

LOCK TABLES `M2SPV5JB6M` WRITE;
/*!40000 ALTER TABLE `M2SPV5JB6M` DISABLE KEYS */;
/*!40000 ALTER TABLE `M2SPV5JB6M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M35S0RE8XH`
--

DROP TABLE IF EXISTS `M35S0RE8XH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M35S0RE8XH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M35S0RE8XH`
--

LOCK TABLES `M35S0RE8XH` WRITE;
/*!40000 ALTER TABLE `M35S0RE8XH` DISABLE KEYS */;
/*!40000 ALTER TABLE `M35S0RE8XH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M39AQPK1K2`
--

DROP TABLE IF EXISTS `M39AQPK1K2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M39AQPK1K2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M39AQPK1K2`
--

LOCK TABLES `M39AQPK1K2` WRITE;
/*!40000 ALTER TABLE `M39AQPK1K2` DISABLE KEYS */;
/*!40000 ALTER TABLE `M39AQPK1K2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M4Y967S5OO`
--

DROP TABLE IF EXISTS `M4Y967S5OO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M4Y967S5OO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M4Y967S5OO`
--

LOCK TABLES `M4Y967S5OO` WRITE;
/*!40000 ALTER TABLE `M4Y967S5OO` DISABLE KEYS */;
/*!40000 ALTER TABLE `M4Y967S5OO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M5E3V7Z7OE`
--

DROP TABLE IF EXISTS `M5E3V7Z7OE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M5E3V7Z7OE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M5E3V7Z7OE`
--

LOCK TABLES `M5E3V7Z7OE` WRITE;
/*!40000 ALTER TABLE `M5E3V7Z7OE` DISABLE KEYS */;
/*!40000 ALTER TABLE `M5E3V7Z7OE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M5G2BTVLUJ`
--

DROP TABLE IF EXISTS `M5G2BTVLUJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M5G2BTVLUJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M5G2BTVLUJ`
--

LOCK TABLES `M5G2BTVLUJ` WRITE;
/*!40000 ALTER TABLE `M5G2BTVLUJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `M5G2BTVLUJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M8V5KXENOV`
--

DROP TABLE IF EXISTS `M8V5KXENOV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M8V5KXENOV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M8V5KXENOV`
--

LOCK TABLES `M8V5KXENOV` WRITE;
/*!40000 ALTER TABLE `M8V5KXENOV` DISABLE KEYS */;
/*!40000 ALTER TABLE `M8V5KXENOV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `M9NLN82PRX`
--

DROP TABLE IF EXISTS `M9NLN82PRX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `M9NLN82PRX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `M9NLN82PRX`
--

LOCK TABLES `M9NLN82PRX` WRITE;
/*!40000 ALTER TABLE `M9NLN82PRX` DISABLE KEYS */;
/*!40000 ALTER TABLE `M9NLN82PRX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MARV2GFBSA`
--

DROP TABLE IF EXISTS `MARV2GFBSA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MARV2GFBSA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MARV2GFBSA`
--

LOCK TABLES `MARV2GFBSA` WRITE;
/*!40000 ALTER TABLE `MARV2GFBSA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MARV2GFBSA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MBICFPZ6WV`
--

DROP TABLE IF EXISTS `MBICFPZ6WV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MBICFPZ6WV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MBICFPZ6WV`
--

LOCK TABLES `MBICFPZ6WV` WRITE;
/*!40000 ALTER TABLE `MBICFPZ6WV` DISABLE KEYS */;
/*!40000 ALTER TABLE `MBICFPZ6WV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MC9D9LAJH3`
--

DROP TABLE IF EXISTS `MC9D9LAJH3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MC9D9LAJH3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MC9D9LAJH3`
--

LOCK TABLES `MC9D9LAJH3` WRITE;
/*!40000 ALTER TABLE `MC9D9LAJH3` DISABLE KEYS */;
/*!40000 ALTER TABLE `MC9D9LAJH3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MCXH5HK9PF`
--

DROP TABLE IF EXISTS `MCXH5HK9PF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MCXH5HK9PF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MCXH5HK9PF`
--

LOCK TABLES `MCXH5HK9PF` WRITE;
/*!40000 ALTER TABLE `MCXH5HK9PF` DISABLE KEYS */;
/*!40000 ALTER TABLE `MCXH5HK9PF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDD0ML76KE`
--

DROP TABLE IF EXISTS `MDD0ML76KE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDD0ML76KE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDD0ML76KE`
--

LOCK TABLES `MDD0ML76KE` WRITE;
/*!40000 ALTER TABLE `MDD0ML76KE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MDD0ML76KE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDZ3RS6JG6`
--

DROP TABLE IF EXISTS `MDZ3RS6JG6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDZ3RS6JG6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDZ3RS6JG6`
--

LOCK TABLES `MDZ3RS6JG6` WRITE;
/*!40000 ALTER TABLE `MDZ3RS6JG6` DISABLE KEYS */;
/*!40000 ALTER TABLE `MDZ3RS6JG6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ME2JLFDK34`
--

DROP TABLE IF EXISTS `ME2JLFDK34`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ME2JLFDK34` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ME2JLFDK34`
--

LOCK TABLES `ME2JLFDK34` WRITE;
/*!40000 ALTER TABLE `ME2JLFDK34` DISABLE KEYS */;
/*!40000 ALTER TABLE `ME2JLFDK34` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MG9J4XVDP4`
--

DROP TABLE IF EXISTS `MG9J4XVDP4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MG9J4XVDP4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MG9J4XVDP4`
--

LOCK TABLES `MG9J4XVDP4` WRITE;
/*!40000 ALTER TABLE `MG9J4XVDP4` DISABLE KEYS */;
/*!40000 ALTER TABLE `MG9J4XVDP4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MGTGURUJHX`
--

DROP TABLE IF EXISTS `MGTGURUJHX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MGTGURUJHX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MGTGURUJHX`
--

LOCK TABLES `MGTGURUJHX` WRITE;
/*!40000 ALTER TABLE `MGTGURUJHX` DISABLE KEYS */;
/*!40000 ALTER TABLE `MGTGURUJHX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MI1VVXY39W`
--

DROP TABLE IF EXISTS `MI1VVXY39W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MI1VVXY39W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MI1VVXY39W`
--

LOCK TABLES `MI1VVXY39W` WRITE;
/*!40000 ALTER TABLE `MI1VVXY39W` DISABLE KEYS */;
/*!40000 ALTER TABLE `MI1VVXY39W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MJNDURKS4E`
--

DROP TABLE IF EXISTS `MJNDURKS4E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MJNDURKS4E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MJNDURKS4E`
--

LOCK TABLES `MJNDURKS4E` WRITE;
/*!40000 ALTER TABLE `MJNDURKS4E` DISABLE KEYS */;
/*!40000 ALTER TABLE `MJNDURKS4E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MKDFY43OCJ`
--

DROP TABLE IF EXISTS `MKDFY43OCJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MKDFY43OCJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MKDFY43OCJ`
--

LOCK TABLES `MKDFY43OCJ` WRITE;
/*!40000 ALTER TABLE `MKDFY43OCJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `MKDFY43OCJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MMH2WGOWM1`
--

DROP TABLE IF EXISTS `MMH2WGOWM1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MMH2WGOWM1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MMH2WGOWM1`
--

LOCK TABLES `MMH2WGOWM1` WRITE;
/*!40000 ALTER TABLE `MMH2WGOWM1` DISABLE KEYS */;
/*!40000 ALTER TABLE `MMH2WGOWM1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MNS4ST9S13`
--

DROP TABLE IF EXISTS `MNS4ST9S13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MNS4ST9S13` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MNS4ST9S13`
--

LOCK TABLES `MNS4ST9S13` WRITE;
/*!40000 ALTER TABLE `MNS4ST9S13` DISABLE KEYS */;
/*!40000 ALTER TABLE `MNS4ST9S13` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MO89P1U765`
--

DROP TABLE IF EXISTS `MO89P1U765`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MO89P1U765` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MO89P1U765`
--

LOCK TABLES `MO89P1U765` WRITE;
/*!40000 ALTER TABLE `MO89P1U765` DISABLE KEYS */;
/*!40000 ALTER TABLE `MO89P1U765` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MQT3FEU93P`
--

DROP TABLE IF EXISTS `MQT3FEU93P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MQT3FEU93P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MQT3FEU93P`
--

LOCK TABLES `MQT3FEU93P` WRITE;
/*!40000 ALTER TABLE `MQT3FEU93P` DISABLE KEYS */;
/*!40000 ALTER TABLE `MQT3FEU93P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MRUPR27NVM`
--

DROP TABLE IF EXISTS `MRUPR27NVM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MRUPR27NVM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MRUPR27NVM`
--

LOCK TABLES `MRUPR27NVM` WRITE;
/*!40000 ALTER TABLE `MRUPR27NVM` DISABLE KEYS */;
/*!40000 ALTER TABLE `MRUPR27NVM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MSF7W78GKU`
--

DROP TABLE IF EXISTS `MSF7W78GKU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MSF7W78GKU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MSF7W78GKU`
--

LOCK TABLES `MSF7W78GKU` WRITE;
/*!40000 ALTER TABLE `MSF7W78GKU` DISABLE KEYS */;
/*!40000 ALTER TABLE `MSF7W78GKU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MT2LS74QX4`
--

DROP TABLE IF EXISTS `MT2LS74QX4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MT2LS74QX4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MT2LS74QX4`
--

LOCK TABLES `MT2LS74QX4` WRITE;
/*!40000 ALTER TABLE `MT2LS74QX4` DISABLE KEYS */;
/*!40000 ALTER TABLE `MT2LS74QX4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MT3VN7KKDV`
--

DROP TABLE IF EXISTS `MT3VN7KKDV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MT3VN7KKDV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MT3VN7KKDV`
--

LOCK TABLES `MT3VN7KKDV` WRITE;
/*!40000 ALTER TABLE `MT3VN7KKDV` DISABLE KEYS */;
/*!40000 ALTER TABLE `MT3VN7KKDV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MTSBYRPU8S`
--

DROP TABLE IF EXISTS `MTSBYRPU8S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MTSBYRPU8S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MTSBYRPU8S`
--

LOCK TABLES `MTSBYRPU8S` WRITE;
/*!40000 ALTER TABLE `MTSBYRPU8S` DISABLE KEYS */;
/*!40000 ALTER TABLE `MTSBYRPU8S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWYGYN2GP4`
--

DROP TABLE IF EXISTS `MWYGYN2GP4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MWYGYN2GP4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWYGYN2GP4`
--

LOCK TABLES `MWYGYN2GP4` WRITE;
/*!40000 ALTER TABLE `MWYGYN2GP4` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWYGYN2GP4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MXKLNES9DA`
--

DROP TABLE IF EXISTS `MXKLNES9DA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MXKLNES9DA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MXKLNES9DA`
--

LOCK TABLES `MXKLNES9DA` WRITE;
/*!40000 ALTER TABLE `MXKLNES9DA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MXKLNES9DA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MXLCCUPT2Y`
--

DROP TABLE IF EXISTS `MXLCCUPT2Y`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MXLCCUPT2Y` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MXLCCUPT2Y`
--

LOCK TABLES `MXLCCUPT2Y` WRITE;
/*!40000 ALTER TABLE `MXLCCUPT2Y` DISABLE KEYS */;
/*!40000 ALTER TABLE `MXLCCUPT2Y` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MYK75Y8UO1`
--

DROP TABLE IF EXISTS `MYK75Y8UO1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MYK75Y8UO1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MYK75Y8UO1`
--

LOCK TABLES `MYK75Y8UO1` WRITE;
/*!40000 ALTER TABLE `MYK75Y8UO1` DISABLE KEYS */;
/*!40000 ALTER TABLE `MYK75Y8UO1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MYQA4XRB0T`
--

DROP TABLE IF EXISTS `MYQA4XRB0T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MYQA4XRB0T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MYQA4XRB0T`
--

LOCK TABLES `MYQA4XRB0T` WRITE;
/*!40000 ALTER TABLE `MYQA4XRB0T` DISABLE KEYS */;
/*!40000 ALTER TABLE `MYQA4XRB0T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MYWEUZ27KL`
--

DROP TABLE IF EXISTS `MYWEUZ27KL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MYWEUZ27KL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MYWEUZ27KL`
--

LOCK TABLES `MYWEUZ27KL` WRITE;
/*!40000 ALTER TABLE `MYWEUZ27KL` DISABLE KEYS */;
/*!40000 ALTER TABLE `MYWEUZ27KL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MYZD269MHR`
--

DROP TABLE IF EXISTS `MYZD269MHR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MYZD269MHR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MYZD269MHR`
--

LOCK TABLES `MYZD269MHR` WRITE;
/*!40000 ALTER TABLE `MYZD269MHR` DISABLE KEYS */;
/*!40000 ALTER TABLE `MYZD269MHR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N0Z7OBFSH7`
--

DROP TABLE IF EXISTS `N0Z7OBFSH7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N0Z7OBFSH7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N0Z7OBFSH7`
--

LOCK TABLES `N0Z7OBFSH7` WRITE;
/*!40000 ALTER TABLE `N0Z7OBFSH7` DISABLE KEYS */;
/*!40000 ALTER TABLE `N0Z7OBFSH7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N1F6056HT5`
--

DROP TABLE IF EXISTS `N1F6056HT5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N1F6056HT5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N1F6056HT5`
--

LOCK TABLES `N1F6056HT5` WRITE;
/*!40000 ALTER TABLE `N1F6056HT5` DISABLE KEYS */;
/*!40000 ALTER TABLE `N1F6056HT5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N1MFHA3PX4`
--

DROP TABLE IF EXISTS `N1MFHA3PX4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N1MFHA3PX4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N1MFHA3PX4`
--

LOCK TABLES `N1MFHA3PX4` WRITE;
/*!40000 ALTER TABLE `N1MFHA3PX4` DISABLE KEYS */;
/*!40000 ALTER TABLE `N1MFHA3PX4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N2D43VFG8E`
--

DROP TABLE IF EXISTS `N2D43VFG8E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N2D43VFG8E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N2D43VFG8E`
--

LOCK TABLES `N2D43VFG8E` WRITE;
/*!40000 ALTER TABLE `N2D43VFG8E` DISABLE KEYS */;
/*!40000 ALTER TABLE `N2D43VFG8E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N3YGDQUP4G`
--

DROP TABLE IF EXISTS `N3YGDQUP4G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N3YGDQUP4G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N3YGDQUP4G`
--

LOCK TABLES `N3YGDQUP4G` WRITE;
/*!40000 ALTER TABLE `N3YGDQUP4G` DISABLE KEYS */;
/*!40000 ALTER TABLE `N3YGDQUP4G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N4AMN7QAT5`
--

DROP TABLE IF EXISTS `N4AMN7QAT5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N4AMN7QAT5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N4AMN7QAT5`
--

LOCK TABLES `N4AMN7QAT5` WRITE;
/*!40000 ALTER TABLE `N4AMN7QAT5` DISABLE KEYS */;
/*!40000 ALTER TABLE `N4AMN7QAT5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N4K457MR4P`
--

DROP TABLE IF EXISTS `N4K457MR4P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N4K457MR4P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N4K457MR4P`
--

LOCK TABLES `N4K457MR4P` WRITE;
/*!40000 ALTER TABLE `N4K457MR4P` DISABLE KEYS */;
/*!40000 ALTER TABLE `N4K457MR4P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N4Y9YA0IRN`
--

DROP TABLE IF EXISTS `N4Y9YA0IRN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N4Y9YA0IRN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N4Y9YA0IRN`
--

LOCK TABLES `N4Y9YA0IRN` WRITE;
/*!40000 ALTER TABLE `N4Y9YA0IRN` DISABLE KEYS */;
/*!40000 ALTER TABLE `N4Y9YA0IRN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N5SKPEFR7B`
--

DROP TABLE IF EXISTS `N5SKPEFR7B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N5SKPEFR7B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N5SKPEFR7B`
--

LOCK TABLES `N5SKPEFR7B` WRITE;
/*!40000 ALTER TABLE `N5SKPEFR7B` DISABLE KEYS */;
/*!40000 ALTER TABLE `N5SKPEFR7B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N807U9XXH1`
--

DROP TABLE IF EXISTS `N807U9XXH1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N807U9XXH1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N807U9XXH1`
--

LOCK TABLES `N807U9XXH1` WRITE;
/*!40000 ALTER TABLE `N807U9XXH1` DISABLE KEYS */;
/*!40000 ALTER TABLE `N807U9XXH1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `N9L4PUA9MY`
--

DROP TABLE IF EXISTS `N9L4PUA9MY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `N9L4PUA9MY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `N9L4PUA9MY`
--

LOCK TABLES `N9L4PUA9MY` WRITE;
/*!40000 ALTER TABLE `N9L4PUA9MY` DISABLE KEYS */;
/*!40000 ALTER TABLE `N9L4PUA9MY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NBSBV197YJ`
--

DROP TABLE IF EXISTS `NBSBV197YJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NBSBV197YJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NBSBV197YJ`
--

LOCK TABLES `NBSBV197YJ` WRITE;
/*!40000 ALTER TABLE `NBSBV197YJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `NBSBV197YJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NCO4YJGC74`
--

DROP TABLE IF EXISTS `NCO4YJGC74`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NCO4YJGC74` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NCO4YJGC74`
--

LOCK TABLES `NCO4YJGC74` WRITE;
/*!40000 ALTER TABLE `NCO4YJGC74` DISABLE KEYS */;
/*!40000 ALTER TABLE `NCO4YJGC74` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NDNTIW4WIU`
--

DROP TABLE IF EXISTS `NDNTIW4WIU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NDNTIW4WIU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NDNTIW4WIU`
--

LOCK TABLES `NDNTIW4WIU` WRITE;
/*!40000 ALTER TABLE `NDNTIW4WIU` DISABLE KEYS */;
/*!40000 ALTER TABLE `NDNTIW4WIU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NDXAEN2476`
--

DROP TABLE IF EXISTS `NDXAEN2476`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NDXAEN2476` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NDXAEN2476`
--

LOCK TABLES `NDXAEN2476` WRITE;
/*!40000 ALTER TABLE `NDXAEN2476` DISABLE KEYS */;
/*!40000 ALTER TABLE `NDXAEN2476` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NECUED74BX`
--

DROP TABLE IF EXISTS `NECUED74BX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NECUED74BX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NECUED74BX`
--

LOCK TABLES `NECUED74BX` WRITE;
/*!40000 ALTER TABLE `NECUED74BX` DISABLE KEYS */;
/*!40000 ALTER TABLE `NECUED74BX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NGD8AKFKZG`
--

DROP TABLE IF EXISTS `NGD8AKFKZG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NGD8AKFKZG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NGD8AKFKZG`
--

LOCK TABLES `NGD8AKFKZG` WRITE;
/*!40000 ALTER TABLE `NGD8AKFKZG` DISABLE KEYS */;
/*!40000 ALTER TABLE `NGD8AKFKZG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NJ7OZ1K7H7`
--

DROP TABLE IF EXISTS `NJ7OZ1K7H7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NJ7OZ1K7H7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NJ7OZ1K7H7`
--

LOCK TABLES `NJ7OZ1K7H7` WRITE;
/*!40000 ALTER TABLE `NJ7OZ1K7H7` DISABLE KEYS */;
/*!40000 ALTER TABLE `NJ7OZ1K7H7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NJRUQAF81P`
--

DROP TABLE IF EXISTS `NJRUQAF81P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NJRUQAF81P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NJRUQAF81P`
--

LOCK TABLES `NJRUQAF81P` WRITE;
/*!40000 ALTER TABLE `NJRUQAF81P` DISABLE KEYS */;
/*!40000 ALTER TABLE `NJRUQAF81P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NM2KBP3W0L`
--

DROP TABLE IF EXISTS `NM2KBP3W0L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NM2KBP3W0L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NM2KBP3W0L`
--

LOCK TABLES `NM2KBP3W0L` WRITE;
/*!40000 ALTER TABLE `NM2KBP3W0L` DISABLE KEYS */;
/*!40000 ALTER TABLE `NM2KBP3W0L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NNAHM1WOKA`
--

DROP TABLE IF EXISTS `NNAHM1WOKA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NNAHM1WOKA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NNAHM1WOKA`
--

LOCK TABLES `NNAHM1WOKA` WRITE;
/*!40000 ALTER TABLE `NNAHM1WOKA` DISABLE KEYS */;
/*!40000 ALTER TABLE `NNAHM1WOKA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NNIPKWHO1H`
--

DROP TABLE IF EXISTS `NNIPKWHO1H`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NNIPKWHO1H` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NNIPKWHO1H`
--

LOCK TABLES `NNIPKWHO1H` WRITE;
/*!40000 ALTER TABLE `NNIPKWHO1H` DISABLE KEYS */;
/*!40000 ALTER TABLE `NNIPKWHO1H` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NQ0G3T5MO8`
--

DROP TABLE IF EXISTS `NQ0G3T5MO8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NQ0G3T5MO8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NQ0G3T5MO8`
--

LOCK TABLES `NQ0G3T5MO8` WRITE;
/*!40000 ALTER TABLE `NQ0G3T5MO8` DISABLE KEYS */;
/*!40000 ALTER TABLE `NQ0G3T5MO8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NQWO5R48WU`
--

DROP TABLE IF EXISTS `NQWO5R48WU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NQWO5R48WU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NQWO5R48WU`
--

LOCK TABLES `NQWO5R48WU` WRITE;
/*!40000 ALTER TABLE `NQWO5R48WU` DISABLE KEYS */;
/*!40000 ALTER TABLE `NQWO5R48WU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NSPT9VL2JA`
--

DROP TABLE IF EXISTS `NSPT9VL2JA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NSPT9VL2JA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NSPT9VL2JA`
--

LOCK TABLES `NSPT9VL2JA` WRITE;
/*!40000 ALTER TABLE `NSPT9VL2JA` DISABLE KEYS */;
/*!40000 ALTER TABLE `NSPT9VL2JA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NVF71PUWBO`
--

DROP TABLE IF EXISTS `NVF71PUWBO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NVF71PUWBO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NVF71PUWBO`
--

LOCK TABLES `NVF71PUWBO` WRITE;
/*!40000 ALTER TABLE `NVF71PUWBO` DISABLE KEYS */;
/*!40000 ALTER TABLE `NVF71PUWBO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NW982M5CV2`
--

DROP TABLE IF EXISTS `NW982M5CV2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NW982M5CV2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NW982M5CV2`
--

LOCK TABLES `NW982M5CV2` WRITE;
/*!40000 ALTER TABLE `NW982M5CV2` DISABLE KEYS */;
/*!40000 ALTER TABLE `NW982M5CV2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NWT7QTHMBT`
--

DROP TABLE IF EXISTS `NWT7QTHMBT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NWT7QTHMBT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NWT7QTHMBT`
--

LOCK TABLES `NWT7QTHMBT` WRITE;
/*!40000 ALTER TABLE `NWT7QTHMBT` DISABLE KEYS */;
/*!40000 ALTER TABLE `NWT7QTHMBT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NXB3J83Z4L`
--

DROP TABLE IF EXISTS `NXB3J83Z4L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NXB3J83Z4L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NXB3J83Z4L`
--

LOCK TABLES `NXB3J83Z4L` WRITE;
/*!40000 ALTER TABLE `NXB3J83Z4L` DISABLE KEYS */;
/*!40000 ALTER TABLE `NXB3J83Z4L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O04VCQI9SM`
--

DROP TABLE IF EXISTS `O04VCQI9SM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O04VCQI9SM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O04VCQI9SM`
--

LOCK TABLES `O04VCQI9SM` WRITE;
/*!40000 ALTER TABLE `O04VCQI9SM` DISABLE KEYS */;
/*!40000 ALTER TABLE `O04VCQI9SM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O24H92KUCF`
--

DROP TABLE IF EXISTS `O24H92KUCF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O24H92KUCF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O24H92KUCF`
--

LOCK TABLES `O24H92KUCF` WRITE;
/*!40000 ALTER TABLE `O24H92KUCF` DISABLE KEYS */;
/*!40000 ALTER TABLE `O24H92KUCF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O4RJGFU5L4`
--

DROP TABLE IF EXISTS `O4RJGFU5L4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O4RJGFU5L4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O4RJGFU5L4`
--

LOCK TABLES `O4RJGFU5L4` WRITE;
/*!40000 ALTER TABLE `O4RJGFU5L4` DISABLE KEYS */;
/*!40000 ALTER TABLE `O4RJGFU5L4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O6V645X026`
--

DROP TABLE IF EXISTS `O6V645X026`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O6V645X026` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O6V645X026`
--

LOCK TABLES `O6V645X026` WRITE;
/*!40000 ALTER TABLE `O6V645X026` DISABLE KEYS */;
/*!40000 ALTER TABLE `O6V645X026` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O9AO8JZBVQ`
--

DROP TABLE IF EXISTS `O9AO8JZBVQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O9AO8JZBVQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O9AO8JZBVQ`
--

LOCK TABLES `O9AO8JZBVQ` WRITE;
/*!40000 ALTER TABLE `O9AO8JZBVQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `O9AO8JZBVQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `O9XGNEE4SN`
--

DROP TABLE IF EXISTS `O9XGNEE4SN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `O9XGNEE4SN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `O9XGNEE4SN`
--

LOCK TABLES `O9XGNEE4SN` WRITE;
/*!40000 ALTER TABLE `O9XGNEE4SN` DISABLE KEYS */;
/*!40000 ALTER TABLE `O9XGNEE4SN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OGX31141NG`
--

DROP TABLE IF EXISTS `OGX31141NG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OGX31141NG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OGX31141NG`
--

LOCK TABLES `OGX31141NG` WRITE;
/*!40000 ALTER TABLE `OGX31141NG` DISABLE KEYS */;
/*!40000 ALTER TABLE `OGX31141NG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OHTYO6M926`
--

DROP TABLE IF EXISTS `OHTYO6M926`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OHTYO6M926` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OHTYO6M926`
--

LOCK TABLES `OHTYO6M926` WRITE;
/*!40000 ALTER TABLE `OHTYO6M926` DISABLE KEYS */;
/*!40000 ALTER TABLE `OHTYO6M926` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OIKY1RI6F5`
--

DROP TABLE IF EXISTS `OIKY1RI6F5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OIKY1RI6F5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OIKY1RI6F5`
--

LOCK TABLES `OIKY1RI6F5` WRITE;
/*!40000 ALTER TABLE `OIKY1RI6F5` DISABLE KEYS */;
/*!40000 ALTER TABLE `OIKY1RI6F5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OJ51KGJSNC`
--

DROP TABLE IF EXISTS `OJ51KGJSNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OJ51KGJSNC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OJ51KGJSNC`
--

LOCK TABLES `OJ51KGJSNC` WRITE;
/*!40000 ALTER TABLE `OJ51KGJSNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `OJ51KGJSNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OJ5QOA0HVO`
--

DROP TABLE IF EXISTS `OJ5QOA0HVO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OJ5QOA0HVO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OJ5QOA0HVO`
--

LOCK TABLES `OJ5QOA0HVO` WRITE;
/*!40000 ALTER TABLE `OJ5QOA0HVO` DISABLE KEYS */;
/*!40000 ALTER TABLE `OJ5QOA0HVO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OKBC6JE1QD`
--

DROP TABLE IF EXISTS `OKBC6JE1QD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OKBC6JE1QD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OKBC6JE1QD`
--

LOCK TABLES `OKBC6JE1QD` WRITE;
/*!40000 ALTER TABLE `OKBC6JE1QD` DISABLE KEYS */;
/*!40000 ALTER TABLE `OKBC6JE1QD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OKSDYCYW4Y`
--

DROP TABLE IF EXISTS `OKSDYCYW4Y`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OKSDYCYW4Y` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OKSDYCYW4Y`
--

LOCK TABLES `OKSDYCYW4Y` WRITE;
/*!40000 ALTER TABLE `OKSDYCYW4Y` DISABLE KEYS */;
/*!40000 ALTER TABLE `OKSDYCYW4Y` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OKW56RERDH`
--

DROP TABLE IF EXISTS `OKW56RERDH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OKW56RERDH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OKW56RERDH`
--

LOCK TABLES `OKW56RERDH` WRITE;
/*!40000 ALTER TABLE `OKW56RERDH` DISABLE KEYS */;
/*!40000 ALTER TABLE `OKW56RERDH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OM7QYWGCNZ`
--

DROP TABLE IF EXISTS `OM7QYWGCNZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OM7QYWGCNZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OM7QYWGCNZ`
--

LOCK TABLES `OM7QYWGCNZ` WRITE;
/*!40000 ALTER TABLE `OM7QYWGCNZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `OM7QYWGCNZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OODCLXD9C3`
--

DROP TABLE IF EXISTS `OODCLXD9C3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OODCLXD9C3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OODCLXD9C3`
--

LOCK TABLES `OODCLXD9C3` WRITE;
/*!40000 ALTER TABLE `OODCLXD9C3` DISABLE KEYS */;
/*!40000 ALTER TABLE `OODCLXD9C3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OOGEP6WX4Q`
--

DROP TABLE IF EXISTS `OOGEP6WX4Q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OOGEP6WX4Q` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OOGEP6WX4Q`
--

LOCK TABLES `OOGEP6WX4Q` WRITE;
/*!40000 ALTER TABLE `OOGEP6WX4Q` DISABLE KEYS */;
/*!40000 ALTER TABLE `OOGEP6WX4Q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OPNC5XMHNN`
--

DROP TABLE IF EXISTS `OPNC5XMHNN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OPNC5XMHNN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OPNC5XMHNN`
--

LOCK TABLES `OPNC5XMHNN` WRITE;
/*!40000 ALTER TABLE `OPNC5XMHNN` DISABLE KEYS */;
/*!40000 ALTER TABLE `OPNC5XMHNN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OQXT6HQFHT`
--

DROP TABLE IF EXISTS `OQXT6HQFHT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OQXT6HQFHT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OQXT6HQFHT`
--

LOCK TABLES `OQXT6HQFHT` WRITE;
/*!40000 ALTER TABLE `OQXT6HQFHT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OQXT6HQFHT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OSJES6XS4T`
--

DROP TABLE IF EXISTS `OSJES6XS4T`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OSJES6XS4T` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OSJES6XS4T`
--

LOCK TABLES `OSJES6XS4T` WRITE;
/*!40000 ALTER TABLE `OSJES6XS4T` DISABLE KEYS */;
/*!40000 ALTER TABLE `OSJES6XS4T` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OWGLOT604B`
--

DROP TABLE IF EXISTS `OWGLOT604B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OWGLOT604B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OWGLOT604B`
--

LOCK TABLES `OWGLOT604B` WRITE;
/*!40000 ALTER TABLE `OWGLOT604B` DISABLE KEYS */;
/*!40000 ALTER TABLE `OWGLOT604B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P0WYB6SMKA`
--

DROP TABLE IF EXISTS `P0WYB6SMKA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P0WYB6SMKA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P0WYB6SMKA`
--

LOCK TABLES `P0WYB6SMKA` WRITE;
/*!40000 ALTER TABLE `P0WYB6SMKA` DISABLE KEYS */;
/*!40000 ALTER TABLE `P0WYB6SMKA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P1TI9HJJBP`
--

DROP TABLE IF EXISTS `P1TI9HJJBP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P1TI9HJJBP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P1TI9HJJBP`
--

LOCK TABLES `P1TI9HJJBP` WRITE;
/*!40000 ALTER TABLE `P1TI9HJJBP` DISABLE KEYS */;
/*!40000 ALTER TABLE `P1TI9HJJBP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P4W0GDWWGR`
--

DROP TABLE IF EXISTS `P4W0GDWWGR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P4W0GDWWGR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P4W0GDWWGR`
--

LOCK TABLES `P4W0GDWWGR` WRITE;
/*!40000 ALTER TABLE `P4W0GDWWGR` DISABLE KEYS */;
/*!40000 ALTER TABLE `P4W0GDWWGR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P5HGUDLU2V`
--

DROP TABLE IF EXISTS `P5HGUDLU2V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P5HGUDLU2V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P5HGUDLU2V`
--

LOCK TABLES `P5HGUDLU2V` WRITE;
/*!40000 ALTER TABLE `P5HGUDLU2V` DISABLE KEYS */;
/*!40000 ALTER TABLE `P5HGUDLU2V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P65CZHLY4U`
--

DROP TABLE IF EXISTS `P65CZHLY4U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P65CZHLY4U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P65CZHLY4U`
--

LOCK TABLES `P65CZHLY4U` WRITE;
/*!40000 ALTER TABLE `P65CZHLY4U` DISABLE KEYS */;
/*!40000 ALTER TABLE `P65CZHLY4U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P7FS0RYZ3J`
--

DROP TABLE IF EXISTS `P7FS0RYZ3J`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P7FS0RYZ3J` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P7FS0RYZ3J`
--

LOCK TABLES `P7FS0RYZ3J` WRITE;
/*!40000 ALTER TABLE `P7FS0RYZ3J` DISABLE KEYS */;
/*!40000 ALTER TABLE `P7FS0RYZ3J` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P8C5FIG6O0`
--

DROP TABLE IF EXISTS `P8C5FIG6O0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P8C5FIG6O0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P8C5FIG6O0`
--

LOCK TABLES `P8C5FIG6O0` WRITE;
/*!40000 ALTER TABLE `P8C5FIG6O0` DISABLE KEYS */;
/*!40000 ALTER TABLE `P8C5FIG6O0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P9DRGASHI7`
--

DROP TABLE IF EXISTS `P9DRGASHI7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P9DRGASHI7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P9DRGASHI7`
--

LOCK TABLES `P9DRGASHI7` WRITE;
/*!40000 ALTER TABLE `P9DRGASHI7` DISABLE KEYS */;
/*!40000 ALTER TABLE `P9DRGASHI7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `P9XKBLNP8N`
--

DROP TABLE IF EXISTS `P9XKBLNP8N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `P9XKBLNP8N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `P9XKBLNP8N`
--

LOCK TABLES `P9XKBLNP8N` WRITE;
/*!40000 ALTER TABLE `P9XKBLNP8N` DISABLE KEYS */;
/*!40000 ALTER TABLE `P9XKBLNP8N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PDM3573ASX`
--

DROP TABLE IF EXISTS `PDM3573ASX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PDM3573ASX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PDM3573ASX`
--

LOCK TABLES `PDM3573ASX` WRITE;
/*!40000 ALTER TABLE `PDM3573ASX` DISABLE KEYS */;
/*!40000 ALTER TABLE `PDM3573ASX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PER2SE8CWV`
--

DROP TABLE IF EXISTS `PER2SE8CWV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PER2SE8CWV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PER2SE8CWV`
--

LOCK TABLES `PER2SE8CWV` WRITE;
/*!40000 ALTER TABLE `PER2SE8CWV` DISABLE KEYS */;
/*!40000 ALTER TABLE `PER2SE8CWV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PFARX5WG74`
--

DROP TABLE IF EXISTS `PFARX5WG74`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PFARX5WG74` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PFARX5WG74`
--

LOCK TABLES `PFARX5WG74` WRITE;
/*!40000 ALTER TABLE `PFARX5WG74` DISABLE KEYS */;
/*!40000 ALTER TABLE `PFARX5WG74` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PGDTUSZG1O`
--

DROP TABLE IF EXISTS `PGDTUSZG1O`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PGDTUSZG1O` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PGDTUSZG1O`
--

LOCK TABLES `PGDTUSZG1O` WRITE;
/*!40000 ALTER TABLE `PGDTUSZG1O` DISABLE KEYS */;
/*!40000 ALTER TABLE `PGDTUSZG1O` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PGU7UP1G8S`
--

DROP TABLE IF EXISTS `PGU7UP1G8S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PGU7UP1G8S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PGU7UP1G8S`
--

LOCK TABLES `PGU7UP1G8S` WRITE;
/*!40000 ALTER TABLE `PGU7UP1G8S` DISABLE KEYS */;
/*!40000 ALTER TABLE `PGU7UP1G8S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PH56TZJDDP`
--

DROP TABLE IF EXISTS `PH56TZJDDP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PH56TZJDDP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PH56TZJDDP`
--

LOCK TABLES `PH56TZJDDP` WRITE;
/*!40000 ALTER TABLE `PH56TZJDDP` DISABLE KEYS */;
/*!40000 ALTER TABLE `PH56TZJDDP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PHO40F07YT`
--

DROP TABLE IF EXISTS `PHO40F07YT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PHO40F07YT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PHO40F07YT`
--

LOCK TABLES `PHO40F07YT` WRITE;
/*!40000 ALTER TABLE `PHO40F07YT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PHO40F07YT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PIEMSPRR6P`
--

DROP TABLE IF EXISTS `PIEMSPRR6P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PIEMSPRR6P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PIEMSPRR6P`
--

LOCK TABLES `PIEMSPRR6P` WRITE;
/*!40000 ALTER TABLE `PIEMSPRR6P` DISABLE KEYS */;
/*!40000 ALTER TABLE `PIEMSPRR6P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PJPJGC83J9`
--

DROP TABLE IF EXISTS `PJPJGC83J9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PJPJGC83J9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PJPJGC83J9`
--

LOCK TABLES `PJPJGC83J9` WRITE;
/*!40000 ALTER TABLE `PJPJGC83J9` DISABLE KEYS */;
/*!40000 ALTER TABLE `PJPJGC83J9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PNAR19FOCS`
--

DROP TABLE IF EXISTS `PNAR19FOCS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PNAR19FOCS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PNAR19FOCS`
--

LOCK TABLES `PNAR19FOCS` WRITE;
/*!40000 ALTER TABLE `PNAR19FOCS` DISABLE KEYS */;
/*!40000 ALTER TABLE `PNAR19FOCS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PQX21E2IXA`
--

DROP TABLE IF EXISTS `PQX21E2IXA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PQX21E2IXA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PQX21E2IXA`
--

LOCK TABLES `PQX21E2IXA` WRITE;
/*!40000 ALTER TABLE `PQX21E2IXA` DISABLE KEYS */;
/*!40000 ALTER TABLE `PQX21E2IXA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PS944UF5JS`
--

DROP TABLE IF EXISTS `PS944UF5JS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PS944UF5JS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PS944UF5JS`
--

LOCK TABLES `PS944UF5JS` WRITE;
/*!40000 ALTER TABLE `PS944UF5JS` DISABLE KEYS */;
/*!40000 ALTER TABLE `PS944UF5JS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PSD15P6MZ4`
--

DROP TABLE IF EXISTS `PSD15P6MZ4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PSD15P6MZ4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PSD15P6MZ4`
--

LOCK TABLES `PSD15P6MZ4` WRITE;
/*!40000 ALTER TABLE `PSD15P6MZ4` DISABLE KEYS */;
/*!40000 ALTER TABLE `PSD15P6MZ4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PTAV2FM43Z`
--

DROP TABLE IF EXISTS `PTAV2FM43Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PTAV2FM43Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PTAV2FM43Z`
--

LOCK TABLES `PTAV2FM43Z` WRITE;
/*!40000 ALTER TABLE `PTAV2FM43Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `PTAV2FM43Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWLSVYAGN5`
--

DROP TABLE IF EXISTS `PWLSVYAGN5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PWLSVYAGN5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWLSVYAGN5`
--

LOCK TABLES `PWLSVYAGN5` WRITE;
/*!40000 ALTER TABLE `PWLSVYAGN5` DISABLE KEYS */;
/*!40000 ALTER TABLE `PWLSVYAGN5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PWNUOULXTJ`
--

DROP TABLE IF EXISTS `PWNUOULXTJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PWNUOULXTJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PWNUOULXTJ`
--

LOCK TABLES `PWNUOULXTJ` WRITE;
/*!40000 ALTER TABLE `PWNUOULXTJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `PWNUOULXTJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PYCT8L5XNH`
--

DROP TABLE IF EXISTS `PYCT8L5XNH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PYCT8L5XNH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PYCT8L5XNH`
--

LOCK TABLES `PYCT8L5XNH` WRITE;
/*!40000 ALTER TABLE `PYCT8L5XNH` DISABLE KEYS */;
/*!40000 ALTER TABLE `PYCT8L5XNH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PYULW8NQUY`
--

DROP TABLE IF EXISTS `PYULW8NQUY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PYULW8NQUY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PYULW8NQUY`
--

LOCK TABLES `PYULW8NQUY` WRITE;
/*!40000 ALTER TABLE `PYULW8NQUY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PYULW8NQUY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Q15XLC9HDT`
--

DROP TABLE IF EXISTS `Q15XLC9HDT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Q15XLC9HDT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Q15XLC9HDT`
--

LOCK TABLES `Q15XLC9HDT` WRITE;
/*!40000 ALTER TABLE `Q15XLC9HDT` DISABLE KEYS */;
/*!40000 ALTER TABLE `Q15XLC9HDT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Q1M5SO09WE`
--

DROP TABLE IF EXISTS `Q1M5SO09WE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Q1M5SO09WE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Q1M5SO09WE`
--

LOCK TABLES `Q1M5SO09WE` WRITE;
/*!40000 ALTER TABLE `Q1M5SO09WE` DISABLE KEYS */;
/*!40000 ALTER TABLE `Q1M5SO09WE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Q3J6B6B3SR`
--

DROP TABLE IF EXISTS `Q3J6B6B3SR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Q3J6B6B3SR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Q3J6B6B3SR`
--

LOCK TABLES `Q3J6B6B3SR` WRITE;
/*!40000 ALTER TABLE `Q3J6B6B3SR` DISABLE KEYS */;
/*!40000 ALTER TABLE `Q3J6B6B3SR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Q77MYYO0IW`
--

DROP TABLE IF EXISTS `Q77MYYO0IW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Q77MYYO0IW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Q77MYYO0IW`
--

LOCK TABLES `Q77MYYO0IW` WRITE;
/*!40000 ALTER TABLE `Q77MYYO0IW` DISABLE KEYS */;
/*!40000 ALTER TABLE `Q77MYYO0IW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Q9X3BXAGCJ`
--

DROP TABLE IF EXISTS `Q9X3BXAGCJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Q9X3BXAGCJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Q9X3BXAGCJ`
--

LOCK TABLES `Q9X3BXAGCJ` WRITE;
/*!40000 ALTER TABLE `Q9X3BXAGCJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `Q9X3BXAGCJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QBL1K9119N`
--

DROP TABLE IF EXISTS `QBL1K9119N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QBL1K9119N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QBL1K9119N`
--

LOCK TABLES `QBL1K9119N` WRITE;
/*!40000 ALTER TABLE `QBL1K9119N` DISABLE KEYS */;
/*!40000 ALTER TABLE `QBL1K9119N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QC9G1GMTCR`
--

DROP TABLE IF EXISTS `QC9G1GMTCR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QC9G1GMTCR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QC9G1GMTCR`
--

LOCK TABLES `QC9G1GMTCR` WRITE;
/*!40000 ALTER TABLE `QC9G1GMTCR` DISABLE KEYS */;
/*!40000 ALTER TABLE `QC9G1GMTCR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QG72UCI2W4`
--

DROP TABLE IF EXISTS `QG72UCI2W4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QG72UCI2W4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QG72UCI2W4`
--

LOCK TABLES `QG72UCI2W4` WRITE;
/*!40000 ALTER TABLE `QG72UCI2W4` DISABLE KEYS */;
/*!40000 ALTER TABLE `QG72UCI2W4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QGJP53L541`
--

DROP TABLE IF EXISTS `QGJP53L541`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QGJP53L541` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QGJP53L541`
--

LOCK TABLES `QGJP53L541` WRITE;
/*!40000 ALTER TABLE `QGJP53L541` DISABLE KEYS */;
/*!40000 ALTER TABLE `QGJP53L541` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QH25YG0NY3`
--

DROP TABLE IF EXISTS `QH25YG0NY3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QH25YG0NY3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QH25YG0NY3`
--

LOCK TABLES `QH25YG0NY3` WRITE;
/*!40000 ALTER TABLE `QH25YG0NY3` DISABLE KEYS */;
/*!40000 ALTER TABLE `QH25YG0NY3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QH3E069YHJ`
--

DROP TABLE IF EXISTS `QH3E069YHJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QH3E069YHJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QH3E069YHJ`
--

LOCK TABLES `QH3E069YHJ` WRITE;
/*!40000 ALTER TABLE `QH3E069YHJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `QH3E069YHJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QHVMJL3IJ7`
--

DROP TABLE IF EXISTS `QHVMJL3IJ7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QHVMJL3IJ7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QHVMJL3IJ7`
--

LOCK TABLES `QHVMJL3IJ7` WRITE;
/*!40000 ALTER TABLE `QHVMJL3IJ7` DISABLE KEYS */;
/*!40000 ALTER TABLE `QHVMJL3IJ7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QIPI80ITKD`
--

DROP TABLE IF EXISTS `QIPI80ITKD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QIPI80ITKD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QIPI80ITKD`
--

LOCK TABLES `QIPI80ITKD` WRITE;
/*!40000 ALTER TABLE `QIPI80ITKD` DISABLE KEYS */;
/*!40000 ALTER TABLE `QIPI80ITKD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QIT3LUAR3M`
--

DROP TABLE IF EXISTS `QIT3LUAR3M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QIT3LUAR3M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QIT3LUAR3M`
--

LOCK TABLES `QIT3LUAR3M` WRITE;
/*!40000 ALTER TABLE `QIT3LUAR3M` DISABLE KEYS */;
/*!40000 ALTER TABLE `QIT3LUAR3M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QITRMCW84Z`
--

DROP TABLE IF EXISTS `QITRMCW84Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QITRMCW84Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QITRMCW84Z`
--

LOCK TABLES `QITRMCW84Z` WRITE;
/*!40000 ALTER TABLE `QITRMCW84Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `QITRMCW84Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QIU8T67K7N`
--

DROP TABLE IF EXISTS `QIU8T67K7N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QIU8T67K7N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QIU8T67K7N`
--

LOCK TABLES `QIU8T67K7N` WRITE;
/*!40000 ALTER TABLE `QIU8T67K7N` DISABLE KEYS */;
/*!40000 ALTER TABLE `QIU8T67K7N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QJ3AFV6WC2`
--

DROP TABLE IF EXISTS `QJ3AFV6WC2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QJ3AFV6WC2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QJ3AFV6WC2`
--

LOCK TABLES `QJ3AFV6WC2` WRITE;
/*!40000 ALTER TABLE `QJ3AFV6WC2` DISABLE KEYS */;
/*!40000 ALTER TABLE `QJ3AFV6WC2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QK5IRZZ4KN`
--

DROP TABLE IF EXISTS `QK5IRZZ4KN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QK5IRZZ4KN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QK5IRZZ4KN`
--

LOCK TABLES `QK5IRZZ4KN` WRITE;
/*!40000 ALTER TABLE `QK5IRZZ4KN` DISABLE KEYS */;
/*!40000 ALTER TABLE `QK5IRZZ4KN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QKXFNLJKBF`
--

DROP TABLE IF EXISTS `QKXFNLJKBF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QKXFNLJKBF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QKXFNLJKBF`
--

LOCK TABLES `QKXFNLJKBF` WRITE;
/*!40000 ALTER TABLE `QKXFNLJKBF` DISABLE KEYS */;
/*!40000 ALTER TABLE `QKXFNLJKBF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QLSXQB4XPK`
--

DROP TABLE IF EXISTS `QLSXQB4XPK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QLSXQB4XPK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QLSXQB4XPK`
--

LOCK TABLES `QLSXQB4XPK` WRITE;
/*!40000 ALTER TABLE `QLSXQB4XPK` DISABLE KEYS */;
/*!40000 ALTER TABLE `QLSXQB4XPK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QMAB0S5S4V`
--

DROP TABLE IF EXISTS `QMAB0S5S4V`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QMAB0S5S4V` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QMAB0S5S4V`
--

LOCK TABLES `QMAB0S5S4V` WRITE;
/*!40000 ALTER TABLE `QMAB0S5S4V` DISABLE KEYS */;
/*!40000 ALTER TABLE `QMAB0S5S4V` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QMABOOAB0H`
--

DROP TABLE IF EXISTS `QMABOOAB0H`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QMABOOAB0H` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QMABOOAB0H`
--

LOCK TABLES `QMABOOAB0H` WRITE;
/*!40000 ALTER TABLE `QMABOOAB0H` DISABLE KEYS */;
/*!40000 ALTER TABLE `QMABOOAB0H` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QMTE5W98KW`
--

DROP TABLE IF EXISTS `QMTE5W98KW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QMTE5W98KW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QMTE5W98KW`
--

LOCK TABLES `QMTE5W98KW` WRITE;
/*!40000 ALTER TABLE `QMTE5W98KW` DISABLE KEYS */;
/*!40000 ALTER TABLE `QMTE5W98KW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QN2IPR6079`
--

DROP TABLE IF EXISTS `QN2IPR6079`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QN2IPR6079` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QN2IPR6079`
--

LOCK TABLES `QN2IPR6079` WRITE;
/*!40000 ALTER TABLE `QN2IPR6079` DISABLE KEYS */;
/*!40000 ALTER TABLE `QN2IPR6079` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QNHG1SYKL2`
--

DROP TABLE IF EXISTS `QNHG1SYKL2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QNHG1SYKL2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QNHG1SYKL2`
--

LOCK TABLES `QNHG1SYKL2` WRITE;
/*!40000 ALTER TABLE `QNHG1SYKL2` DISABLE KEYS */;
/*!40000 ALTER TABLE `QNHG1SYKL2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QNIZ4UPTXT`
--

DROP TABLE IF EXISTS `QNIZ4UPTXT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QNIZ4UPTXT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QNIZ4UPTXT`
--

LOCK TABLES `QNIZ4UPTXT` WRITE;
/*!40000 ALTER TABLE `QNIZ4UPTXT` DISABLE KEYS */;
/*!40000 ALTER TABLE `QNIZ4UPTXT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QNSF6JDQ5S`
--

DROP TABLE IF EXISTS `QNSF6JDQ5S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QNSF6JDQ5S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QNSF6JDQ5S`
--

LOCK TABLES `QNSF6JDQ5S` WRITE;
/*!40000 ALTER TABLE `QNSF6JDQ5S` DISABLE KEYS */;
/*!40000 ALTER TABLE `QNSF6JDQ5S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QO8S4B3WDV`
--

DROP TABLE IF EXISTS `QO8S4B3WDV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QO8S4B3WDV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QO8S4B3WDV`
--

LOCK TABLES `QO8S4B3WDV` WRITE;
/*!40000 ALTER TABLE `QO8S4B3WDV` DISABLE KEYS */;
/*!40000 ALTER TABLE `QO8S4B3WDV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QODRKFB5NN`
--

DROP TABLE IF EXISTS `QODRKFB5NN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QODRKFB5NN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QODRKFB5NN`
--

LOCK TABLES `QODRKFB5NN` WRITE;
/*!40000 ALTER TABLE `QODRKFB5NN` DISABLE KEYS */;
/*!40000 ALTER TABLE `QODRKFB5NN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QQ7BM8UANM`
--

DROP TABLE IF EXISTS `QQ7BM8UANM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QQ7BM8UANM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QQ7BM8UANM`
--

LOCK TABLES `QQ7BM8UANM` WRITE;
/*!40000 ALTER TABLE `QQ7BM8UANM` DISABLE KEYS */;
/*!40000 ALTER TABLE `QQ7BM8UANM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QQ7PGE2S3F`
--

DROP TABLE IF EXISTS `QQ7PGE2S3F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QQ7PGE2S3F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QQ7PGE2S3F`
--

LOCK TABLES `QQ7PGE2S3F` WRITE;
/*!40000 ALTER TABLE `QQ7PGE2S3F` DISABLE KEYS */;
/*!40000 ALTER TABLE `QQ7PGE2S3F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QQBH44OTLZ`
--

DROP TABLE IF EXISTS `QQBH44OTLZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QQBH44OTLZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QQBH44OTLZ`
--

LOCK TABLES `QQBH44OTLZ` WRITE;
/*!40000 ALTER TABLE `QQBH44OTLZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `QQBH44OTLZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTHU0JPQZ`
--

DROP TABLE IF EXISTS `QRTHU0JPQZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTHU0JPQZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTHU0JPQZ`
--

LOCK TABLES `QRTHU0JPQZ` WRITE;
/*!40000 ALTER TABLE `QRTHU0JPQZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTHU0JPQZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QSV93C7KM2`
--

DROP TABLE IF EXISTS `QSV93C7KM2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QSV93C7KM2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QSV93C7KM2`
--

LOCK TABLES `QSV93C7KM2` WRITE;
/*!40000 ALTER TABLE `QSV93C7KM2` DISABLE KEYS */;
/*!40000 ALTER TABLE `QSV93C7KM2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QSXWCNBQU1`
--

DROP TABLE IF EXISTS `QSXWCNBQU1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QSXWCNBQU1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QSXWCNBQU1`
--

LOCK TABLES `QSXWCNBQU1` WRITE;
/*!40000 ALTER TABLE `QSXWCNBQU1` DISABLE KEYS */;
/*!40000 ALTER TABLE `QSXWCNBQU1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QTNEU5TMX7`
--

DROP TABLE IF EXISTS `QTNEU5TMX7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QTNEU5TMX7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QTNEU5TMX7`
--

LOCK TABLES `QTNEU5TMX7` WRITE;
/*!40000 ALTER TABLE `QTNEU5TMX7` DISABLE KEYS */;
/*!40000 ALTER TABLE `QTNEU5TMX7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QTYYG3BUIM`
--

DROP TABLE IF EXISTS `QTYYG3BUIM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QTYYG3BUIM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QTYYG3BUIM`
--

LOCK TABLES `QTYYG3BUIM` WRITE;
/*!40000 ALTER TABLE `QTYYG3BUIM` DISABLE KEYS */;
/*!40000 ALTER TABLE `QTYYG3BUIM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QVC747RNFO`
--

DROP TABLE IF EXISTS `QVC747RNFO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QVC747RNFO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QVC747RNFO`
--

LOCK TABLES `QVC747RNFO` WRITE;
/*!40000 ALTER TABLE `QVC747RNFO` DISABLE KEYS */;
/*!40000 ALTER TABLE `QVC747RNFO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QVJC5EQOE8`
--

DROP TABLE IF EXISTS `QVJC5EQOE8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QVJC5EQOE8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QVJC5EQOE8`
--

LOCK TABLES `QVJC5EQOE8` WRITE;
/*!40000 ALTER TABLE `QVJC5EQOE8` DISABLE KEYS */;
/*!40000 ALTER TABLE `QVJC5EQOE8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QYK1AZQGNI`
--

DROP TABLE IF EXISTS `QYK1AZQGNI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QYK1AZQGNI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QYK1AZQGNI`
--

LOCK TABLES `QYK1AZQGNI` WRITE;
/*!40000 ALTER TABLE `QYK1AZQGNI` DISABLE KEYS */;
/*!40000 ALTER TABLE `QYK1AZQGNI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R0352O3N2L`
--

DROP TABLE IF EXISTS `R0352O3N2L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R0352O3N2L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R0352O3N2L`
--

LOCK TABLES `R0352O3N2L` WRITE;
/*!40000 ALTER TABLE `R0352O3N2L` DISABLE KEYS */;
/*!40000 ALTER TABLE `R0352O3N2L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R0VZNDESFB`
--

DROP TABLE IF EXISTS `R0VZNDESFB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R0VZNDESFB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R0VZNDESFB`
--

LOCK TABLES `R0VZNDESFB` WRITE;
/*!40000 ALTER TABLE `R0VZNDESFB` DISABLE KEYS */;
/*!40000 ALTER TABLE `R0VZNDESFB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R2M6R2V082`
--

DROP TABLE IF EXISTS `R2M6R2V082`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R2M6R2V082` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R2M6R2V082`
--

LOCK TABLES `R2M6R2V082` WRITE;
/*!40000 ALTER TABLE `R2M6R2V082` DISABLE KEYS */;
/*!40000 ALTER TABLE `R2M6R2V082` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R50PAK6005`
--

DROP TABLE IF EXISTS `R50PAK6005`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R50PAK6005` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R50PAK6005`
--

LOCK TABLES `R50PAK6005` WRITE;
/*!40000 ALTER TABLE `R50PAK6005` DISABLE KEYS */;
/*!40000 ALTER TABLE `R50PAK6005` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R6K74CTWL8`
--

DROP TABLE IF EXISTS `R6K74CTWL8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R6K74CTWL8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R6K74CTWL8`
--

LOCK TABLES `R6K74CTWL8` WRITE;
/*!40000 ALTER TABLE `R6K74CTWL8` DISABLE KEYS */;
/*!40000 ALTER TABLE `R6K74CTWL8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R6RGNECGZ8`
--

DROP TABLE IF EXISTS `R6RGNECGZ8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R6RGNECGZ8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R6RGNECGZ8`
--

LOCK TABLES `R6RGNECGZ8` WRITE;
/*!40000 ALTER TABLE `R6RGNECGZ8` DISABLE KEYS */;
/*!40000 ALTER TABLE `R6RGNECGZ8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `R9J3BG32V0`
--

DROP TABLE IF EXISTS `R9J3BG32V0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `R9J3BG32V0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `R9J3BG32V0`
--

LOCK TABLES `R9J3BG32V0` WRITE;
/*!40000 ALTER TABLE `R9J3BG32V0` DISABLE KEYS */;
/*!40000 ALTER TABLE `R9J3BG32V0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RBENKH6R7Y`
--

DROP TABLE IF EXISTS `RBENKH6R7Y`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RBENKH6R7Y` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RBENKH6R7Y`
--

LOCK TABLES `RBENKH6R7Y` WRITE;
/*!40000 ALTER TABLE `RBENKH6R7Y` DISABLE KEYS */;
/*!40000 ALTER TABLE `RBENKH6R7Y` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RBWW47R7JV`
--

DROP TABLE IF EXISTS `RBWW47R7JV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RBWW47R7JV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RBWW47R7JV`
--

LOCK TABLES `RBWW47R7JV` WRITE;
/*!40000 ALTER TABLE `RBWW47R7JV` DISABLE KEYS */;
/*!40000 ALTER TABLE `RBWW47R7JV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RCTNZTJFL3`
--

DROP TABLE IF EXISTS `RCTNZTJFL3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RCTNZTJFL3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RCTNZTJFL3`
--

LOCK TABLES `RCTNZTJFL3` WRITE;
/*!40000 ALTER TABLE `RCTNZTJFL3` DISABLE KEYS */;
/*!40000 ALTER TABLE `RCTNZTJFL3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RD02DGED3K`
--

DROP TABLE IF EXISTS `RD02DGED3K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RD02DGED3K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RD02DGED3K`
--

LOCK TABLES `RD02DGED3K` WRITE;
/*!40000 ALTER TABLE `RD02DGED3K` DISABLE KEYS */;
/*!40000 ALTER TABLE `RD02DGED3K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RD8O37HS9W`
--

DROP TABLE IF EXISTS `RD8O37HS9W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RD8O37HS9W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RD8O37HS9W`
--

LOCK TABLES `RD8O37HS9W` WRITE;
/*!40000 ALTER TABLE `RD8O37HS9W` DISABLE KEYS */;
/*!40000 ALTER TABLE `RD8O37HS9W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RD8X3UW2DO`
--

DROP TABLE IF EXISTS `RD8X3UW2DO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RD8X3UW2DO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RD8X3UW2DO`
--

LOCK TABLES `RD8X3UW2DO` WRITE;
/*!40000 ALTER TABLE `RD8X3UW2DO` DISABLE KEYS */;
/*!40000 ALTER TABLE `RD8X3UW2DO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RF843CH9GJ`
--

DROP TABLE IF EXISTS `RF843CH9GJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RF843CH9GJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RF843CH9GJ`
--

LOCK TABLES `RF843CH9GJ` WRITE;
/*!40000 ALTER TABLE `RF843CH9GJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `RF843CH9GJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RG1XHPU676`
--

DROP TABLE IF EXISTS `RG1XHPU676`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RG1XHPU676` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RG1XHPU676`
--

LOCK TABLES `RG1XHPU676` WRITE;
/*!40000 ALTER TABLE `RG1XHPU676` DISABLE KEYS */;
/*!40000 ALTER TABLE `RG1XHPU676` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RIXQ2CVMEA`
--

DROP TABLE IF EXISTS `RIXQ2CVMEA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RIXQ2CVMEA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RIXQ2CVMEA`
--

LOCK TABLES `RIXQ2CVMEA` WRITE;
/*!40000 ALTER TABLE `RIXQ2CVMEA` DISABLE KEYS */;
/*!40000 ALTER TABLE `RIXQ2CVMEA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RJ8BZNFUO3`
--

DROP TABLE IF EXISTS `RJ8BZNFUO3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RJ8BZNFUO3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RJ8BZNFUO3`
--

LOCK TABLES `RJ8BZNFUO3` WRITE;
/*!40000 ALTER TABLE `RJ8BZNFUO3` DISABLE KEYS */;
/*!40000 ALTER TABLE `RJ8BZNFUO3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RKKG8CEPCE`
--

DROP TABLE IF EXISTS `RKKG8CEPCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RKKG8CEPCE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RKKG8CEPCE`
--

LOCK TABLES `RKKG8CEPCE` WRITE;
/*!40000 ALTER TABLE `RKKG8CEPCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RKKG8CEPCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RL1VOTVOSQ`
--

DROP TABLE IF EXISTS `RL1VOTVOSQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RL1VOTVOSQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RL1VOTVOSQ`
--

LOCK TABLES `RL1VOTVOSQ` WRITE;
/*!40000 ALTER TABLE `RL1VOTVOSQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `RL1VOTVOSQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RL3CWOLZGP`
--

DROP TABLE IF EXISTS `RL3CWOLZGP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RL3CWOLZGP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RL3CWOLZGP`
--

LOCK TABLES `RL3CWOLZGP` WRITE;
/*!40000 ALTER TABLE `RL3CWOLZGP` DISABLE KEYS */;
/*!40000 ALTER TABLE `RL3CWOLZGP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RLOZUZPUH5`
--

DROP TABLE IF EXISTS `RLOZUZPUH5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RLOZUZPUH5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RLOZUZPUH5`
--

LOCK TABLES `RLOZUZPUH5` WRITE;
/*!40000 ALTER TABLE `RLOZUZPUH5` DISABLE KEYS */;
/*!40000 ALTER TABLE `RLOZUZPUH5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RLSRDN477M`
--

DROP TABLE IF EXISTS `RLSRDN477M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RLSRDN477M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RLSRDN477M`
--

LOCK TABLES `RLSRDN477M` WRITE;
/*!40000 ALTER TABLE `RLSRDN477M` DISABLE KEYS */;
/*!40000 ALTER TABLE `RLSRDN477M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROSXDS2JBD`
--

DROP TABLE IF EXISTS `ROSXDS2JBD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROSXDS2JBD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROSXDS2JBD`
--

LOCK TABLES `ROSXDS2JBD` WRITE;
/*!40000 ALTER TABLE `ROSXDS2JBD` DISABLE KEYS */;
/*!40000 ALTER TABLE `ROSXDS2JBD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RPBVTEQ10P`
--

DROP TABLE IF EXISTS `RPBVTEQ10P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RPBVTEQ10P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RPBVTEQ10P`
--

LOCK TABLES `RPBVTEQ10P` WRITE;
/*!40000 ALTER TABLE `RPBVTEQ10P` DISABLE KEYS */;
/*!40000 ALTER TABLE `RPBVTEQ10P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RQ0WYZ9RSQ`
--

DROP TABLE IF EXISTS `RQ0WYZ9RSQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RQ0WYZ9RSQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RQ0WYZ9RSQ`
--

LOCK TABLES `RQ0WYZ9RSQ` WRITE;
/*!40000 ALTER TABLE `RQ0WYZ9RSQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `RQ0WYZ9RSQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RQLI3HU6XJ`
--

DROP TABLE IF EXISTS `RQLI3HU6XJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RQLI3HU6XJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RQLI3HU6XJ`
--

LOCK TABLES `RQLI3HU6XJ` WRITE;
/*!40000 ALTER TABLE `RQLI3HU6XJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `RQLI3HU6XJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RTEQ1R2H9Z`
--

DROP TABLE IF EXISTS `RTEQ1R2H9Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RTEQ1R2H9Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RTEQ1R2H9Z`
--

LOCK TABLES `RTEQ1R2H9Z` WRITE;
/*!40000 ALTER TABLE `RTEQ1R2H9Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `RTEQ1R2H9Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RTQWRKVMZE`
--

DROP TABLE IF EXISTS `RTQWRKVMZE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RTQWRKVMZE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RTQWRKVMZE`
--

LOCK TABLES `RTQWRKVMZE` WRITE;
/*!40000 ALTER TABLE `RTQWRKVMZE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RTQWRKVMZE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RTSYLKWKF3`
--

DROP TABLE IF EXISTS `RTSYLKWKF3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RTSYLKWKF3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RTSYLKWKF3`
--

LOCK TABLES `RTSYLKWKF3` WRITE;
/*!40000 ALTER TABLE `RTSYLKWKF3` DISABLE KEYS */;
/*!40000 ALTER TABLE `RTSYLKWKF3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RVA4YLGZQX`
--

DROP TABLE IF EXISTS `RVA4YLGZQX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RVA4YLGZQX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RVA4YLGZQX`
--

LOCK TABLES `RVA4YLGZQX` WRITE;
/*!40000 ALTER TABLE `RVA4YLGZQX` DISABLE KEYS */;
/*!40000 ALTER TABLE `RVA4YLGZQX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RWA2D6GGSI`
--

DROP TABLE IF EXISTS `RWA2D6GGSI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RWA2D6GGSI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RWA2D6GGSI`
--

LOCK TABLES `RWA2D6GGSI` WRITE;
/*!40000 ALTER TABLE `RWA2D6GGSI` DISABLE KEYS */;
/*!40000 ALTER TABLE `RWA2D6GGSI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RX7WIEHJIN`
--

DROP TABLE IF EXISTS `RX7WIEHJIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RX7WIEHJIN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RX7WIEHJIN`
--

LOCK TABLES `RX7WIEHJIN` WRITE;
/*!40000 ALTER TABLE `RX7WIEHJIN` DISABLE KEYS */;
/*!40000 ALTER TABLE `RX7WIEHJIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RXE96AH3F2`
--

DROP TABLE IF EXISTS `RXE96AH3F2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RXE96AH3F2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RXE96AH3F2`
--

LOCK TABLES `RXE96AH3F2` WRITE;
/*!40000 ALTER TABLE `RXE96AH3F2` DISABLE KEYS */;
/*!40000 ALTER TABLE `RXE96AH3F2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RY0WLA4BBE`
--

DROP TABLE IF EXISTS `RY0WLA4BBE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RY0WLA4BBE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RY0WLA4BBE`
--

LOCK TABLES `RY0WLA4BBE` WRITE;
/*!40000 ALTER TABLE `RY0WLA4BBE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RY0WLA4BBE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RYBGRDB26W`
--

DROP TABLE IF EXISTS `RYBGRDB26W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RYBGRDB26W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RYBGRDB26W`
--

LOCK TABLES `RYBGRDB26W` WRITE;
/*!40000 ALTER TABLE `RYBGRDB26W` DISABLE KEYS */;
/*!40000 ALTER TABLE `RYBGRDB26W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RZHGV7ET9O`
--

DROP TABLE IF EXISTS `RZHGV7ET9O`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RZHGV7ET9O` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RZHGV7ET9O`
--

LOCK TABLES `RZHGV7ET9O` WRITE;
/*!40000 ALTER TABLE `RZHGV7ET9O` DISABLE KEYS */;
/*!40000 ALTER TABLE `RZHGV7ET9O` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `S2K0J4ORLB`
--

DROP TABLE IF EXISTS `S2K0J4ORLB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `S2K0J4ORLB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `S2K0J4ORLB`
--

LOCK TABLES `S2K0J4ORLB` WRITE;
/*!40000 ALTER TABLE `S2K0J4ORLB` DISABLE KEYS */;
/*!40000 ALTER TABLE `S2K0J4ORLB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `S5JP3RN822`
--

DROP TABLE IF EXISTS `S5JP3RN822`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `S5JP3RN822` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `S5JP3RN822`
--

LOCK TABLES `S5JP3RN822` WRITE;
/*!40000 ALTER TABLE `S5JP3RN822` DISABLE KEYS */;
/*!40000 ALTER TABLE `S5JP3RN822` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `S6VG03ANGZ`
--

DROP TABLE IF EXISTS `S6VG03ANGZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `S6VG03ANGZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `S6VG03ANGZ`
--

LOCK TABLES `S6VG03ANGZ` WRITE;
/*!40000 ALTER TABLE `S6VG03ANGZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `S6VG03ANGZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SBQF6HLASE`
--

DROP TABLE IF EXISTS `SBQF6HLASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SBQF6HLASE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SBQF6HLASE`
--

LOCK TABLES `SBQF6HLASE` WRITE;
/*!40000 ALTER TABLE `SBQF6HLASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `SBQF6HLASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SD9MTPGPN1`
--

DROP TABLE IF EXISTS `SD9MTPGPN1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SD9MTPGPN1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SD9MTPGPN1`
--

LOCK TABLES `SD9MTPGPN1` WRITE;
/*!40000 ALTER TABLE `SD9MTPGPN1` DISABLE KEYS */;
/*!40000 ALTER TABLE `SD9MTPGPN1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SDRLTY9Q9D`
--

DROP TABLE IF EXISTS `SDRLTY9Q9D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SDRLTY9Q9D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SDRLTY9Q9D`
--

LOCK TABLES `SDRLTY9Q9D` WRITE;
/*!40000 ALTER TABLE `SDRLTY9Q9D` DISABLE KEYS */;
/*!40000 ALTER TABLE `SDRLTY9Q9D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SE9P4BVZGT`
--

DROP TABLE IF EXISTS `SE9P4BVZGT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SE9P4BVZGT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SE9P4BVZGT`
--

LOCK TABLES `SE9P4BVZGT` WRITE;
/*!40000 ALTER TABLE `SE9P4BVZGT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SE9P4BVZGT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEDNJN0TT5`
--

DROP TABLE IF EXISTS `SEDNJN0TT5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEDNJN0TT5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEDNJN0TT5`
--

LOCK TABLES `SEDNJN0TT5` WRITE;
/*!40000 ALTER TABLE `SEDNJN0TT5` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEDNJN0TT5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SH497PPPC8`
--

DROP TABLE IF EXISTS `SH497PPPC8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SH497PPPC8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SH497PPPC8`
--

LOCK TABLES `SH497PPPC8` WRITE;
/*!40000 ALTER TABLE `SH497PPPC8` DISABLE KEYS */;
/*!40000 ALTER TABLE `SH497PPPC8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SI8W70V8OO`
--

DROP TABLE IF EXISTS `SI8W70V8OO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SI8W70V8OO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SI8W70V8OO`
--

LOCK TABLES `SI8W70V8OO` WRITE;
/*!40000 ALTER TABLE `SI8W70V8OO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SI8W70V8OO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SJ71O17UVC`
--

DROP TABLE IF EXISTS `SJ71O17UVC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SJ71O17UVC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SJ71O17UVC`
--

LOCK TABLES `SJ71O17UVC` WRITE;
/*!40000 ALTER TABLE `SJ71O17UVC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SJ71O17UVC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SK6HD5J3T6`
--

DROP TABLE IF EXISTS `SK6HD5J3T6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SK6HD5J3T6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SK6HD5J3T6`
--

LOCK TABLES `SK6HD5J3T6` WRITE;
/*!40000 ALTER TABLE `SK6HD5J3T6` DISABLE KEYS */;
/*!40000 ALTER TABLE `SK6HD5J3T6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SL2WX1BHJI`
--

DROP TABLE IF EXISTS `SL2WX1BHJI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SL2WX1BHJI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SL2WX1BHJI`
--

LOCK TABLES `SL2WX1BHJI` WRITE;
/*!40000 ALTER TABLE `SL2WX1BHJI` DISABLE KEYS */;
/*!40000 ALTER TABLE `SL2WX1BHJI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SNAT62DY3Z`
--

DROP TABLE IF EXISTS `SNAT62DY3Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SNAT62DY3Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SNAT62DY3Z`
--

LOCK TABLES `SNAT62DY3Z` WRITE;
/*!40000 ALTER TABLE `SNAT62DY3Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `SNAT62DY3Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SNFFN232JU`
--

DROP TABLE IF EXISTS `SNFFN232JU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SNFFN232JU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SNFFN232JU`
--

LOCK TABLES `SNFFN232JU` WRITE;
/*!40000 ALTER TABLE `SNFFN232JU` DISABLE KEYS */;
/*!40000 ALTER TABLE `SNFFN232JU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SS471GU537`
--

DROP TABLE IF EXISTS `SS471GU537`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SS471GU537` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SS471GU537`
--

LOCK TABLES `SS471GU537` WRITE;
/*!40000 ALTER TABLE `SS471GU537` DISABLE KEYS */;
/*!40000 ALTER TABLE `SS471GU537` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ST18MTGS8S`
--

DROP TABLE IF EXISTS `ST18MTGS8S`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ST18MTGS8S` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ST18MTGS8S`
--

LOCK TABLES `ST18MTGS8S` WRITE;
/*!40000 ALTER TABLE `ST18MTGS8S` DISABLE KEYS */;
/*!40000 ALTER TABLE `ST18MTGS8S` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STGUXC3ETV`
--

DROP TABLE IF EXISTS `STGUXC3ETV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `STGUXC3ETV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STGUXC3ETV`
--

LOCK TABLES `STGUXC3ETV` WRITE;
/*!40000 ALTER TABLE `STGUXC3ETV` DISABLE KEYS */;
/*!40000 ALTER TABLE `STGUXC3ETV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SUZPH8PCMK`
--

DROP TABLE IF EXISTS `SUZPH8PCMK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SUZPH8PCMK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SUZPH8PCMK`
--

LOCK TABLES `SUZPH8PCMK` WRITE;
/*!40000 ALTER TABLE `SUZPH8PCMK` DISABLE KEYS */;
/*!40000 ALTER TABLE `SUZPH8PCMK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SV4SWC2OTH`
--

DROP TABLE IF EXISTS `SV4SWC2OTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SV4SWC2OTH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SV4SWC2OTH`
--

LOCK TABLES `SV4SWC2OTH` WRITE;
/*!40000 ALTER TABLE `SV4SWC2OTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `SV4SWC2OTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SV64YBMI21`
--

DROP TABLE IF EXISTS `SV64YBMI21`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SV64YBMI21` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SV64YBMI21`
--

LOCK TABLES `SV64YBMI21` WRITE;
/*!40000 ALTER TABLE `SV64YBMI21` DISABLE KEYS */;
/*!40000 ALTER TABLE `SV64YBMI21` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T0L36XDD18`
--

DROP TABLE IF EXISTS `T0L36XDD18`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T0L36XDD18` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T0L36XDD18`
--

LOCK TABLES `T0L36XDD18` WRITE;
/*!40000 ALTER TABLE `T0L36XDD18` DISABLE KEYS */;
/*!40000 ALTER TABLE `T0L36XDD18` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T1KJEV7HKE`
--

DROP TABLE IF EXISTS `T1KJEV7HKE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T1KJEV7HKE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T1KJEV7HKE`
--

LOCK TABLES `T1KJEV7HKE` WRITE;
/*!40000 ALTER TABLE `T1KJEV7HKE` DISABLE KEYS */;
/*!40000 ALTER TABLE `T1KJEV7HKE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T1KLS3D79B`
--

DROP TABLE IF EXISTS `T1KLS3D79B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T1KLS3D79B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T1KLS3D79B`
--

LOCK TABLES `T1KLS3D79B` WRITE;
/*!40000 ALTER TABLE `T1KLS3D79B` DISABLE KEYS */;
/*!40000 ALTER TABLE `T1KLS3D79B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T2Z3V53OCD`
--

DROP TABLE IF EXISTS `T2Z3V53OCD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T2Z3V53OCD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T2Z3V53OCD`
--

LOCK TABLES `T2Z3V53OCD` WRITE;
/*!40000 ALTER TABLE `T2Z3V53OCD` DISABLE KEYS */;
/*!40000 ALTER TABLE `T2Z3V53OCD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T3B6GLUROQ`
--

DROP TABLE IF EXISTS `T3B6GLUROQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T3B6GLUROQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T3B6GLUROQ`
--

LOCK TABLES `T3B6GLUROQ` WRITE;
/*!40000 ALTER TABLE `T3B6GLUROQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `T3B6GLUROQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T4U98ZX6VU`
--

DROP TABLE IF EXISTS `T4U98ZX6VU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T4U98ZX6VU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T4U98ZX6VU`
--

LOCK TABLES `T4U98ZX6VU` WRITE;
/*!40000 ALTER TABLE `T4U98ZX6VU` DISABLE KEYS */;
/*!40000 ALTER TABLE `T4U98ZX6VU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `T6H25J1U3D`
--

DROP TABLE IF EXISTS `T6H25J1U3D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `T6H25J1U3D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `T6H25J1U3D`
--

LOCK TABLES `T6H25J1U3D` WRITE;
/*!40000 ALTER TABLE `T6H25J1U3D` DISABLE KEYS */;
/*!40000 ALTER TABLE `T6H25J1U3D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TCU5A2JVTU`
--

DROP TABLE IF EXISTS `TCU5A2JVTU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TCU5A2JVTU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TCU5A2JVTU`
--

LOCK TABLES `TCU5A2JVTU` WRITE;
/*!40000 ALTER TABLE `TCU5A2JVTU` DISABLE KEYS */;
/*!40000 ALTER TABLE `TCU5A2JVTU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TCWQ1NQCUR`
--

DROP TABLE IF EXISTS `TCWQ1NQCUR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TCWQ1NQCUR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TCWQ1NQCUR`
--

LOCK TABLES `TCWQ1NQCUR` WRITE;
/*!40000 ALTER TABLE `TCWQ1NQCUR` DISABLE KEYS */;
/*!40000 ALTER TABLE `TCWQ1NQCUR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TCYGOVRYKC`
--

DROP TABLE IF EXISTS `TCYGOVRYKC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TCYGOVRYKC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TCYGOVRYKC`
--

LOCK TABLES `TCYGOVRYKC` WRITE;
/*!40000 ALTER TABLE `TCYGOVRYKC` DISABLE KEYS */;
/*!40000 ALTER TABLE `TCYGOVRYKC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TDWTV0PYMY`
--

DROP TABLE IF EXISTS `TDWTV0PYMY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TDWTV0PYMY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TDWTV0PYMY`
--

LOCK TABLES `TDWTV0PYMY` WRITE;
/*!40000 ALTER TABLE `TDWTV0PYMY` DISABLE KEYS */;
/*!40000 ALTER TABLE `TDWTV0PYMY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TGEBU71LYR`
--

DROP TABLE IF EXISTS `TGEBU71LYR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TGEBU71LYR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TGEBU71LYR`
--

LOCK TABLES `TGEBU71LYR` WRITE;
/*!40000 ALTER TABLE `TGEBU71LYR` DISABLE KEYS */;
/*!40000 ALTER TABLE `TGEBU71LYR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TH8C3GJUI8`
--

DROP TABLE IF EXISTS `TH8C3GJUI8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TH8C3GJUI8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TH8C3GJUI8`
--

LOCK TABLES `TH8C3GJUI8` WRITE;
/*!40000 ALTER TABLE `TH8C3GJUI8` DISABLE KEYS */;
/*!40000 ALTER TABLE `TH8C3GJUI8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TI7W2BWJB6`
--

DROP TABLE IF EXISTS `TI7W2BWJB6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TI7W2BWJB6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TI7W2BWJB6`
--

LOCK TABLES `TI7W2BWJB6` WRITE;
/*!40000 ALTER TABLE `TI7W2BWJB6` DISABLE KEYS */;
/*!40000 ALTER TABLE `TI7W2BWJB6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKU2SL7TRD`
--

DROP TABLE IF EXISTS `TKU2SL7TRD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TKU2SL7TRD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKU2SL7TRD`
--

LOCK TABLES `TKU2SL7TRD` WRITE;
/*!40000 ALTER TABLE `TKU2SL7TRD` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKU2SL7TRD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TL0T0W87HG`
--

DROP TABLE IF EXISTS `TL0T0W87HG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TL0T0W87HG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TL0T0W87HG`
--

LOCK TABLES `TL0T0W87HG` WRITE;
/*!40000 ALTER TABLE `TL0T0W87HG` DISABLE KEYS */;
/*!40000 ALTER TABLE `TL0T0W87HG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TLUMM7X6P1`
--

DROP TABLE IF EXISTS `TLUMM7X6P1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TLUMM7X6P1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TLUMM7X6P1`
--

LOCK TABLES `TLUMM7X6P1` WRITE;
/*!40000 ALTER TABLE `TLUMM7X6P1` DISABLE KEYS */;
/*!40000 ALTER TABLE `TLUMM7X6P1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TNGVLDFYLO`
--

DROP TABLE IF EXISTS `TNGVLDFYLO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TNGVLDFYLO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TNGVLDFYLO`
--

LOCK TABLES `TNGVLDFYLO` WRITE;
/*!40000 ALTER TABLE `TNGVLDFYLO` DISABLE KEYS */;
/*!40000 ALTER TABLE `TNGVLDFYLO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRE26FYRQT`
--

DROP TABLE IF EXISTS `TRE26FYRQT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRE26FYRQT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRE26FYRQT`
--

LOCK TABLES `TRE26FYRQT` WRITE;
/*!40000 ALTER TABLE `TRE26FYRQT` DISABLE KEYS */;
/*!40000 ALTER TABLE `TRE26FYRQT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRZY822I8E`
--

DROP TABLE IF EXISTS `TRZY822I8E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRZY822I8E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRZY822I8E`
--

LOCK TABLES `TRZY822I8E` WRITE;
/*!40000 ALTER TABLE `TRZY822I8E` DISABLE KEYS */;
/*!40000 ALTER TABLE `TRZY822I8E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TT3844I9TR`
--

DROP TABLE IF EXISTS `TT3844I9TR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TT3844I9TR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TT3844I9TR`
--

LOCK TABLES `TT3844I9TR` WRITE;
/*!40000 ALTER TABLE `TT3844I9TR` DISABLE KEYS */;
/*!40000 ALTER TABLE `TT3844I9TR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TTTQOD0UPC`
--

DROP TABLE IF EXISTS `TTTQOD0UPC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TTTQOD0UPC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TTTQOD0UPC`
--

LOCK TABLES `TTTQOD0UPC` WRITE;
/*!40000 ALTER TABLE `TTTQOD0UPC` DISABLE KEYS */;
/*!40000 ALTER TABLE `TTTQOD0UPC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TUGW8GUKFC`
--

DROP TABLE IF EXISTS `TUGW8GUKFC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TUGW8GUKFC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TUGW8GUKFC`
--

LOCK TABLES `TUGW8GUKFC` WRITE;
/*!40000 ALTER TABLE `TUGW8GUKFC` DISABLE KEYS */;
/*!40000 ALTER TABLE `TUGW8GUKFC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TXO9LXTR3D`
--

DROP TABLE IF EXISTS `TXO9LXTR3D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TXO9LXTR3D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TXO9LXTR3D`
--

LOCK TABLES `TXO9LXTR3D` WRITE;
/*!40000 ALTER TABLE `TXO9LXTR3D` DISABLE KEYS */;
/*!40000 ALTER TABLE `TXO9LXTR3D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U00198NV2M`
--

DROP TABLE IF EXISTS `U00198NV2M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U00198NV2M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U00198NV2M`
--

LOCK TABLES `U00198NV2M` WRITE;
/*!40000 ALTER TABLE `U00198NV2M` DISABLE KEYS */;
/*!40000 ALTER TABLE `U00198NV2M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U0E693J31Q`
--

DROP TABLE IF EXISTS `U0E693J31Q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U0E693J31Q` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U0E693J31Q`
--

LOCK TABLES `U0E693J31Q` WRITE;
/*!40000 ALTER TABLE `U0E693J31Q` DISABLE KEYS */;
/*!40000 ALTER TABLE `U0E693J31Q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U3UY9QLE2R`
--

DROP TABLE IF EXISTS `U3UY9QLE2R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U3UY9QLE2R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U3UY9QLE2R`
--

LOCK TABLES `U3UY9QLE2R` WRITE;
/*!40000 ALTER TABLE `U3UY9QLE2R` DISABLE KEYS */;
/*!40000 ALTER TABLE `U3UY9QLE2R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U4YO4JKFNE`
--

DROP TABLE IF EXISTS `U4YO4JKFNE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U4YO4JKFNE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U4YO4JKFNE`
--

LOCK TABLES `U4YO4JKFNE` WRITE;
/*!40000 ALTER TABLE `U4YO4JKFNE` DISABLE KEYS */;
/*!40000 ALTER TABLE `U4YO4JKFNE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U70COVTF19`
--

DROP TABLE IF EXISTS `U70COVTF19`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U70COVTF19` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U70COVTF19`
--

LOCK TABLES `U70COVTF19` WRITE;
/*!40000 ALTER TABLE `U70COVTF19` DISABLE KEYS */;
/*!40000 ALTER TABLE `U70COVTF19` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `U99FDQSJ4W`
--

DROP TABLE IF EXISTS `U99FDQSJ4W`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `U99FDQSJ4W` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `U99FDQSJ4W`
--

LOCK TABLES `U99FDQSJ4W` WRITE;
/*!40000 ALTER TABLE `U99FDQSJ4W` DISABLE KEYS */;
/*!40000 ALTER TABLE `U99FDQSJ4W` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UAM0OC1Q7L`
--

DROP TABLE IF EXISTS `UAM0OC1Q7L`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UAM0OC1Q7L` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UAM0OC1Q7L`
--

LOCK TABLES `UAM0OC1Q7L` WRITE;
/*!40000 ALTER TABLE `UAM0OC1Q7L` DISABLE KEYS */;
/*!40000 ALTER TABLE `UAM0OC1Q7L` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UAPW0NCXDR`
--

DROP TABLE IF EXISTS `UAPW0NCXDR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UAPW0NCXDR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UAPW0NCXDR`
--

LOCK TABLES `UAPW0NCXDR` WRITE;
/*!40000 ALTER TABLE `UAPW0NCXDR` DISABLE KEYS */;
/*!40000 ALTER TABLE `UAPW0NCXDR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UEI2LQHBDJ`
--

DROP TABLE IF EXISTS `UEI2LQHBDJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UEI2LQHBDJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UEI2LQHBDJ`
--

LOCK TABLES `UEI2LQHBDJ` WRITE;
/*!40000 ALTER TABLE `UEI2LQHBDJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `UEI2LQHBDJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UG16RN8RLK`
--

DROP TABLE IF EXISTS `UG16RN8RLK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UG16RN8RLK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UG16RN8RLK`
--

LOCK TABLES `UG16RN8RLK` WRITE;
/*!40000 ALTER TABLE `UG16RN8RLK` DISABLE KEYS */;
/*!40000 ALTER TABLE `UG16RN8RLK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UI2TIBU5X2`
--

DROP TABLE IF EXISTS `UI2TIBU5X2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UI2TIBU5X2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UI2TIBU5X2`
--

LOCK TABLES `UI2TIBU5X2` WRITE;
/*!40000 ALTER TABLE `UI2TIBU5X2` DISABLE KEYS */;
/*!40000 ALTER TABLE `UI2TIBU5X2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UI5AKN66LH`
--

DROP TABLE IF EXISTS `UI5AKN66LH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UI5AKN66LH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UI5AKN66LH`
--

LOCK TABLES `UI5AKN66LH` WRITE;
/*!40000 ALTER TABLE `UI5AKN66LH` DISABLE KEYS */;
/*!40000 ALTER TABLE `UI5AKN66LH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UKTIFPSG72`
--

DROP TABLE IF EXISTS `UKTIFPSG72`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UKTIFPSG72` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UKTIFPSG72`
--

LOCK TABLES `UKTIFPSG72` WRITE;
/*!40000 ALTER TABLE `UKTIFPSG72` DISABLE KEYS */;
/*!40000 ALTER TABLE `UKTIFPSG72` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UL055V4QZG`
--

DROP TABLE IF EXISTS `UL055V4QZG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UL055V4QZG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UL055V4QZG`
--

LOCK TABLES `UL055V4QZG` WRITE;
/*!40000 ALTER TABLE `UL055V4QZG` DISABLE KEYS */;
/*!40000 ALTER TABLE `UL055V4QZG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UL39MK2YTL`
--

DROP TABLE IF EXISTS `UL39MK2YTL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UL39MK2YTL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UL39MK2YTL`
--

LOCK TABLES `UL39MK2YTL` WRITE;
/*!40000 ALTER TABLE `UL39MK2YTL` DISABLE KEYS */;
/*!40000 ALTER TABLE `UL39MK2YTL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UMHC6WAEJF`
--

DROP TABLE IF EXISTS `UMHC6WAEJF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UMHC6WAEJF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UMHC6WAEJF`
--

LOCK TABLES `UMHC6WAEJF` WRITE;
/*!40000 ALTER TABLE `UMHC6WAEJF` DISABLE KEYS */;
/*!40000 ALTER TABLE `UMHC6WAEJF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNO9OUX63R`
--

DROP TABLE IF EXISTS `UNO9OUX63R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNO9OUX63R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNO9OUX63R`
--

LOCK TABLES `UNO9OUX63R` WRITE;
/*!40000 ALTER TABLE `UNO9OUX63R` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNO9OUX63R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UPL00MZ71M`
--

DROP TABLE IF EXISTS `UPL00MZ71M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UPL00MZ71M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UPL00MZ71M`
--

LOCK TABLES `UPL00MZ71M` WRITE;
/*!40000 ALTER TABLE `UPL00MZ71M` DISABLE KEYS */;
/*!40000 ALTER TABLE `UPL00MZ71M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UR4Z4TJ291`
--

DROP TABLE IF EXISTS `UR4Z4TJ291`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UR4Z4TJ291` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UR4Z4TJ291`
--

LOCK TABLES `UR4Z4TJ291` WRITE;
/*!40000 ALTER TABLE `UR4Z4TJ291` DISABLE KEYS */;
/*!40000 ALTER TABLE `UR4Z4TJ291` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `URGAG4B53D`
--

DROP TABLE IF EXISTS `URGAG4B53D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `URGAG4B53D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `URGAG4B53D`
--

LOCK TABLES `URGAG4B53D` WRITE;
/*!40000 ALTER TABLE `URGAG4B53D` DISABLE KEYS */;
/*!40000 ALTER TABLE `URGAG4B53D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UT2GT9EZXS`
--

DROP TABLE IF EXISTS `UT2GT9EZXS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UT2GT9EZXS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UT2GT9EZXS`
--

LOCK TABLES `UT2GT9EZXS` WRITE;
/*!40000 ALTER TABLE `UT2GT9EZXS` DISABLE KEYS */;
/*!40000 ALTER TABLE `UT2GT9EZXS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UT75HMASUJ`
--

DROP TABLE IF EXISTS `UT75HMASUJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UT75HMASUJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UT75HMASUJ`
--

LOCK TABLES `UT75HMASUJ` WRITE;
/*!40000 ALTER TABLE `UT75HMASUJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `UT75HMASUJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UUSUTOO422`
--

DROP TABLE IF EXISTS `UUSUTOO422`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UUSUTOO422` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UUSUTOO422`
--

LOCK TABLES `UUSUTOO422` WRITE;
/*!40000 ALTER TABLE `UUSUTOO422` DISABLE KEYS */;
/*!40000 ALTER TABLE `UUSUTOO422` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UWXP40GD7P`
--

DROP TABLE IF EXISTS `UWXP40GD7P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UWXP40GD7P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UWXP40GD7P`
--

LOCK TABLES `UWXP40GD7P` WRITE;
/*!40000 ALTER TABLE `UWXP40GD7P` DISABLE KEYS */;
/*!40000 ALTER TABLE `UWXP40GD7P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UX0DCFRWBG`
--

DROP TABLE IF EXISTS `UX0DCFRWBG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UX0DCFRWBG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UX0DCFRWBG`
--

LOCK TABLES `UX0DCFRWBG` WRITE;
/*!40000 ALTER TABLE `UX0DCFRWBG` DISABLE KEYS */;
/*!40000 ALTER TABLE `UX0DCFRWBG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UYBBNN40TP`
--

DROP TABLE IF EXISTS `UYBBNN40TP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UYBBNN40TP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UYBBNN40TP`
--

LOCK TABLES `UYBBNN40TP` WRITE;
/*!40000 ALTER TABLE `UYBBNN40TP` DISABLE KEYS */;
/*!40000 ALTER TABLE `UYBBNN40TP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UYDC63TP7G`
--

DROP TABLE IF EXISTS `UYDC63TP7G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UYDC63TP7G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UYDC63TP7G`
--

LOCK TABLES `UYDC63TP7G` WRITE;
/*!40000 ALTER TABLE `UYDC63TP7G` DISABLE KEYS */;
/*!40000 ALTER TABLE `UYDC63TP7G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UZA8KY7S1N`
--

DROP TABLE IF EXISTS `UZA8KY7S1N`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UZA8KY7S1N` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UZA8KY7S1N`
--

LOCK TABLES `UZA8KY7S1N` WRITE;
/*!40000 ALTER TABLE `UZA8KY7S1N` DISABLE KEYS */;
/*!40000 ALTER TABLE `UZA8KY7S1N` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UZCUIEC6ML`
--

DROP TABLE IF EXISTS `UZCUIEC6ML`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UZCUIEC6ML` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UZCUIEC6ML`
--

LOCK TABLES `UZCUIEC6ML` WRITE;
/*!40000 ALTER TABLE `UZCUIEC6ML` DISABLE KEYS */;
/*!40000 ALTER TABLE `UZCUIEC6ML` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V38J4E6QP6`
--

DROP TABLE IF EXISTS `V38J4E6QP6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V38J4E6QP6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V38J4E6QP6`
--

LOCK TABLES `V38J4E6QP6` WRITE;
/*!40000 ALTER TABLE `V38J4E6QP6` DISABLE KEYS */;
/*!40000 ALTER TABLE `V38J4E6QP6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V3KJSJ8Q70`
--

DROP TABLE IF EXISTS `V3KJSJ8Q70`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V3KJSJ8Q70` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V3KJSJ8Q70`
--

LOCK TABLES `V3KJSJ8Q70` WRITE;
/*!40000 ALTER TABLE `V3KJSJ8Q70` DISABLE KEYS */;
/*!40000 ALTER TABLE `V3KJSJ8Q70` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V50DPFZC2E`
--

DROP TABLE IF EXISTS `V50DPFZC2E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V50DPFZC2E` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V50DPFZC2E`
--

LOCK TABLES `V50DPFZC2E` WRITE;
/*!40000 ALTER TABLE `V50DPFZC2E` DISABLE KEYS */;
/*!40000 ALTER TABLE `V50DPFZC2E` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V5DK7TYNL0`
--

DROP TABLE IF EXISTS `V5DK7TYNL0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V5DK7TYNL0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V5DK7TYNL0`
--

LOCK TABLES `V5DK7TYNL0` WRITE;
/*!40000 ALTER TABLE `V5DK7TYNL0` DISABLE KEYS */;
/*!40000 ALTER TABLE `V5DK7TYNL0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V8V5WQZYB4`
--

DROP TABLE IF EXISTS `V8V5WQZYB4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V8V5WQZYB4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V8V5WQZYB4`
--

LOCK TABLES `V8V5WQZYB4` WRITE;
/*!40000 ALTER TABLE `V8V5WQZYB4` DISABLE KEYS */;
/*!40000 ALTER TABLE `V8V5WQZYB4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `V9IF0U31IG`
--

DROP TABLE IF EXISTS `V9IF0U31IG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `V9IF0U31IG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `V9IF0U31IG`
--

LOCK TABLES `V9IF0U31IG` WRITE;
/*!40000 ALTER TABLE `V9IF0U31IG` DISABLE KEYS */;
/*!40000 ALTER TABLE `V9IF0U31IG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAE7W7IUDK`
--

DROP TABLE IF EXISTS `VAE7W7IUDK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAE7W7IUDK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAE7W7IUDK`
--

LOCK TABLES `VAE7W7IUDK` WRITE;
/*!40000 ALTER TABLE `VAE7W7IUDK` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAE7W7IUDK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VE0Z5NC0RG`
--

DROP TABLE IF EXISTS `VE0Z5NC0RG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VE0Z5NC0RG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VE0Z5NC0RG`
--

LOCK TABLES `VE0Z5NC0RG` WRITE;
/*!40000 ALTER TABLE `VE0Z5NC0RG` DISABLE KEYS */;
/*!40000 ALTER TABLE `VE0Z5NC0RG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VEI9L7QZBX`
--

DROP TABLE IF EXISTS `VEI9L7QZBX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VEI9L7QZBX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VEI9L7QZBX`
--

LOCK TABLES `VEI9L7QZBX` WRITE;
/*!40000 ALTER TABLE `VEI9L7QZBX` DISABLE KEYS */;
/*!40000 ALTER TABLE `VEI9L7QZBX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VEZJWEOQRL`
--

DROP TABLE IF EXISTS `VEZJWEOQRL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VEZJWEOQRL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VEZJWEOQRL`
--

LOCK TABLES `VEZJWEOQRL` WRITE;
/*!40000 ALTER TABLE `VEZJWEOQRL` DISABLE KEYS */;
/*!40000 ALTER TABLE `VEZJWEOQRL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VHBO6THFG2`
--

DROP TABLE IF EXISTS `VHBO6THFG2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VHBO6THFG2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VHBO6THFG2`
--

LOCK TABLES `VHBO6THFG2` WRITE;
/*!40000 ALTER TABLE `VHBO6THFG2` DISABLE KEYS */;
/*!40000 ALTER TABLE `VHBO6THFG2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VJ16Z9XX7R`
--

DROP TABLE IF EXISTS `VJ16Z9XX7R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VJ16Z9XX7R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VJ16Z9XX7R`
--

LOCK TABLES `VJ16Z9XX7R` WRITE;
/*!40000 ALTER TABLE `VJ16Z9XX7R` DISABLE KEYS */;
/*!40000 ALTER TABLE `VJ16Z9XX7R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VK9333V3CP`
--

DROP TABLE IF EXISTS `VK9333V3CP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VK9333V3CP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VK9333V3CP`
--

LOCK TABLES `VK9333V3CP` WRITE;
/*!40000 ALTER TABLE `VK9333V3CP` DISABLE KEYS */;
/*!40000 ALTER TABLE `VK9333V3CP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VKHQ0B57J0`
--

DROP TABLE IF EXISTS `VKHQ0B57J0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VKHQ0B57J0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VKHQ0B57J0`
--

LOCK TABLES `VKHQ0B57J0` WRITE;
/*!40000 ALTER TABLE `VKHQ0B57J0` DISABLE KEYS */;
/*!40000 ALTER TABLE `VKHQ0B57J0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VLE2QDJG15`
--

DROP TABLE IF EXISTS `VLE2QDJG15`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VLE2QDJG15` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VLE2QDJG15`
--

LOCK TABLES `VLE2QDJG15` WRITE;
/*!40000 ALTER TABLE `VLE2QDJG15` DISABLE KEYS */;
/*!40000 ALTER TABLE `VLE2QDJG15` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VOJS8NUD9K`
--

DROP TABLE IF EXISTS `VOJS8NUD9K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VOJS8NUD9K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VOJS8NUD9K`
--

LOCK TABLES `VOJS8NUD9K` WRITE;
/*!40000 ALTER TABLE `VOJS8NUD9K` DISABLE KEYS */;
/*!40000 ALTER TABLE `VOJS8NUD9K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VR8GEI2M2B`
--

DROP TABLE IF EXISTS `VR8GEI2M2B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VR8GEI2M2B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VR8GEI2M2B`
--

LOCK TABLES `VR8GEI2M2B` WRITE;
/*!40000 ALTER TABLE `VR8GEI2M2B` DISABLE KEYS */;
/*!40000 ALTER TABLE `VR8GEI2M2B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VRYZPJ0SMF`
--

DROP TABLE IF EXISTS `VRYZPJ0SMF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VRYZPJ0SMF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VRYZPJ0SMF`
--

LOCK TABLES `VRYZPJ0SMF` WRITE;
/*!40000 ALTER TABLE `VRYZPJ0SMF` DISABLE KEYS */;
/*!40000 ALTER TABLE `VRYZPJ0SMF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VS7DGLSQZQ`
--

DROP TABLE IF EXISTS `VS7DGLSQZQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VS7DGLSQZQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VS7DGLSQZQ`
--

LOCK TABLES `VS7DGLSQZQ` WRITE;
/*!40000 ALTER TABLE `VS7DGLSQZQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `VS7DGLSQZQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VSZSV1QLY5`
--

DROP TABLE IF EXISTS `VSZSV1QLY5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VSZSV1QLY5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VSZSV1QLY5`
--

LOCK TABLES `VSZSV1QLY5` WRITE;
/*!40000 ALTER TABLE `VSZSV1QLY5` DISABLE KEYS */;
/*!40000 ALTER TABLE `VSZSV1QLY5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VWUUXSQ1CR`
--

DROP TABLE IF EXISTS `VWUUXSQ1CR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VWUUXSQ1CR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VWUUXSQ1CR`
--

LOCK TABLES `VWUUXSQ1CR` WRITE;
/*!40000 ALTER TABLE `VWUUXSQ1CR` DISABLE KEYS */;
/*!40000 ALTER TABLE `VWUUXSQ1CR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W22FAVKRDJ`
--

DROP TABLE IF EXISTS `W22FAVKRDJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W22FAVKRDJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W22FAVKRDJ`
--

LOCK TABLES `W22FAVKRDJ` WRITE;
/*!40000 ALTER TABLE `W22FAVKRDJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `W22FAVKRDJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W2JCJ4RAKC`
--

DROP TABLE IF EXISTS `W2JCJ4RAKC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W2JCJ4RAKC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W2JCJ4RAKC`
--

LOCK TABLES `W2JCJ4RAKC` WRITE;
/*!40000 ALTER TABLE `W2JCJ4RAKC` DISABLE KEYS */;
/*!40000 ALTER TABLE `W2JCJ4RAKC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W35I9ST7JO`
--

DROP TABLE IF EXISTS `W35I9ST7JO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W35I9ST7JO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W35I9ST7JO`
--

LOCK TABLES `W35I9ST7JO` WRITE;
/*!40000 ALTER TABLE `W35I9ST7JO` DISABLE KEYS */;
/*!40000 ALTER TABLE `W35I9ST7JO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W5JBMPBLVV`
--

DROP TABLE IF EXISTS `W5JBMPBLVV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W5JBMPBLVV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W5JBMPBLVV`
--

LOCK TABLES `W5JBMPBLVV` WRITE;
/*!40000 ALTER TABLE `W5JBMPBLVV` DISABLE KEYS */;
/*!40000 ALTER TABLE `W5JBMPBLVV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W5JVBY8RP0`
--

DROP TABLE IF EXISTS `W5JVBY8RP0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W5JVBY8RP0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W5JVBY8RP0`
--

LOCK TABLES `W5JVBY8RP0` WRITE;
/*!40000 ALTER TABLE `W5JVBY8RP0` DISABLE KEYS */;
/*!40000 ALTER TABLE `W5JVBY8RP0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W62FUAKWEC`
--

DROP TABLE IF EXISTS `W62FUAKWEC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W62FUAKWEC` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W62FUAKWEC`
--

LOCK TABLES `W62FUAKWEC` WRITE;
/*!40000 ALTER TABLE `W62FUAKWEC` DISABLE KEYS */;
/*!40000 ALTER TABLE `W62FUAKWEC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W6GB41UUS4`
--

DROP TABLE IF EXISTS `W6GB41UUS4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W6GB41UUS4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W6GB41UUS4`
--

LOCK TABLES `W6GB41UUS4` WRITE;
/*!40000 ALTER TABLE `W6GB41UUS4` DISABLE KEYS */;
/*!40000 ALTER TABLE `W6GB41UUS4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W7H9Q3VHBI`
--

DROP TABLE IF EXISTS `W7H9Q3VHBI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W7H9Q3VHBI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W7H9Q3VHBI`
--

LOCK TABLES `W7H9Q3VHBI` WRITE;
/*!40000 ALTER TABLE `W7H9Q3VHBI` DISABLE KEYS */;
/*!40000 ALTER TABLE `W7H9Q3VHBI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W7NUOWZARP`
--

DROP TABLE IF EXISTS `W7NUOWZARP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W7NUOWZARP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W7NUOWZARP`
--

LOCK TABLES `W7NUOWZARP` WRITE;
/*!40000 ALTER TABLE `W7NUOWZARP` DISABLE KEYS */;
/*!40000 ALTER TABLE `W7NUOWZARP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W95I8WCU5H`
--

DROP TABLE IF EXISTS `W95I8WCU5H`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W95I8WCU5H` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W95I8WCU5H`
--

LOCK TABLES `W95I8WCU5H` WRITE;
/*!40000 ALTER TABLE `W95I8WCU5H` DISABLE KEYS */;
/*!40000 ALTER TABLE `W95I8WCU5H` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `W9X2WVELHL`
--

DROP TABLE IF EXISTS `W9X2WVELHL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `W9X2WVELHL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `W9X2WVELHL`
--

LOCK TABLES `W9X2WVELHL` WRITE;
/*!40000 ALTER TABLE `W9X2WVELHL` DISABLE KEYS */;
/*!40000 ALTER TABLE `W9X2WVELHL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WAJGN1ZSGB`
--

DROP TABLE IF EXISTS `WAJGN1ZSGB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WAJGN1ZSGB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WAJGN1ZSGB`
--

LOCK TABLES `WAJGN1ZSGB` WRITE;
/*!40000 ALTER TABLE `WAJGN1ZSGB` DISABLE KEYS */;
/*!40000 ALTER TABLE `WAJGN1ZSGB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WBVV3KE62G`
--

DROP TABLE IF EXISTS `WBVV3KE62G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WBVV3KE62G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WBVV3KE62G`
--

LOCK TABLES `WBVV3KE62G` WRITE;
/*!40000 ALTER TABLE `WBVV3KE62G` DISABLE KEYS */;
/*!40000 ALTER TABLE `WBVV3KE62G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WCNCTZFR9F`
--

DROP TABLE IF EXISTS `WCNCTZFR9F`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WCNCTZFR9F` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WCNCTZFR9F`
--

LOCK TABLES `WCNCTZFR9F` WRITE;
/*!40000 ALTER TABLE `WCNCTZFR9F` DISABLE KEYS */;
/*!40000 ALTER TABLE `WCNCTZFR9F` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WD3LW3FXNE`
--

DROP TABLE IF EXISTS `WD3LW3FXNE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WD3LW3FXNE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WD3LW3FXNE`
--

LOCK TABLES `WD3LW3FXNE` WRITE;
/*!40000 ALTER TABLE `WD3LW3FXNE` DISABLE KEYS */;
/*!40000 ALTER TABLE `WD3LW3FXNE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WDSX2VK015`
--

DROP TABLE IF EXISTS `WDSX2VK015`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WDSX2VK015` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WDSX2VK015`
--

LOCK TABLES `WDSX2VK015` WRITE;
/*!40000 ALTER TABLE `WDSX2VK015` DISABLE KEYS */;
/*!40000 ALTER TABLE `WDSX2VK015` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WFPRWEXZXA`
--

DROP TABLE IF EXISTS `WFPRWEXZXA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WFPRWEXZXA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WFPRWEXZXA`
--

LOCK TABLES `WFPRWEXZXA` WRITE;
/*!40000 ALTER TABLE `WFPRWEXZXA` DISABLE KEYS */;
/*!40000 ALTER TABLE `WFPRWEXZXA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WH72BGW1N7`
--

DROP TABLE IF EXISTS `WH72BGW1N7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WH72BGW1N7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WH72BGW1N7`
--

LOCK TABLES `WH72BGW1N7` WRITE;
/*!40000 ALTER TABLE `WH72BGW1N7` DISABLE KEYS */;
/*!40000 ALTER TABLE `WH72BGW1N7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WI97H6UWNN`
--

DROP TABLE IF EXISTS `WI97H6UWNN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WI97H6UWNN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WI97H6UWNN`
--

LOCK TABLES `WI97H6UWNN` WRITE;
/*!40000 ALTER TABLE `WI97H6UWNN` DISABLE KEYS */;
/*!40000 ALTER TABLE `WI97H6UWNN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WK00BYF2ON`
--

DROP TABLE IF EXISTS `WK00BYF2ON`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WK00BYF2ON` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WK00BYF2ON`
--

LOCK TABLES `WK00BYF2ON` WRITE;
/*!40000 ALTER TABLE `WK00BYF2ON` DISABLE KEYS */;
/*!40000 ALTER TABLE `WK00BYF2ON` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WKXFT67VVK`
--

DROP TABLE IF EXISTS `WKXFT67VVK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKXFT67VVK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WKXFT67VVK`
--

LOCK TABLES `WKXFT67VVK` WRITE;
/*!40000 ALTER TABLE `WKXFT67VVK` DISABLE KEYS */;
/*!40000 ALTER TABLE `WKXFT67VVK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WLRB35E4AM`
--

DROP TABLE IF EXISTS `WLRB35E4AM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WLRB35E4AM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WLRB35E4AM`
--

LOCK TABLES `WLRB35E4AM` WRITE;
/*!40000 ALTER TABLE `WLRB35E4AM` DISABLE KEYS */;
/*!40000 ALTER TABLE `WLRB35E4AM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WMYCBG57NQ`
--

DROP TABLE IF EXISTS `WMYCBG57NQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WMYCBG57NQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WMYCBG57NQ`
--

LOCK TABLES `WMYCBG57NQ` WRITE;
/*!40000 ALTER TABLE `WMYCBG57NQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `WMYCBG57NQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WNRPGG9IX7`
--

DROP TABLE IF EXISTS `WNRPGG9IX7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WNRPGG9IX7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WNRPGG9IX7`
--

LOCK TABLES `WNRPGG9IX7` WRITE;
/*!40000 ALTER TABLE `WNRPGG9IX7` DISABLE KEYS */;
/*!40000 ALTER TABLE `WNRPGG9IX7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WO3HJH54BI`
--

DROP TABLE IF EXISTS `WO3HJH54BI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WO3HJH54BI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WO3HJH54BI`
--

LOCK TABLES `WO3HJH54BI` WRITE;
/*!40000 ALTER TABLE `WO3HJH54BI` DISABLE KEYS */;
/*!40000 ALTER TABLE `WO3HJH54BI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WO6ADGNOGF`
--

DROP TABLE IF EXISTS `WO6ADGNOGF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WO6ADGNOGF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WO6ADGNOGF`
--

LOCK TABLES `WO6ADGNOGF` WRITE;
/*!40000 ALTER TABLE `WO6ADGNOGF` DISABLE KEYS */;
/*!40000 ALTER TABLE `WO6ADGNOGF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WP6P1JN96D`
--

DROP TABLE IF EXISTS `WP6P1JN96D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WP6P1JN96D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WP6P1JN96D`
--

LOCK TABLES `WP6P1JN96D` WRITE;
/*!40000 ALTER TABLE `WP6P1JN96D` DISABLE KEYS */;
/*!40000 ALTER TABLE `WP6P1JN96D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WRFOH3O0IG`
--

DROP TABLE IF EXISTS `WRFOH3O0IG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WRFOH3O0IG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WRFOH3O0IG`
--

LOCK TABLES `WRFOH3O0IG` WRITE;
/*!40000 ALTER TABLE `WRFOH3O0IG` DISABLE KEYS */;
/*!40000 ALTER TABLE `WRFOH3O0IG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WSGHP0PYVZ`
--

DROP TABLE IF EXISTS `WSGHP0PYVZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WSGHP0PYVZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WSGHP0PYVZ`
--

LOCK TABLES `WSGHP0PYVZ` WRITE;
/*!40000 ALTER TABLE `WSGHP0PYVZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `WSGHP0PYVZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WTIRTZ3Y40`
--

DROP TABLE IF EXISTS `WTIRTZ3Y40`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WTIRTZ3Y40` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WTIRTZ3Y40`
--

LOCK TABLES `WTIRTZ3Y40` WRITE;
/*!40000 ALTER TABLE `WTIRTZ3Y40` DISABLE KEYS */;
/*!40000 ALTER TABLE `WTIRTZ3Y40` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WTKN7QPNOP`
--

DROP TABLE IF EXISTS `WTKN7QPNOP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WTKN7QPNOP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WTKN7QPNOP`
--

LOCK TABLES `WTKN7QPNOP` WRITE;
/*!40000 ALTER TABLE `WTKN7QPNOP` DISABLE KEYS */;
/*!40000 ALTER TABLE `WTKN7QPNOP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WTKRKNW0SD`
--

DROP TABLE IF EXISTS `WTKRKNW0SD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WTKRKNW0SD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WTKRKNW0SD`
--

LOCK TABLES `WTKRKNW0SD` WRITE;
/*!40000 ALTER TABLE `WTKRKNW0SD` DISABLE KEYS */;
/*!40000 ALTER TABLE `WTKRKNW0SD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WUG9TLU6R5`
--

DROP TABLE IF EXISTS `WUG9TLU6R5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WUG9TLU6R5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WUG9TLU6R5`
--

LOCK TABLES `WUG9TLU6R5` WRITE;
/*!40000 ALTER TABLE `WUG9TLU6R5` DISABLE KEYS */;
/*!40000 ALTER TABLE `WUG9TLU6R5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WUQKZ5TJQJ`
--

DROP TABLE IF EXISTS `WUQKZ5TJQJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WUQKZ5TJQJ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WUQKZ5TJQJ`
--

LOCK TABLES `WUQKZ5TJQJ` WRITE;
/*!40000 ALTER TABLE `WUQKZ5TJQJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `WUQKZ5TJQJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WW3VHFE3ER`
--

DROP TABLE IF EXISTS `WW3VHFE3ER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WW3VHFE3ER` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WW3VHFE3ER`
--

LOCK TABLES `WW3VHFE3ER` WRITE;
/*!40000 ALTER TABLE `WW3VHFE3ER` DISABLE KEYS */;
/*!40000 ALTER TABLE `WW3VHFE3ER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WWJZ5HJ4V2`
--

DROP TABLE IF EXISTS `WWJZ5HJ4V2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WWJZ5HJ4V2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WWJZ5HJ4V2`
--

LOCK TABLES `WWJZ5HJ4V2` WRITE;
/*!40000 ALTER TABLE `WWJZ5HJ4V2` DISABLE KEYS */;
/*!40000 ALTER TABLE `WWJZ5HJ4V2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WWNH4N4CR4`
--

DROP TABLE IF EXISTS `WWNH4N4CR4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WWNH4N4CR4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WWNH4N4CR4`
--

LOCK TABLES `WWNH4N4CR4` WRITE;
/*!40000 ALTER TABLE `WWNH4N4CR4` DISABLE KEYS */;
/*!40000 ALTER TABLE `WWNH4N4CR4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WWWJ19NZZL`
--

DROP TABLE IF EXISTS `WWWJ19NZZL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WWWJ19NZZL` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WWWJ19NZZL`
--

LOCK TABLES `WWWJ19NZZL` WRITE;
/*!40000 ALTER TABLE `WWWJ19NZZL` DISABLE KEYS */;
/*!40000 ALTER TABLE `WWWJ19NZZL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WX1RLYA5WR`
--

DROP TABLE IF EXISTS `WX1RLYA5WR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WX1RLYA5WR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WX1RLYA5WR`
--

LOCK TABLES `WX1RLYA5WR` WRITE;
/*!40000 ALTER TABLE `WX1RLYA5WR` DISABLE KEYS */;
/*!40000 ALTER TABLE `WX1RLYA5WR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WYFV9K3UQU`
--

DROP TABLE IF EXISTS `WYFV9K3UQU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WYFV9K3UQU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WYFV9K3UQU`
--

LOCK TABLES `WYFV9K3UQU` WRITE;
/*!40000 ALTER TABLE `WYFV9K3UQU` DISABLE KEYS */;
/*!40000 ALTER TABLE `WYFV9K3UQU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WZFR8JMYC2`
--

DROP TABLE IF EXISTS `WZFR8JMYC2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WZFR8JMYC2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WZFR8JMYC2`
--

LOCK TABLES `WZFR8JMYC2` WRITE;
/*!40000 ALTER TABLE `WZFR8JMYC2` DISABLE KEYS */;
/*!40000 ALTER TABLE `WZFR8JMYC2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WZX0A0UD4K`
--

DROP TABLE IF EXISTS `WZX0A0UD4K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WZX0A0UD4K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WZX0A0UD4K`
--

LOCK TABLES `WZX0A0UD4K` WRITE;
/*!40000 ALTER TABLE `WZX0A0UD4K` DISABLE KEYS */;
/*!40000 ALTER TABLE `WZX0A0UD4K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X03I69G3N3`
--

DROP TABLE IF EXISTS `X03I69G3N3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X03I69G3N3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X03I69G3N3`
--

LOCK TABLES `X03I69G3N3` WRITE;
/*!40000 ALTER TABLE `X03I69G3N3` DISABLE KEYS */;
/*!40000 ALTER TABLE `X03I69G3N3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X04Y5S65ON`
--

DROP TABLE IF EXISTS `X04Y5S65ON`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X04Y5S65ON` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X04Y5S65ON`
--

LOCK TABLES `X04Y5S65ON` WRITE;
/*!40000 ALTER TABLE `X04Y5S65ON` DISABLE KEYS */;
/*!40000 ALTER TABLE `X04Y5S65ON` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X0KO3ZXGNR`
--

DROP TABLE IF EXISTS `X0KO3ZXGNR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X0KO3ZXGNR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X0KO3ZXGNR`
--

LOCK TABLES `X0KO3ZXGNR` WRITE;
/*!40000 ALTER TABLE `X0KO3ZXGNR` DISABLE KEYS */;
/*!40000 ALTER TABLE `X0KO3ZXGNR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X2Z349UY9G`
--

DROP TABLE IF EXISTS `X2Z349UY9G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X2Z349UY9G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X2Z349UY9G`
--

LOCK TABLES `X2Z349UY9G` WRITE;
/*!40000 ALTER TABLE `X2Z349UY9G` DISABLE KEYS */;
/*!40000 ALTER TABLE `X2Z349UY9G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X32RUKT8JW`
--

DROP TABLE IF EXISTS `X32RUKT8JW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X32RUKT8JW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X32RUKT8JW`
--

LOCK TABLES `X32RUKT8JW` WRITE;
/*!40000 ALTER TABLE `X32RUKT8JW` DISABLE KEYS */;
/*!40000 ALTER TABLE `X32RUKT8JW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X3OYF7YCCE`
--

DROP TABLE IF EXISTS `X3OYF7YCCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X3OYF7YCCE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X3OYF7YCCE`
--

LOCK TABLES `X3OYF7YCCE` WRITE;
/*!40000 ALTER TABLE `X3OYF7YCCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `X3OYF7YCCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X49ELKWFLF`
--

DROP TABLE IF EXISTS `X49ELKWFLF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X49ELKWFLF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X49ELKWFLF`
--

LOCK TABLES `X49ELKWFLF` WRITE;
/*!40000 ALTER TABLE `X49ELKWFLF` DISABLE KEYS */;
/*!40000 ALTER TABLE `X49ELKWFLF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `X6KK85XU5H`
--

DROP TABLE IF EXISTS `X6KK85XU5H`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `X6KK85XU5H` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `X6KK85XU5H`
--

LOCK TABLES `X6KK85XU5H` WRITE;
/*!40000 ALTER TABLE `X6KK85XU5H` DISABLE KEYS */;
/*!40000 ALTER TABLE `X6KK85XU5H` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XB07FOTIDW`
--

DROP TABLE IF EXISTS `XB07FOTIDW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XB07FOTIDW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XB07FOTIDW`
--

LOCK TABLES `XB07FOTIDW` WRITE;
/*!40000 ALTER TABLE `XB07FOTIDW` DISABLE KEYS */;
/*!40000 ALTER TABLE `XB07FOTIDW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XBMQTEK95B`
--

DROP TABLE IF EXISTS `XBMQTEK95B`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XBMQTEK95B` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XBMQTEK95B`
--

LOCK TABLES `XBMQTEK95B` WRITE;
/*!40000 ALTER TABLE `XBMQTEK95B` DISABLE KEYS */;
/*!40000 ALTER TABLE `XBMQTEK95B` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XDY03BT53P`
--

DROP TABLE IF EXISTS `XDY03BT53P`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XDY03BT53P` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XDY03BT53P`
--

LOCK TABLES `XDY03BT53P` WRITE;
/*!40000 ALTER TABLE `XDY03BT53P` DISABLE KEYS */;
/*!40000 ALTER TABLE `XDY03BT53P` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XH8ZNFEKZF`
--

DROP TABLE IF EXISTS `XH8ZNFEKZF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XH8ZNFEKZF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XH8ZNFEKZF`
--

LOCK TABLES `XH8ZNFEKZF` WRITE;
/*!40000 ALTER TABLE `XH8ZNFEKZF` DISABLE KEYS */;
/*!40000 ALTER TABLE `XH8ZNFEKZF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XJHYA064CW`
--

DROP TABLE IF EXISTS `XJHYA064CW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XJHYA064CW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XJHYA064CW`
--

LOCK TABLES `XJHYA064CW` WRITE;
/*!40000 ALTER TABLE `XJHYA064CW` DISABLE KEYS */;
/*!40000 ALTER TABLE `XJHYA064CW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XK5CM002AR`
--

DROP TABLE IF EXISTS `XK5CM002AR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XK5CM002AR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XK5CM002AR`
--

LOCK TABLES `XK5CM002AR` WRITE;
/*!40000 ALTER TABLE `XK5CM002AR` DISABLE KEYS */;
/*!40000 ALTER TABLE `XK5CM002AR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XL39CXUP3Q`
--

DROP TABLE IF EXISTS `XL39CXUP3Q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XL39CXUP3Q` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XL39CXUP3Q`
--

LOCK TABLES `XL39CXUP3Q` WRITE;
/*!40000 ALTER TABLE `XL39CXUP3Q` DISABLE KEYS */;
/*!40000 ALTER TABLE `XL39CXUP3Q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XL5P0NGYLH`
--

DROP TABLE IF EXISTS `XL5P0NGYLH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XL5P0NGYLH` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XL5P0NGYLH`
--

LOCK TABLES `XL5P0NGYLH` WRITE;
/*!40000 ALTER TABLE `XL5P0NGYLH` DISABLE KEYS */;
/*!40000 ALTER TABLE `XL5P0NGYLH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XNT86O3PFS`
--

DROP TABLE IF EXISTS `XNT86O3PFS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XNT86O3PFS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XNT86O3PFS`
--

LOCK TABLES `XNT86O3PFS` WRITE;
/*!40000 ALTER TABLE `XNT86O3PFS` DISABLE KEYS */;
/*!40000 ALTER TABLE `XNT86O3PFS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XPG0TK4PZZ`
--

DROP TABLE IF EXISTS `XPG0TK4PZZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XPG0TK4PZZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XPG0TK4PZZ`
--

LOCK TABLES `XPG0TK4PZZ` WRITE;
/*!40000 ALTER TABLE `XPG0TK4PZZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `XPG0TK4PZZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XQ9W8FVK4R`
--

DROP TABLE IF EXISTS `XQ9W8FVK4R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XQ9W8FVK4R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XQ9W8FVK4R`
--

LOCK TABLES `XQ9W8FVK4R` WRITE;
/*!40000 ALTER TABLE `XQ9W8FVK4R` DISABLE KEYS */;
/*!40000 ALTER TABLE `XQ9W8FVK4R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XQU7ZRV4NE`
--

DROP TABLE IF EXISTS `XQU7ZRV4NE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XQU7ZRV4NE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XQU7ZRV4NE`
--

LOCK TABLES `XQU7ZRV4NE` WRITE;
/*!40000 ALTER TABLE `XQU7ZRV4NE` DISABLE KEYS */;
/*!40000 ALTER TABLE `XQU7ZRV4NE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XUN97LZS8A`
--

DROP TABLE IF EXISTS `XUN97LZS8A`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XUN97LZS8A` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XUN97LZS8A`
--

LOCK TABLES `XUN97LZS8A` WRITE;
/*!40000 ALTER TABLE `XUN97LZS8A` DISABLE KEYS */;
/*!40000 ALTER TABLE `XUN97LZS8A` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XVBXH960F0`
--

DROP TABLE IF EXISTS `XVBXH960F0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XVBXH960F0` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XVBXH960F0`
--

LOCK TABLES `XVBXH960F0` WRITE;
/*!40000 ALTER TABLE `XVBXH960F0` DISABLE KEYS */;
/*!40000 ALTER TABLE `XVBXH960F0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XW06DJ10JO`
--

DROP TABLE IF EXISTS `XW06DJ10JO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XW06DJ10JO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XW06DJ10JO`
--

LOCK TABLES `XW06DJ10JO` WRITE;
/*!40000 ALTER TABLE `XW06DJ10JO` DISABLE KEYS */;
/*!40000 ALTER TABLE `XW06DJ10JO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XW2S0F4QH8`
--

DROP TABLE IF EXISTS `XW2S0F4QH8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XW2S0F4QH8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XW2S0F4QH8`
--

LOCK TABLES `XW2S0F4QH8` WRITE;
/*!40000 ALTER TABLE `XW2S0F4QH8` DISABLE KEYS */;
/*!40000 ALTER TABLE `XW2S0F4QH8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XWWPJQ75SG`
--

DROP TABLE IF EXISTS `XWWPJQ75SG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XWWPJQ75SG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XWWPJQ75SG`
--

LOCK TABLES `XWWPJQ75SG` WRITE;
/*!40000 ALTER TABLE `XWWPJQ75SG` DISABLE KEYS */;
/*!40000 ALTER TABLE `XWWPJQ75SG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XZZL0DUE7U`
--

DROP TABLE IF EXISTS `XZZL0DUE7U`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `XZZL0DUE7U` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XZZL0DUE7U`
--

LOCK TABLES `XZZL0DUE7U` WRITE;
/*!40000 ALTER TABLE `XZZL0DUE7U` DISABLE KEYS */;
/*!40000 ALTER TABLE `XZZL0DUE7U` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y1AJ73ZMVV`
--

DROP TABLE IF EXISTS `Y1AJ73ZMVV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y1AJ73ZMVV` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y1AJ73ZMVV`
--

LOCK TABLES `Y1AJ73ZMVV` WRITE;
/*!40000 ALTER TABLE `Y1AJ73ZMVV` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y1AJ73ZMVV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y1B3KWY2A5`
--

DROP TABLE IF EXISTS `Y1B3KWY2A5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y1B3KWY2A5` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y1B3KWY2A5`
--

LOCK TABLES `Y1B3KWY2A5` WRITE;
/*!40000 ALTER TABLE `Y1B3KWY2A5` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y1B3KWY2A5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y30CXWNGLT`
--

DROP TABLE IF EXISTS `Y30CXWNGLT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y30CXWNGLT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y30CXWNGLT`
--

LOCK TABLES `Y30CXWNGLT` WRITE;
/*!40000 ALTER TABLE `Y30CXWNGLT` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y30CXWNGLT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y3JE72DLZN`
--

DROP TABLE IF EXISTS `Y3JE72DLZN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y3JE72DLZN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y3JE72DLZN`
--

LOCK TABLES `Y3JE72DLZN` WRITE;
/*!40000 ALTER TABLE `Y3JE72DLZN` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y3JE72DLZN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y606LLR305`
--

DROP TABLE IF EXISTS `Y606LLR305`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y606LLR305` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y606LLR305`
--

LOCK TABLES `Y606LLR305` WRITE;
/*!40000 ALTER TABLE `Y606LLR305` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y606LLR305` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y67MFEIDYM`
--

DROP TABLE IF EXISTS `Y67MFEIDYM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y67MFEIDYM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y67MFEIDYM`
--

LOCK TABLES `Y67MFEIDYM` WRITE;
/*!40000 ALTER TABLE `Y67MFEIDYM` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y67MFEIDYM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y6JRQK11DE`
--

DROP TABLE IF EXISTS `Y6JRQK11DE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y6JRQK11DE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y6JRQK11DE`
--

LOCK TABLES `Y6JRQK11DE` WRITE;
/*!40000 ALTER TABLE `Y6JRQK11DE` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y6JRQK11DE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y84H3ORHR8`
--

DROP TABLE IF EXISTS `Y84H3ORHR8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y84H3ORHR8` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y84H3ORHR8`
--

LOCK TABLES `Y84H3ORHR8` WRITE;
/*!40000 ALTER TABLE `Y84H3ORHR8` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y84H3ORHR8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Y9X435NPW7`
--

DROP TABLE IF EXISTS `Y9X435NPW7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Y9X435NPW7` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Y9X435NPW7`
--

LOCK TABLES `Y9X435NPW7` WRITE;
/*!40000 ALTER TABLE `Y9X435NPW7` DISABLE KEYS */;
/*!40000 ALTER TABLE `Y9X435NPW7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YAR5762XCM`
--

DROP TABLE IF EXISTS `YAR5762XCM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YAR5762XCM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YAR5762XCM`
--

LOCK TABLES `YAR5762XCM` WRITE;
/*!40000 ALTER TABLE `YAR5762XCM` DISABLE KEYS */;
/*!40000 ALTER TABLE `YAR5762XCM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YAWRQ1RKPI`
--

DROP TABLE IF EXISTS `YAWRQ1RKPI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YAWRQ1RKPI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YAWRQ1RKPI`
--

LOCK TABLES `YAWRQ1RKPI` WRITE;
/*!40000 ALTER TABLE `YAWRQ1RKPI` DISABLE KEYS */;
/*!40000 ALTER TABLE `YAWRQ1RKPI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YBQVKTXMNM`
--

DROP TABLE IF EXISTS `YBQVKTXMNM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YBQVKTXMNM` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YBQVKTXMNM`
--

LOCK TABLES `YBQVKTXMNM` WRITE;
/*!40000 ALTER TABLE `YBQVKTXMNM` DISABLE KEYS */;
/*!40000 ALTER TABLE `YBQVKTXMNM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YC28Q6ZFCY`
--

DROP TABLE IF EXISTS `YC28Q6ZFCY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YC28Q6ZFCY` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YC28Q6ZFCY`
--

LOCK TABLES `YC28Q6ZFCY` WRITE;
/*!40000 ALTER TABLE `YC28Q6ZFCY` DISABLE KEYS */;
/*!40000 ALTER TABLE `YC28Q6ZFCY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YECM5UONXD`
--

DROP TABLE IF EXISTS `YECM5UONXD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YECM5UONXD` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YECM5UONXD`
--

LOCK TABLES `YECM5UONXD` WRITE;
/*!40000 ALTER TABLE `YECM5UONXD` DISABLE KEYS */;
/*!40000 ALTER TABLE `YECM5UONXD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YG051GUHYG`
--

DROP TABLE IF EXISTS `YG051GUHYG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YG051GUHYG` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YG051GUHYG`
--

LOCK TABLES `YG051GUHYG` WRITE;
/*!40000 ALTER TABLE `YG051GUHYG` DISABLE KEYS */;
/*!40000 ALTER TABLE `YG051GUHYG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YG843IKDYR`
--

DROP TABLE IF EXISTS `YG843IKDYR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YG843IKDYR` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YG843IKDYR`
--

LOCK TABLES `YG843IKDYR` WRITE;
/*!40000 ALTER TABLE `YG843IKDYR` DISABLE KEYS */;
/*!40000 ALTER TABLE `YG843IKDYR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YHAOOHRIG9`
--

DROP TABLE IF EXISTS `YHAOOHRIG9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YHAOOHRIG9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YHAOOHRIG9`
--

LOCK TABLES `YHAOOHRIG9` WRITE;
/*!40000 ALTER TABLE `YHAOOHRIG9` DISABLE KEYS */;
/*!40000 ALTER TABLE `YHAOOHRIG9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YHIJGX8P9D`
--

DROP TABLE IF EXISTS `YHIJGX8P9D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YHIJGX8P9D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YHIJGX8P9D`
--

LOCK TABLES `YHIJGX8P9D` WRITE;
/*!40000 ALTER TABLE `YHIJGX8P9D` DISABLE KEYS */;
/*!40000 ALTER TABLE `YHIJGX8P9D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YIHSK9EUE6`
--

DROP TABLE IF EXISTS `YIHSK9EUE6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YIHSK9EUE6` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YIHSK9EUE6`
--

LOCK TABLES `YIHSK9EUE6` WRITE;
/*!40000 ALTER TABLE `YIHSK9EUE6` DISABLE KEYS */;
/*!40000 ALTER TABLE `YIHSK9EUE6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YJQNXTVD6I`
--

DROP TABLE IF EXISTS `YJQNXTVD6I`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YJQNXTVD6I` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YJQNXTVD6I`
--

LOCK TABLES `YJQNXTVD6I` WRITE;
/*!40000 ALTER TABLE `YJQNXTVD6I` DISABLE KEYS */;
/*!40000 ALTER TABLE `YJQNXTVD6I` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YK58PQVJEP`
--

DROP TABLE IF EXISTS `YK58PQVJEP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YK58PQVJEP` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YK58PQVJEP`
--

LOCK TABLES `YK58PQVJEP` WRITE;
/*!40000 ALTER TABLE `YK58PQVJEP` DISABLE KEYS */;
/*!40000 ALTER TABLE `YK58PQVJEP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YLEEI4NWCB`
--

DROP TABLE IF EXISTS `YLEEI4NWCB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YLEEI4NWCB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YLEEI4NWCB`
--

LOCK TABLES `YLEEI4NWCB` WRITE;
/*!40000 ALTER TABLE `YLEEI4NWCB` DISABLE KEYS */;
/*!40000 ALTER TABLE `YLEEI4NWCB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YLPJJI67EN`
--

DROP TABLE IF EXISTS `YLPJJI67EN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YLPJJI67EN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YLPJJI67EN`
--

LOCK TABLES `YLPJJI67EN` WRITE;
/*!40000 ALTER TABLE `YLPJJI67EN` DISABLE KEYS */;
/*!40000 ALTER TABLE `YLPJJI67EN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YNFTPFWNB1`
--

DROP TABLE IF EXISTS `YNFTPFWNB1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YNFTPFWNB1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YNFTPFWNB1`
--

LOCK TABLES `YNFTPFWNB1` WRITE;
/*!40000 ALTER TABLE `YNFTPFWNB1` DISABLE KEYS */;
/*!40000 ALTER TABLE `YNFTPFWNB1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YNRAKF1F28`
--

DROP TABLE IF EXISTS `YNRAKF1F28`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YNRAKF1F28` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YNRAKF1F28`
--

LOCK TABLES `YNRAKF1F28` WRITE;
/*!40000 ALTER TABLE `YNRAKF1F28` DISABLE KEYS */;
/*!40000 ALTER TABLE `YNRAKF1F28` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YO0EASW5LQ`
--

DROP TABLE IF EXISTS `YO0EASW5LQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YO0EASW5LQ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YO0EASW5LQ`
--

LOCK TABLES `YO0EASW5LQ` WRITE;
/*!40000 ALTER TABLE `YO0EASW5LQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `YO0EASW5LQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YO2AQ7T43R`
--

DROP TABLE IF EXISTS `YO2AQ7T43R`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YO2AQ7T43R` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YO2AQ7T43R`
--

LOCK TABLES `YO2AQ7T43R` WRITE;
/*!40000 ALTER TABLE `YO2AQ7T43R` DISABLE KEYS */;
/*!40000 ALTER TABLE `YO2AQ7T43R` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YO4WFJSHXS`
--

DROP TABLE IF EXISTS `YO4WFJSHXS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YO4WFJSHXS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YO4WFJSHXS`
--

LOCK TABLES `YO4WFJSHXS` WRITE;
/*!40000 ALTER TABLE `YO4WFJSHXS` DISABLE KEYS */;
/*!40000 ALTER TABLE `YO4WFJSHXS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YP615P9RKW`
--

DROP TABLE IF EXISTS `YP615P9RKW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YP615P9RKW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YP615P9RKW`
--

LOCK TABLES `YP615P9RKW` WRITE;
/*!40000 ALTER TABLE `YP615P9RKW` DISABLE KEYS */;
/*!40000 ALTER TABLE `YP615P9RKW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YPMLAEF5E9`
--

DROP TABLE IF EXISTS `YPMLAEF5E9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YPMLAEF5E9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YPMLAEF5E9`
--

LOCK TABLES `YPMLAEF5E9` WRITE;
/*!40000 ALTER TABLE `YPMLAEF5E9` DISABLE KEYS */;
/*!40000 ALTER TABLE `YPMLAEF5E9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YPTYSJV3HI`
--

DROP TABLE IF EXISTS `YPTYSJV3HI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YPTYSJV3HI` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YPTYSJV3HI`
--

LOCK TABLES `YPTYSJV3HI` WRITE;
/*!40000 ALTER TABLE `YPTYSJV3HI` DISABLE KEYS */;
/*!40000 ALTER TABLE `YPTYSJV3HI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YQO4477WIO`
--

DROP TABLE IF EXISTS `YQO4477WIO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YQO4477WIO` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YQO4477WIO`
--

LOCK TABLES `YQO4477WIO` WRITE;
/*!40000 ALTER TABLE `YQO4477WIO` DISABLE KEYS */;
/*!40000 ALTER TABLE `YQO4477WIO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YQOAKRYOXW`
--

DROP TABLE IF EXISTS `YQOAKRYOXW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YQOAKRYOXW` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YQOAKRYOXW`
--

LOCK TABLES `YQOAKRYOXW` WRITE;
/*!40000 ALTER TABLE `YQOAKRYOXW` DISABLE KEYS */;
/*!40000 ALTER TABLE `YQOAKRYOXW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YQYJU5JJJX`
--

DROP TABLE IF EXISTS `YQYJU5JJJX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YQYJU5JJJX` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YQYJU5JJJX`
--

LOCK TABLES `YQYJU5JJJX` WRITE;
/*!40000 ALTER TABLE `YQYJU5JJJX` DISABLE KEYS */;
/*!40000 ALTER TABLE `YQYJU5JJJX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YUXLYOSHD3`
--

DROP TABLE IF EXISTS `YUXLYOSHD3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YUXLYOSHD3` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YUXLYOSHD3`
--

LOCK TABLES `YUXLYOSHD3` WRITE;
/*!40000 ALTER TABLE `YUXLYOSHD3` DISABLE KEYS */;
/*!40000 ALTER TABLE `YUXLYOSHD3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YV8R0G5MX9`
--

DROP TABLE IF EXISTS `YV8R0G5MX9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YV8R0G5MX9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YV8R0G5MX9`
--

LOCK TABLES `YV8R0G5MX9` WRITE;
/*!40000 ALTER TABLE `YV8R0G5MX9` DISABLE KEYS */;
/*!40000 ALTER TABLE `YV8R0G5MX9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YVBYMERHL2`
--

DROP TABLE IF EXISTS `YVBYMERHL2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YVBYMERHL2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YVBYMERHL2`
--

LOCK TABLES `YVBYMERHL2` WRITE;
/*!40000 ALTER TABLE `YVBYMERHL2` DISABLE KEYS */;
/*!40000 ALTER TABLE `YVBYMERHL2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `YYPMRMN4GF`
--

DROP TABLE IF EXISTS `YYPMRMN4GF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `YYPMRMN4GF` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `YYPMRMN4GF`
--

LOCK TABLES `YYPMRMN4GF` WRITE;
/*!40000 ALTER TABLE `YYPMRMN4GF` DISABLE KEYS */;
/*!40000 ALTER TABLE `YYPMRMN4GF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z2VKAT6HZU`
--

DROP TABLE IF EXISTS `Z2VKAT6HZU`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z2VKAT6HZU` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z2VKAT6HZU`
--

LOCK TABLES `Z2VKAT6HZU` WRITE;
/*!40000 ALTER TABLE `Z2VKAT6HZU` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z2VKAT6HZU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z2WYC5TFZT`
--

DROP TABLE IF EXISTS `Z2WYC5TFZT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z2WYC5TFZT` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z2WYC5TFZT`
--

LOCK TABLES `Z2WYC5TFZT` WRITE;
/*!40000 ALTER TABLE `Z2WYC5TFZT` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z2WYC5TFZT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z30SZ62ZH2`
--

DROP TABLE IF EXISTS `Z30SZ62ZH2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z30SZ62ZH2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z30SZ62ZH2`
--

LOCK TABLES `Z30SZ62ZH2` WRITE;
/*!40000 ALTER TABLE `Z30SZ62ZH2` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z30SZ62ZH2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z45SWJM31A`
--

DROP TABLE IF EXISTS `Z45SWJM31A`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z45SWJM31A` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z45SWJM31A`
--

LOCK TABLES `Z45SWJM31A` WRITE;
/*!40000 ALTER TABLE `Z45SWJM31A` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z45SWJM31A` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z4ERFUW43Z`
--

DROP TABLE IF EXISTS `Z4ERFUW43Z`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z4ERFUW43Z` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z4ERFUW43Z`
--

LOCK TABLES `Z4ERFUW43Z` WRITE;
/*!40000 ALTER TABLE `Z4ERFUW43Z` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z4ERFUW43Z` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Z6TUDGETRZ`
--

DROP TABLE IF EXISTS `Z6TUDGETRZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Z6TUDGETRZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Z6TUDGETRZ`
--

LOCK TABLES `Z6TUDGETRZ` WRITE;
/*!40000 ALTER TABLE `Z6TUDGETRZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `Z6TUDGETRZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZA0RPA9EIB`
--

DROP TABLE IF EXISTS `ZA0RPA9EIB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZA0RPA9EIB` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZA0RPA9EIB`
--

LOCK TABLES `ZA0RPA9EIB` WRITE;
/*!40000 ALTER TABLE `ZA0RPA9EIB` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZA0RPA9EIB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZAG11M5V23`
--

DROP TABLE IF EXISTS `ZAG11M5V23`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZAG11M5V23` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZAG11M5V23`
--

LOCK TABLES `ZAG11M5V23` WRITE;
/*!40000 ALTER TABLE `ZAG11M5V23` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZAG11M5V23` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZC582KDNHZ`
--

DROP TABLE IF EXISTS `ZC582KDNHZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZC582KDNHZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZC582KDNHZ`
--

LOCK TABLES `ZC582KDNHZ` WRITE;
/*!40000 ALTER TABLE `ZC582KDNHZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZC582KDNHZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZDQ0ZQPSL4`
--

DROP TABLE IF EXISTS `ZDQ0ZQPSL4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZDQ0ZQPSL4` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZDQ0ZQPSL4`
--

LOCK TABLES `ZDQ0ZQPSL4` WRITE;
/*!40000 ALTER TABLE `ZDQ0ZQPSL4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZDQ0ZQPSL4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZDXP1QYE5G`
--

DROP TABLE IF EXISTS `ZDXP1QYE5G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZDXP1QYE5G` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZDXP1QYE5G`
--

LOCK TABLES `ZDXP1QYE5G` WRITE;
/*!40000 ALTER TABLE `ZDXP1QYE5G` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZDXP1QYE5G` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZF9H5KMAHA`
--

DROP TABLE IF EXISTS `ZF9H5KMAHA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZF9H5KMAHA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZF9H5KMAHA`
--

LOCK TABLES `ZF9H5KMAHA` WRITE;
/*!40000 ALTER TABLE `ZF9H5KMAHA` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZF9H5KMAHA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZFOCSKPFE9`
--

DROP TABLE IF EXISTS `ZFOCSKPFE9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZFOCSKPFE9` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZFOCSKPFE9`
--

LOCK TABLES `ZFOCSKPFE9` WRITE;
/*!40000 ALTER TABLE `ZFOCSKPFE9` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZFOCSKPFE9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZNC4VPVW6D`
--

DROP TABLE IF EXISTS `ZNC4VPVW6D`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZNC4VPVW6D` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZNC4VPVW6D`
--

LOCK TABLES `ZNC4VPVW6D` WRITE;
/*!40000 ALTER TABLE `ZNC4VPVW6D` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZNC4VPVW6D` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZON0DGMUMN`
--

DROP TABLE IF EXISTS `ZON0DGMUMN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZON0DGMUMN` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZON0DGMUMN`
--

LOCK TABLES `ZON0DGMUMN` WRITE;
/*!40000 ALTER TABLE `ZON0DGMUMN` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZON0DGMUMN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZOWXBZOR31`
--

DROP TABLE IF EXISTS `ZOWXBZOR31`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZOWXBZOR31` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZOWXBZOR31`
--

LOCK TABLES `ZOWXBZOR31` WRITE;
/*!40000 ALTER TABLE `ZOWXBZOR31` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZOWXBZOR31` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZR8FXY8UUK`
--

DROP TABLE IF EXISTS `ZR8FXY8UUK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZR8FXY8UUK` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZR8FXY8UUK`
--

LOCK TABLES `ZR8FXY8UUK` WRITE;
/*!40000 ALTER TABLE `ZR8FXY8UUK` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZR8FXY8UUK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZRE9A7GX94`
--

DROP TABLE IF EXISTS `ZRE9A7GX94`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZRE9A7GX94` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZRE9A7GX94`
--

LOCK TABLES `ZRE9A7GX94` WRITE;
/*!40000 ALTER TABLE `ZRE9A7GX94` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZRE9A7GX94` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZUAQVOYFTA`
--

DROP TABLE IF EXISTS `ZUAQVOYFTA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZUAQVOYFTA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZUAQVOYFTA`
--

LOCK TABLES `ZUAQVOYFTA` WRITE;
/*!40000 ALTER TABLE `ZUAQVOYFTA` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZUAQVOYFTA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZVO9TYRWFZ`
--

DROP TABLE IF EXISTS `ZVO9TYRWFZ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZVO9TYRWFZ` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZVO9TYRWFZ`
--

LOCK TABLES `ZVO9TYRWFZ` WRITE;
/*!40000 ALTER TABLE `ZVO9TYRWFZ` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZVO9TYRWFZ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZWEZMAW16K`
--

DROP TABLE IF EXISTS `ZWEZMAW16K`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZWEZMAW16K` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZWEZMAW16K`
--

LOCK TABLES `ZWEZMAW16K` WRITE;
/*!40000 ALTER TABLE `ZWEZMAW16K` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZWEZMAW16K` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZWI7MBECPA`
--

DROP TABLE IF EXISTS `ZWI7MBECPA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZWI7MBECPA` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZWI7MBECPA`
--

LOCK TABLES `ZWI7MBECPA` WRITE;
/*!40000 ALTER TABLE `ZWI7MBECPA` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZWI7MBECPA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ZZC3QL1J4M`
--

DROP TABLE IF EXISTS `ZZC3QL1J4M`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZZC3QL1J4M` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ZZC3QL1J4M`
--

LOCK TABLES `ZZC3QL1J4M` WRITE;
/*!40000 ALTER TABLE `ZZC3QL1J4M` DISABLE KEYS */;
/*!40000 ALTER TABLE `ZZC3QL1J4M` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `flag_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `flag_id` (`flag_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`flag_id`) REFERENCES `FL4GH0LD3R` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2776 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,890,549),(2,284,406),(3,344,104),(4,486,834),(5,256,899),(6,161,934),(7,649,204),(8,988,195),(9,153,161),(10,999,990),(11,129,638),(12,310,808),(13,16,957),(14,270,228),(15,483,349),(16,217,220),(17,559,42),(18,59,587),(19,587,896),(20,653,306),(21,415,452),(22,543,40),(23,397,919),(24,85,938),(25,388,746),(26,650,820),(27,172,785),(28,81,436),(29,292,390),(30,753,431),(31,766,400),(32,511,189),(33,643,414),(34,624,897),(35,668,44),(36,717,946),(37,627,565),(38,570,489),(39,738,839),(40,942,518),(41,72,553),(42,408,328),(43,491,74),(44,363,900),(45,930,479),(46,838,104),(47,25,704),(48,477,140),(49,249,490),(50,211,239),(51,794,591),(52,570,165),(53,549,652),(54,170,900),(55,84,994),(56,674,386),(57,646,839),(58,986,391),(59,105,848),(60,181,641),(61,389,471),(62,507,984),(63,220,894),(64,462,629),(65,549,638),(66,160,447),(67,72,471),(68,346,716),(69,250,142),(70,139,229),(71,397,811),(72,865,314),(73,475,227),(74,781,146),(75,637,795),(76,936,487),(77,890,486),(78,505,916),(79,466,347),(80,714,392),(81,690,644),(82,179,160),(83,115,751),(84,933,799),(85,450,79),(86,526,448),(87,554,756),(88,241,861),(89,162,295),(90,980,112),(91,565,63),(92,917,439),(93,674,582),(94,717,567),(95,656,99),(96,128,375),(97,742,31),(98,573,554),(99,370,470),(100,308,835),(101,746,798),(102,638,996),(103,981,185),(104,1,33),(105,549,28),(106,726,135),(107,115,703),(108,982,24),(109,551,587),(110,438,650),(111,218,550),(112,501,843),(113,87,538),(114,803,573),(115,27,769),(116,602,168),(117,830,757),(118,769,3),(119,570,10),(120,754,579),(121,253,193),(122,458,763),(123,710,274),(124,244,153),(125,335,924),(126,302,943),(127,236,610),(128,335,83),(129,7,575),(130,366,188),(131,670,37),(132,877,505),(133,4,626),(134,85,558),(135,344,703),(136,803,614),(137,536,285),(138,766,443),(139,973,855),(140,214,111),(141,445,22),(142,259,368),(143,162,395),(144,985,375),(145,964,163),(146,495,41),(147,156,175),(148,741,552),(149,895,987),(150,486,712),(151,517,963),(152,955,695),(153,875,282),(154,685,49),(155,699,665),(156,126,270),(157,234,687),(158,109,740),(159,821,883),(160,278,942),(161,718,267),(162,996,402),(163,371,482),(164,463,246),(165,751,835),(166,223,389),(167,1000,583),(168,212,827),(169,297,376),(170,132,898),(171,298,681),(172,843,917),(173,594,352),(174,459,372),(175,850,828),(176,734,601),(177,263,538),(178,231,435),(179,502,420),(180,868,564),(181,737,376),(182,943,589),(183,196,526),(184,465,514),(185,731,120),(186,335,248),(187,51,840),(188,528,174),(189,803,339),(190,412,345),(191,67,988),(192,455,846),(193,840,955),(194,181,669),(195,74,873),(196,82,50),(197,275,935),(198,313,435),(199,449,38),(200,473,291),(201,452,278),(202,959,673),(203,545,529),(204,711,673),(205,673,480),(206,790,626),(207,311,423),(208,56,83),(209,658,160),(210,484,388),(211,108,423),(212,844,280),(213,765,409),(214,857,917),(215,895,877),(216,989,452),(217,857,831),(218,347,638),(219,982,404),(220,448,286),(221,860,845),(222,74,581),(223,155,221),(224,13,847),(225,501,305),(226,850,565),(227,519,457),(228,113,611),(229,623,658),(230,543,742),(231,231,490),(232,72,312),(233,322,825),(234,589,616),(235,165,219),(236,590,982),(237,324,232),(238,726,672),(239,878,763),(240,950,667),(241,126,611),(242,798,163),(243,200,291),(244,494,28),(245,576,448),(246,308,883),(247,759,990),(248,984,380),(249,440,250),(250,64,412),(251,514,667),(252,113,922),(253,631,27),(254,935,283),(255,79,469),(256,404,97),(257,241,301),(258,745,440),(259,819,876),(260,194,826),(261,811,449),(262,401,169),(263,346,56),(264,161,201),(265,3,8),(266,616,366),(267,154,298),(268,209,870),(269,814,960),(270,518,650),(271,518,572),(272,518,523),(273,518,9),(274,518,763),(275,518,431),(276,518,861),(277,518,457),(278,518,596),(279,518,941),(280,518,620),(281,518,361),(282,518,522),(283,518,754),(284,518,387),(285,518,425),(286,518,19),(287,518,537),(288,518,450),(289,518,775),(290,518,676),(291,518,361),(292,518,150),(293,518,640),(294,518,356),(295,518,922),(296,518,737),(297,518,15),(298,518,663),(299,518,108),(300,518,220),(301,518,296),(302,518,991),(303,518,640),(304,518,157),(305,518,551),(306,518,447),(307,518,113),(308,518,598),(309,518,513),(310,518,823),(311,518,332),(312,518,937),(313,518,894),(314,518,754),(315,518,650),(316,518,991),(317,518,624),(318,518,416),(319,518,156),(320,518,573),(321,518,90),(322,518,280),(323,518,602),(324,518,917),(325,518,996),(326,518,660),(327,518,286),(328,518,47),(329,518,476),(330,518,918),(331,518,814),(332,518,845),(333,518,530),(334,518,267),(335,518,511),(336,518,6),(337,518,92),(338,518,989),(339,518,86),(340,518,572),(341,518,915),(342,518,717),(343,518,40),(344,518,461),(345,518,280),(346,518,328),(347,518,101),(348,518,946),(349,518,663),(350,518,396),(351,518,794),(352,518,38),(353,518,919),(354,518,985),(355,518,695),(356,518,591),(357,518,156),(358,518,11),(359,518,65),(360,518,466),(361,518,357),(362,518,559),(363,518,526),(364,518,314),(365,518,293),(366,518,342),(367,518,145),(368,518,134),(369,518,793),(370,518,469),(371,518,980),(372,518,309),(373,518,873),(374,518,366),(375,518,889),(376,518,549),(377,518,121),(378,518,161),(379,518,419),(380,518,327),(381,518,444),(382,518,603),(383,518,470),(384,518,649),(385,518,848),(386,518,360),(387,518,321),(388,518,618),(389,518,461),(390,518,295),(391,518,343),(392,518,922),(393,518,674),(394,518,181),(395,518,686),(396,518,858),(397,518,684),(398,518,13),(399,518,789),(400,518,336),(401,518,578),(402,518,677),(403,518,70),(404,518,188),(405,518,329),(406,518,85),(407,518,870),(408,518,532),(409,518,508),(410,518,421),(411,518,965),(412,518,326),(413,518,490),(414,518,424),(415,518,216),(416,518,781),(417,518,376),(418,518,482),(419,518,238),(420,518,145),(421,518,935),(422,518,216),(423,518,602),(424,518,28),(425,518,611),(426,518,2),(427,518,12),(428,518,856),(429,518,418),(430,518,872),(431,518,600),(432,518,932),(433,518,566),(434,518,623),(435,518,299),(436,518,617),(437,518,711),(438,518,479),(439,518,639),(440,518,674),(441,518,599),(442,518,110),(443,518,152),(444,518,192),(445,518,707),(446,518,177),(447,518,552),(448,518,697),(449,518,921),(450,518,22),(451,518,550),(452,518,74),(453,518,542),(454,518,731),(455,518,388),(456,518,875),(457,518,333),(458,518,712),(459,518,690),(460,518,392),(461,518,385),(462,518,93),(463,518,759),(464,518,99),(465,518,967),(466,518,62),(467,518,131),(468,518,988),(469,518,146),(470,518,195),(471,518,410),(472,518,968),(473,518,232),(474,518,556),(475,518,563),(476,518,74),(477,518,663),(478,518,962),(479,518,303),(480,518,739),(481,518,199),(482,518,267),(483,518,636),(484,518,155),(485,518,542),(486,518,427),(487,518,278),(488,518,540),(489,518,451),(490,518,928),(491,518,948),(492,518,957),(493,518,768),(494,518,735),(495,518,985),(496,518,678),(497,518,102),(498,518,145),(499,518,675),(500,518,157),(501,518,94),(502,518,862),(503,518,626),(504,518,501),(505,518,545),(506,518,880),(507,518,208),(508,518,430),(509,518,816),(510,518,574),(511,518,615),(512,518,948),(513,518,567),(514,518,783),(515,518,413),(516,518,271),(517,518,114),(518,518,684),(519,518,597),(520,518,96),(521,518,545),(522,518,550),(523,518,168),(524,518,723),(525,518,269),(526,518,699),(527,518,745),(528,518,133),(529,518,353),(530,518,765),(531,518,139),(532,518,515),(533,518,366),(534,518,38),(535,518,334),(536,518,139),(537,518,870),(538,518,646),(539,518,787),(540,518,95),(541,518,948),(542,518,662),(543,518,681),(544,518,19),(545,518,865),(546,518,202),(547,518,903),(548,518,649),(549,518,413),(550,518,989),(551,518,406),(552,518,65),(553,518,881),(554,518,810),(555,518,62),(556,518,201),(557,518,181),(558,518,143),(559,518,431),(560,518,969),(561,518,988),(562,518,2),(563,518,931),(564,518,413),(565,518,160),(566,518,222),(567,518,327),(568,518,457),(569,518,407),(570,518,369),(571,518,279),(572,518,815),(573,518,747),(574,518,396),(575,518,593),(576,518,903),(577,518,162),(578,518,233),(579,518,287),(580,518,546),(581,518,848),(582,518,834),(583,518,567),(584,518,440),(585,518,988),(586,518,796),(587,518,412),(588,518,47),(589,518,605),(590,518,364),(591,518,817),(592,518,781),(593,518,491),(594,518,820),(595,518,790),(596,518,337),(597,518,503),(598,518,790),(599,518,18),(600,518,208),(601,518,434),(602,518,442),(603,518,123),(604,518,451),(605,518,574),(606,518,488),(607,518,700),(608,518,166),(609,518,774),(610,518,836),(611,518,713),(612,518,83),(613,518,771),(614,518,613),(615,518,478),(616,518,568),(617,518,788),(618,518,232),(619,518,72),(620,518,113),(621,518,728),(622,518,841),(623,518,947),(624,518,949),(625,518,774),(626,518,797),(627,518,24),(628,518,28),(629,518,853),(630,518,393),(631,518,40),(632,518,301),(633,518,850),(634,518,138),(635,518,856),(636,518,282),(637,518,567),(638,518,959),(639,518,128),(640,518,59),(641,518,321),(642,518,443),(643,518,345),(644,518,914),(645,518,426),(646,518,540),(647,518,952),(648,518,512),(649,518,979),(650,518,827),(651,518,156),(652,518,402),(653,518,302),(654,518,142),(655,518,337),(656,518,302),(657,518,811),(658,518,61),(659,518,791),(660,518,826),(661,518,719),(662,518,567),(663,518,572),(664,518,900),(665,518,430),(666,518,57),(667,518,43),(668,518,409),(669,518,688),(670,518,127),(671,518,409),(672,518,648),(673,518,190),(674,518,361),(675,518,550),(676,518,985),(677,518,911),(678,518,953),(679,518,979),(680,518,809),(681,518,475),(682,518,619),(683,518,880),(684,518,417),(685,518,137),(686,518,341),(687,518,332),(688,518,351),(689,518,750),(690,518,477),(691,518,463),(692,518,647),(693,518,89),(694,518,866),(695,518,895),(696,518,410),(697,518,285),(698,518,743),(699,518,299),(700,518,632),(701,518,832),(702,518,118),(703,518,819),(704,518,631),(705,518,98),(706,518,71),(707,518,431),(708,518,231),(709,518,737),(710,518,914),(711,518,429),(712,518,273),(713,518,908),(714,518,894),(715,518,89),(716,518,945),(717,518,588),(718,518,903),(719,518,785),(720,518,772),(721,518,724),(722,518,193),(723,518,160),(724,518,37),(725,518,407),(726,518,286),(727,518,155),(728,518,602),(729,518,535),(730,518,474),(731,518,45),(732,518,366),(733,518,595),(734,518,307),(735,518,455),(736,518,524),(737,518,551),(738,518,18),(739,518,364),(740,518,148),(741,518,99),(742,518,446),(743,518,673),(744,518,373),(745,518,800),(746,518,47),(747,518,565),(748,518,236),(749,518,635),(750,518,884),(751,518,248),(752,518,210),(753,518,111),(754,518,705),(755,518,358),(756,518,617),(757,518,844),(758,518,187),(759,518,434),(760,518,869),(761,518,264),(762,518,781),(763,518,555),(764,518,733),(765,518,376),(766,518,225),(767,518,764),(768,518,805),(769,518,572),(770,518,121),(771,518,927),(772,518,116),(773,518,266),(774,518,47),(775,518,440),(776,518,496),(777,518,324),(778,518,621),(779,518,178),(780,518,788),(781,518,137),(782,518,699),(783,518,407),(784,518,215),(785,518,576),(786,518,803),(787,518,501),(788,518,143),(789,518,353),(790,518,140),(791,518,44),(792,518,134),(793,518,966),(794,518,130),(795,518,300),(796,518,86),(797,518,907),(798,518,603),(799,518,434),(800,518,529),(801,518,737),(802,518,430),(803,518,180),(804,518,745),(805,518,429),(806,518,452),(807,518,894),(808,518,414),(809,518,728),(810,518,461),(811,518,27),(812,518,638),(813,518,658),(814,518,299),(815,518,945),(816,518,30),(817,518,734),(818,518,6),(819,518,970),(820,518,497),(821,518,995),(822,518,965),(823,518,728),(824,518,763),(825,518,764),(826,518,157),(827,518,538),(828,518,722),(829,518,796),(830,518,408),(831,518,540),(832,518,511),(833,518,226),(834,518,450),(835,518,810),(836,518,113),(837,518,78),(838,518,34),(839,518,221),(840,518,73),(841,518,801),(842,518,877),(843,518,132),(844,518,590),(845,518,378),(846,518,43),(847,518,691),(848,518,403),(849,518,819),(850,518,39),(851,518,423),(852,518,461),(853,518,82),(854,518,972),(855,518,545),(856,518,472),(857,518,511),(858,518,411),(859,518,216),(860,518,174),(861,518,699),(862,518,38),(863,518,739),(864,518,984),(865,518,567),(866,518,640),(867,518,610),(868,518,518),(869,518,502),(870,518,809),(871,518,432),(872,518,794),(873,518,372),(874,518,798),(875,518,315),(876,518,788),(877,518,673),(878,518,31),(879,518,19),(880,518,434),(881,518,855),(882,518,817),(883,518,953),(884,518,596),(885,518,158),(886,518,561),(887,518,112),(888,518,476),(889,518,863),(890,518,826),(891,518,470),(892,518,434),(893,518,612),(894,518,624),(895,518,975),(896,518,521),(897,518,499),(898,518,559),(899,518,461),(900,518,326),(901,518,933),(902,518,267),(903,518,208),(904,518,811),(905,518,388),(906,518,554),(907,518,938),(908,518,110),(909,518,662),(910,518,281),(911,518,34),(912,518,414),(913,518,861),(914,518,474),(915,518,8),(916,518,269),(917,518,34),(918,518,819),(919,518,365),(920,518,404),(921,518,888),(922,518,209),(923,518,605),(924,518,434),(925,518,988),(926,518,302),(927,518,94),(928,518,787),(929,518,451),(930,518,490),(931,518,8),(932,518,332),(933,518,238),(934,518,344),(935,518,707),(936,518,957),(937,518,891),(938,518,868),(939,518,37),(940,518,378),(941,518,840),(942,518,538),(943,518,925),(944,518,262),(945,518,321),(946,518,288),(947,518,32),(948,518,929),(949,518,935),(950,518,76),(951,518,137),(952,518,700),(953,518,668),(954,518,850),(955,518,188),(956,518,571),(957,518,296),(958,518,979),(959,518,65),(960,518,740),(961,518,140),(962,518,712),(963,518,280),(964,518,117),(965,518,132),(966,518,710),(967,518,386),(968,518,931),(969,518,614),(970,518,188),(971,518,256),(972,518,527),(973,518,443),(974,518,654),(975,518,724),(976,518,598),(977,518,218),(978,518,151),(979,518,138),(980,518,810),(981,518,782),(982,518,348),(983,518,537),(984,518,143),(985,518,468),(986,518,43),(987,518,789),(988,518,688),(989,518,419),(990,518,406),(991,518,698),(992,518,281),(993,518,663),(994,518,657),(995,518,332),(996,518,290),(997,518,236),(998,518,558),(999,518,882),(1000,518,126),(1001,518,467),(1002,518,361),(1003,518,741),(1004,518,795),(1005,518,180),(1006,518,873),(1007,518,947),(1008,518,289),(1009,518,172),(1010,518,562),(1011,518,51),(1012,518,567),(1013,518,68),(1014,518,25),(1015,518,989),(1016,518,284),(1017,518,141),(1018,518,989),(1019,518,191),(1020,518,453),(1021,518,244),(1022,518,143),(1023,518,679),(1024,518,91),(1025,518,926),(1026,518,333),(1027,518,596),(1028,518,520),(1029,518,384),(1030,518,879),(1031,518,739),(1032,518,767),(1033,518,674),(1034,518,162),(1035,518,550),(1036,518,877),(1037,518,843),(1038,518,529),(1039,518,637),(1040,518,315),(1041,518,402),(1042,518,358),(1043,518,865),(1044,518,8),(1045,518,689),(1046,518,237),(1047,896,644),(1048,443,665),(1049,902,935),(1050,602,688),(1051,280,620),(1052,564,656),(1053,363,761),(1054,354,667),(1055,976,392),(1056,36,711),(1057,552,348),(1058,977,432),(1059,468,263),(1060,396,711),(1061,232,644),(1062,397,874),(1063,323,381),(1064,86,349),(1065,695,977),(1066,652,756),(1067,231,261),(1068,482,122),(1069,724,209),(1070,483,414),(1071,579,123),(1072,919,849),(1073,948,768),(1074,527,405),(1075,672,52),(1076,125,171),(1077,139,572),(1078,922,161),(1079,555,941),(1080,572,678),(1081,944,886),(1082,798,10),(1083,567,680),(1084,142,46),(1085,645,732),(1086,849,691),(1087,654,396),(1088,475,101),(1089,83,962),(1090,674,431),(1091,198,499),(1092,540,513),(1093,173,807),(1094,827,997),(1095,876,847),(1096,917,334),(1097,73,454),(1098,485,52),(1099,282,642),(1100,196,352),(1101,801,803),(1102,980,674),(1103,451,611),(1104,502,138),(1105,183,529),(1106,9,59),(1107,646,922),(1108,609,264),(1109,271,540),(1110,825,859),(1111,36,514),(1112,835,892),(1113,316,80),(1114,493,403),(1115,535,81),(1116,375,262),(1117,73,457),(1118,759,508),(1119,537,315),(1120,863,144),(1121,643,422),(1122,793,38),(1123,992,85),(1124,388,605),(1125,994,139),(1126,682,226),(1127,753,912),(1128,85,780),(1129,751,422),(1130,934,109),(1131,283,461),(1132,903,872),(1133,866,952),(1134,888,780),(1135,98,849),(1136,271,245),(1137,376,311),(1138,989,314),(1139,659,577),(1140,301,414),(1141,927,411),(1142,254,815),(1143,558,569),(1144,472,660),(1145,599,309),(1146,483,209),(1147,299,933),(1148,500,262),(1149,998,130),(1150,517,311),(1151,214,293),(1152,360,973),(1153,192,283),(1154,47,881),(1155,680,669),(1156,755,949),(1157,121,114),(1158,589,681),(1159,720,304),(1160,568,322),(1161,997,339),(1162,799,228),(1163,435,834),(1164,168,160),(1165,497,492),(1166,904,344),(1167,776,423),(1168,399,417),(1169,951,1000),(1170,844,940),(1171,33,665),(1172,376,530),(1173,351,473),(1174,836,195),(1175,244,46),(1176,128,52),(1177,878,37),(1178,533,190),(1179,350,856),(1180,2,437),(1181,24,651),(1182,493,532),(1183,294,856),(1184,853,711),(1185,84,45),(1186,908,339),(1187,751,711),(1188,877,685),(1189,398,765),(1190,968,970),(1191,65,125),(1192,963,582),(1193,677,553),(1194,232,651),(1195,853,1000),(1196,811,470),(1197,39,206),(1198,276,879),(1199,337,393),(1200,621,47),(1201,91,52),(1202,872,788),(1203,126,790),(1204,395,40),(1205,618,74),(1206,639,583),(1207,40,1000),(1208,647,474),(1209,713,102),(1210,132,596),(1211,992,356),(1212,757,125),(1213,933,756),(1214,812,794),(1215,197,802),(1216,167,990),(1217,228,819),(1218,315,681),(1219,369,547),(1220,183,69),(1221,159,96),(1222,11,622),(1223,847,327),(1224,692,631),(1225,183,626),(1226,355,253),(1227,151,296),(1228,688,55),(1229,805,344),(1230,461,931),(1231,842,566),(1232,756,796),(1233,924,865),(1234,414,616),(1235,551,745),(1236,775,303),(1237,453,654),(1238,884,628),(1239,462,251),(1240,897,728),(1241,920,45),(1242,470,74),(1243,762,116),(1244,370,584),(1245,614,474),(1246,923,564),(1247,20,198),(1248,186,741),(1249,717,493),(1250,869,394),(1251,257,62),(1252,179,824),(1253,282,190),(1254,430,194),(1255,15,950),(1256,826,368),(1257,266,89),(1258,877,430),(1259,149,993),(1260,382,693),(1261,369,906),(1262,25,630),(1263,168,17),(1264,809,752),(1265,137,569),(1266,255,279),(1267,211,220),(1268,833,48),(1269,983,797),(1270,728,51),(1271,267,341),(1272,682,158),(1273,804,800),(1274,527,181),(1275,936,58),(1276,503,13),(1277,7,544),(1278,776,631),(1279,343,938),(1280,466,598),(1281,596,482),(1282,823,283),(1283,879,762),(1284,91,255),(1285,755,160),(1286,654,754),(1287,21,733),(1288,156,930),(1289,377,397),(1290,599,86),(1291,688,990),(1292,70,965),(1293,242,934),(1294,56,566),(1295,414,569),(1296,973,995),(1297,332,724),(1298,725,448),(1299,133,305),(1300,458,319),(1301,952,454),(1302,793,985),(1303,694,428),(1304,846,739),(1305,902,195),(1306,785,714),(1307,263,691),(1308,940,3),(1309,91,337),(1310,556,363),(1311,901,596),(1312,236,403),(1313,745,187),(1314,139,446),(1315,659,808),(1316,613,177),(1317,933,841),(1318,913,842),(1319,143,547),(1320,712,561),(1321,736,972),(1322,626,764),(1323,19,859),(1324,3,425),(1325,526,431),(1326,408,646),(1327,260,497),(1328,79,908),(1329,490,912),(1330,325,472),(1331,742,985),(1332,14,561),(1333,379,116),(1334,57,780),(1335,582,885),(1336,795,705),(1337,506,106),(1338,38,288),(1339,455,968),(1340,24,730),(1341,735,707),(1342,223,250),(1343,551,989),(1344,337,503),(1345,674,441),(1346,925,414),(1347,713,390),(1348,819,216),(1349,345,637),(1350,885,603),(1351,404,666),(1352,575,925),(1353,804,221),(1354,362,158),(1355,928,209),(1356,326,903),(1357,464,341),(1358,857,740),(1359,552,908),(1360,466,578),(1361,553,61),(1362,945,483),(1363,394,700),(1364,400,376),(1365,478,917),(1366,225,709),(1367,165,989),(1368,835,458),(1369,726,252),(1370,629,718),(1371,937,355),(1372,239,34),(1373,632,44),(1374,765,654),(1375,237,257),(1376,874,977),(1377,597,998),(1378,880,660),(1379,680,388),(1380,691,83),(1381,965,49),(1382,759,92),(1383,549,189),(1384,434,361),(1385,500,464),(1386,621,41),(1387,66,597),(1388,889,937),(1389,23,75),(1390,961,867),(1391,420,681),(1392,997,438),(1393,742,316),(1394,571,752),(1395,477,368),(1396,903,47),(1397,489,307),(1398,18,56),(1399,420,897),(1400,313,410),(1401,604,99),(1402,267,24),(1403,592,669),(1404,29,362),(1405,63,237),(1406,498,280),(1407,652,636),(1408,435,295),(1409,836,942),(1410,160,166),(1411,723,930),(1412,551,283),(1413,342,104),(1414,303,959),(1415,736,723),(1416,249,223),(1417,343,819),(1418,310,328),(1419,527,512),(1420,85,723),(1421,484,274),(1422,665,797),(1423,913,123),(1424,538,561),(1425,212,481),(1426,820,414),(1427,670,624),(1428,706,935),(1429,92,490),(1430,444,982),(1431,962,393),(1432,597,68),(1433,756,280),(1434,917,464),(1435,409,691),(1436,505,633),(1437,892,362),(1438,785,811),(1439,944,486),(1440,496,919),(1441,786,352),(1442,720,295),(1443,889,713),(1444,695,677),(1445,745,191),(1446,708,474),(1447,356,542),(1448,333,956),(1449,373,22),(1450,354,56),(1451,492,878),(1452,372,958),(1453,238,985),(1454,258,465),(1455,79,406),(1456,836,226),(1457,403,757),(1458,75,752),(1459,123,33),(1460,90,512),(1461,48,284),(1462,311,387),(1463,378,941),(1464,592,542),(1465,839,221),(1466,376,228),(1467,887,352),(1468,213,481),(1469,542,229),(1470,374,353),(1471,26,377),(1472,123,66),(1473,62,459),(1474,86,503),(1475,645,167),(1476,38,299),(1477,883,970),(1478,235,850),(1479,184,914),(1480,609,660),(1481,193,421),(1482,674,740),(1483,807,558),(1484,430,487),(1485,606,708),(1486,473,853),(1487,104,372),(1488,638,764),(1489,108,154),(1490,92,817),(1491,49,821),(1492,506,723),(1493,874,973),(1494,633,797),(1495,478,409),(1496,550,575),(1497,8,802),(1498,423,920),(1499,637,124),(1500,815,636),(1501,13,582),(1502,102,554),(1503,41,964),(1504,265,15),(1505,729,4),(1506,553,925),(1507,128,890),(1508,50,89),(1509,143,845),(1510,815,750),(1511,229,387),(1512,200,796),(1513,536,106),(1514,237,406),(1515,924,398),(1516,346,892),(1517,445,835),(1518,999,131),(1519,514,212),(1520,160,409),(1521,746,81),(1522,7,74),(1523,877,622),(1524,210,801),(1525,66,930),(1526,16,704),(1527,288,989),(1528,468,905),(1529,602,642),(1530,965,505),(1531,681,983),(1532,604,171),(1533,32,606),(1534,382,413),(1535,966,825),(1536,369,461),(1537,81,97),(1538,106,498),(1539,35,945),(1540,705,533),(1541,635,808),(1542,544,794),(1543,773,809),(1544,644,69),(1545,894,70),(1546,523,123),(1547,894,764),(1548,136,660),(1549,155,771),(1550,975,692),(1551,669,916),(1552,932,125),(1553,870,162),(1554,889,974),(1555,709,650),(1556,729,580),(1557,261,619),(1558,296,115),(1559,827,460),(1560,414,665),(1561,188,866),(1562,377,516),(1563,816,786),(1564,442,947),(1565,34,80),(1566,77,375),(1567,816,876),(1568,436,837),(1569,221,137),(1570,725,732),(1571,149,397),(1572,361,943),(1573,864,401),(1574,280,582),(1575,252,463),(1576,226,843),(1577,428,280),(1578,876,290),(1579,631,797),(1580,783,777),(1581,354,105),(1582,579,506),(1583,648,714),(1584,136,172),(1585,972,789),(1586,576,743),(1587,392,681),(1588,741,58),(1589,259,439),(1590,38,800),(1591,856,360),(1592,130,162),(1593,514,455),(1594,867,511),(1595,719,602),(1596,945,117),(1597,130,405),(1598,985,600),(1599,862,900),(1600,4,695),(1601,493,350),(1602,503,645),(1603,974,92),(1604,467,504),(1605,396,743),(1606,348,348),(1607,250,305),(1608,806,856),(1609,901,542),(1610,315,84),(1611,36,770),(1612,388,99),(1613,264,543),(1614,331,627),(1615,419,279),(1616,343,973),(1617,476,879),(1618,377,294),(1619,354,270),(1620,656,289),(1621,267,124),(1622,212,285),(1623,914,899),(1624,477,984),(1625,988,710),(1626,954,813),(1627,709,658),(1628,817,949),(1629,459,850),(1630,402,648),(1631,595,66),(1632,90,300),(1633,697,316),(1634,845,710),(1635,825,142),(1636,477,467),(1637,554,103),(1638,773,277),(1639,355,720),(1640,621,302),(1641,88,71),(1642,214,780),(1643,646,214),(1644,949,965),(1645,249,533),(1646,410,220),(1647,265,317),(1648,412,403),(1649,217,968),(1650,627,546),(1651,292,568),(1652,576,462),(1653,805,710),(1654,5,742),(1655,794,977),(1656,882,376),(1657,467,833),(1658,839,707),(1659,112,332),(1660,67,996),(1661,278,779),(1662,733,123),(1663,682,567),(1664,877,384),(1665,529,811),(1666,904,299),(1667,306,648),(1668,908,258),(1669,60,902),(1670,618,357),(1671,83,845),(1672,328,1),(1673,848,310),(1674,950,756),(1675,980,801),(1676,773,448),(1677,161,487),(1678,767,600),(1679,188,4),(1680,933,7),(1681,991,429),(1682,522,438),(1683,77,268),(1684,920,127),(1685,946,614),(1686,497,75),(1687,785,996),(1688,308,879),(1689,445,334),(1690,294,363),(1691,339,41),(1692,248,434),(1693,510,955),(1694,859,105),(1695,629,400),(1696,408,569),(1697,106,763),(1698,475,930),(1699,514,956),(1700,617,827),(1701,387,288),(1702,872,251),(1703,58,540),(1704,766,410),(1705,984,534),(1706,613,429),(1707,379,207),(1708,543,735),(1709,820,262),(1710,339,877),(1711,260,730),(1712,650,688),(1713,886,298),(1714,18,327),(1715,635,855),(1716,981,602),(1717,537,726),(1718,21,160),(1719,372,808),(1720,345,767),(1721,533,170),(1722,384,692),(1723,205,462),(1724,948,550),(1725,995,591),(1726,460,599),(1727,587,906),(1728,674,208),(1729,308,418),(1730,285,6),(1731,15,134),(1732,526,163),(1733,706,587),(1734,78,106),(1735,861,808),(1736,589,803),(1737,153,424),(1738,791,772),(1739,84,799),(1740,596,235),(1741,673,538),(1742,310,198),(1743,399,758),(1744,715,134),(1745,59,256),(1746,777,809),(1747,348,698),(1748,140,872),(1749,812,970),(1750,98,15),(1751,312,111),(1752,498,419),(1753,429,605),(1754,671,973),(1755,250,677),(1756,737,403),(1757,685,413),(1758,806,129),(1759,833,953),(1760,364,86),(1761,371,74),(1762,681,743),(1763,360,595),(1764,551,804),(1765,133,57),(1766,880,323),(1767,46,595),(1768,71,911),(1769,930,934),(1770,728,260),(1771,87,198),(1772,897,726),(1773,690,28),(1774,205,744),(1775,280,909),(1776,129,1846),(1777,737,1933),(1778,671,1171),(1779,581,1380),(1780,498,1148),(1781,591,1930),(1782,821,1285),(1783,712,1217),(1784,780,1100),(1785,661,1917),(1786,742,1680),(1787,264,1739),(1788,722,1162),(1789,237,1479),(1790,360,1117),(1791,674,1966),(1792,875,1697),(1793,789,1379),(1794,754,1038),(1795,93,1149),(1796,530,1929),(1797,472,1957),(1798,740,1567),(1799,568,1953),(1800,473,1633),(1801,333,1980),(1802,274,1451),(1803,583,1418),(1804,162,1668),(1805,918,1231),(1806,155,1856),(1807,601,1988),(1808,499,1568),(1809,5,1971),(1810,898,1940),(1811,240,1153),(1812,996,1210),(1813,90,1177),(1814,865,1595),(1815,474,1857),(1816,166,1400),(1817,458,1302),(1818,621,1135),(1819,882,1139),(1820,336,1940),(1821,521,1668),(1822,320,1760),(1823,464,1872),(1824,805,1780),(1825,320,1216),(1826,133,1113),(1827,56,1244),(1828,187,1772),(1829,734,1597),(1830,951,1164),(1831,860,1769),(1832,731,1477),(1833,796,1123),(1834,94,1120),(1835,434,1150),(1836,974,1755),(1837,751,1155),(1838,524,1688),(1839,515,1115),(1840,823,1151),(1841,319,1962),(1842,724,1159),(1843,876,1215),(1844,252,1151),(1845,961,1917),(1846,680,1766),(1847,416,1711),(1848,473,1084),(1849,667,1763),(1850,252,1036),(1851,50,1299),(1852,344,1190),(1853,668,1857),(1854,790,1180),(1855,702,1125),(1856,524,1615),(1857,868,1847),(1858,230,1666),(1859,970,1747),(1860,630,1497),(1861,67,1884),(1862,640,1524),(1863,1000,1468),(1864,637,1758),(1865,355,1676),(1866,725,1258),(1867,825,1694),(1868,944,1821),(1869,573,1921),(1870,697,1817),(1871,30,1479),(1872,882,1691),(1873,666,1553),(1874,180,1925),(1875,642,1943),(1876,130,1973),(1877,8,1176),(1878,725,1304),(1879,280,1460),(1880,341,1382),(1881,680,1890),(1882,308,1162),(1883,95,1910),(1884,798,1301),(1885,250,1865),(1886,315,1603),(1887,502,1141),(1888,20,1945),(1889,74,1504),(1890,51,1127),(1891,108,1048),(1892,201,1337),(1893,131,1279),(1894,398,1210),(1895,500,1038),(1896,920,1724),(1897,980,1597),(1898,488,1692),(1899,70,1115),(1900,111,1902),(1901,945,1225),(1902,693,1433),(1903,572,1852),(1904,289,1044),(1905,338,1161),(1906,389,1898),(1907,608,1246),(1908,197,1344),(1909,985,1217),(1910,795,1085),(1911,578,1271),(1912,371,1385),(1913,157,1368),(1914,843,1169),(1915,210,1417),(1916,965,1430),(1917,570,1966),(1918,648,1136),(1919,198,1333),(1920,45,1226),(1921,189,1675),(1922,889,1373),(1923,271,1717),(1924,974,1583),(1925,968,1902),(1926,940,1446),(1927,887,1235),(1928,611,1543),(1929,682,1710),(1930,385,1798),(1931,500,1357),(1932,845,1040),(1933,414,1408),(1934,892,1480),(1935,381,1783),(1936,3,1735),(1937,338,1240),(1938,127,1060),(1939,973,1195),(1940,194,1764),(1941,391,1833),(1942,87,1554),(1943,933,1352),(1944,756,1135),(1945,845,1995),(1946,500,1670),(1947,386,1262),(1948,763,1907),(1949,649,1891),(1950,985,1641),(1951,210,1857),(1952,860,1297),(1953,249,1153),(1954,210,1697),(1955,533,1474),(1956,308,1685),(1957,186,1329),(1958,4,1219),(1959,618,1426),(1960,475,1307),(1961,439,1713),(1962,530,1349),(1963,91,1188),(1964,981,1277),(1965,943,1716),(1966,214,1023),(1967,335,1133),(1968,495,1419),(1969,853,1820),(1970,209,1029),(1971,101,1900),(1972,65,1128),(1973,596,1934),(1974,767,1103),(1975,886,1298),(1976,338,1753),(1977,925,1278),(1978,746,1517),(1979,870,1814),(1980,236,1424),(1981,260,1220),(1982,863,1615),(1983,630,1247),(1984,277,1253),(1985,792,1550),(1986,685,1019),(1987,514,1108),(1988,178,1839),(1989,504,1684),(1990,100,1190),(1991,416,1233),(1992,760,1135),(1993,223,1192),(1994,784,1761),(1995,441,1445),(1996,954,1678),(1997,352,1947),(1998,753,1353),(1999,819,1756),(2000,552,1580),(2001,268,1774),(2002,493,1777),(2003,626,1618),(2004,983,1038),(2005,470,1239),(2006,940,1262),(2007,638,1534),(2008,71,1805),(2009,494,1535),(2010,362,1160),(2011,306,1638),(2012,708,1474),(2013,35,1454),(2014,872,1174),(2015,477,1202),(2016,284,1220),(2017,778,1185),(2018,728,1824),(2019,703,1907),(2020,517,1516),(2021,954,1274),(2022,208,1156),(2023,218,1902),(2024,609,1459),(2025,459,1167),(2026,595,1684),(2027,270,1795),(2028,972,1979),(2029,755,1619),(2030,73,1484),(2031,451,1900),(2032,341,1609),(2033,779,1777),(2034,774,1055),(2035,602,1546),(2036,165,1535),(2037,825,1915),(2038,670,1187),(2039,295,1805),(2040,988,1968),(2041,535,1265),(2042,360,1372),(2043,647,1397),(2044,988,1060),(2045,985,1730),(2046,283,1502),(2047,182,1246),(2048,965,1960),(2049,858,1593),(2050,193,1011),(2051,216,1452),(2052,651,1483),(2053,811,1109),(2054,978,1426),(2055,663,1219),(2056,532,1361),(2057,488,1630),(2058,246,1369),(2059,408,1380),(2060,9,1744),(2061,743,1578),(2062,234,1547),(2063,150,1030),(2064,896,1623),(2065,935,1164),(2066,352,1340),(2067,14,1612),(2068,28,1802),(2069,302,1264),(2070,22,1347),(2071,467,1354),(2072,652,1020),(2073,371,1564),(2074,38,1693),(2075,833,1435),(2076,165,1512),(2077,205,1147),(2078,543,1710),(2079,235,1226),(2080,10,1356),(2081,82,1742),(2082,599,1417),(2083,101,1673),(2084,677,1097),(2085,569,1942),(2086,237,1194),(2087,747,1289),(2088,758,1401),(2089,624,1077),(2090,889,1111),(2091,541,1395),(2092,519,1666),(2093,124,1470),(2094,756,1047),(2095,58,1239),(2096,481,1451),(2097,431,1335),(2098,357,1074),(2099,13,1999),(2100,720,1558),(2101,169,1072),(2102,637,1786),(2103,571,1167),(2104,911,1777),(2105,551,1620),(2106,87,1186),(2107,895,1075),(2108,519,1360),(2109,591,1633),(2110,134,1955),(2111,584,1689),(2112,474,1365),(2113,44,1156),(2114,208,1663),(2115,79,1377),(2116,567,1922),(2117,797,1808),(2118,365,1194),(2119,519,1474),(2120,683,1839),(2121,330,1556),(2122,656,1098),(2123,652,1190),(2124,898,1610),(2125,879,1967),(2126,489,1900),(2127,338,1635),(2128,297,1465),(2129,692,1208),(2130,623,1658),(2131,560,1054),(2132,777,1763),(2133,943,1209),(2134,818,1481),(2135,685,1261),(2136,612,1199),(2137,434,1059),(2138,713,1901),(2139,729,1029),(2140,916,1561),(2141,96,1659),(2142,283,1425),(2143,419,1300),(2144,742,1320),(2145,897,1578),(2146,519,1739),(2147,772,1872),(2148,385,1420),(2149,448,1258),(2150,262,1714),(2151,437,1261),(2152,535,1847),(2153,138,1798),(2154,984,1246),(2155,125,1783),(2156,804,1870),(2157,765,1034),(2158,303,1443),(2159,938,1727),(2160,162,1893),(2161,601,1652),(2162,185,1156),(2163,450,1850),(2164,177,1245),(2165,48,1574),(2166,543,1396),(2167,705,1981),(2168,536,1541),(2169,451,1604),(2170,456,1094),(2171,709,1803),(2172,706,1573),(2173,512,1096),(2174,969,1453),(2175,861,1301),(2176,639,1170),(2177,80,1446),(2178,665,1005),(2179,119,1515),(2180,72,1633),(2181,71,1698),(2182,16,1532),(2183,421,1860),(2184,853,1398),(2185,242,1468),(2186,519,1559),(2187,519,1615),(2188,534,1308),(2189,77,1449),(2190,404,1576),(2191,103,1200),(2192,27,1900),(2193,405,1458),(2194,571,1348),(2195,344,1302),(2196,275,1727),(2197,446,1698),(2198,458,1509),(2199,737,1997),(2200,279,1543),(2201,401,1880),(2202,867,1576),(2203,323,1312),(2204,271,1267),(2205,191,1908),(2206,375,1121),(2207,799,1650),(2208,502,1578),(2209,483,1802),(2210,866,1346),(2211,72,1740),(2212,275,1096),(2213,640,1068),(2214,96,1806),(2215,488,1020),(2216,162,1144),(2217,486,1899),(2218,641,1217),(2219,764,1772),(2220,749,1196),(2221,583,1542),(2222,424,1730),(2223,431,1345),(2224,390,1495),(2225,914,1522),(2226,519,1671),(2227,218,1456),(2228,145,1453),(2229,766,1887),(2230,597,1283),(2231,886,1600),(2232,187,1641),(2233,303,1472),(2234,876,1804),(2235,24,1738),(2236,876,1080),(2237,519,1523),(2238,786,1098),(2239,122,1465),(2240,519,1496),(2241,151,1197),(2242,446,1433),(2243,917,1771),(2244,12,1670),(2245,652,1043),(2246,831,1910),(2247,84,1959),(2248,624,1133),(2249,233,1743),(2250,695,1525),(2251,511,1989),(2252,519,1747),(2253,416,1594),(2254,828,1002),(2255,775,1823),(2256,161,1324),(2257,972,1347),(2258,403,1742),(2259,130,1534),(2260,734,1653),(2261,768,1212),(2262,633,1540),(2263,875,1984),(2264,86,1620),(2265,377,1993),(2266,346,1653),(2267,80,1822),(2268,257,1204),(2269,851,1317),(2270,137,1711),(2271,877,1518),(2272,790,1610),(2273,633,1230),(2274,768,1699),(2275,601,1688),(2276,419,1975),(2277,317,1457),(2278,43,1026),(2279,508,1926),(2280,844,1421),(2281,700,1439),(2282,880,1111),(2283,946,1406),(2284,604,1325),(2285,945,1244),(2286,836,1274),(2287,836,1827),(2288,612,1666),(2289,480,1251),(2290,24,1756),(2291,519,1458),(2292,923,1578),(2293,801,1113),(2294,97,1468),(2295,689,1502),(2296,2,1997),(2297,523,1003),(2298,147,1984),(2299,43,1083),(2300,675,1816),(2301,402,1726),(2302,543,1819),(2303,129,1012),(2304,336,1400),(2305,347,1641),(2306,104,1960),(2307,138,1494),(2308,748,1695),(2309,14,1516),(2310,987,1030),(2311,171,1967),(2312,519,1515),(2313,193,1759),(2314,871,1785),(2315,719,1400),(2316,118,1069),(2317,578,1547),(2318,58,1479),(2319,849,1562),(2320,712,1065),(2321,810,1757),(2322,957,1012),(2323,725,1042),(2324,736,1263),(2325,870,1214),(2326,693,1941),(2327,640,1746),(2328,926,1415),(2329,688,1994),(2330,861,1283),(2331,733,1535),(2332,964,1774),(2333,270,1362),(2334,824,1593),(2335,243,1593),(2336,124,1151),(2337,655,1456),(2338,591,1003),(2339,234,1607),(2340,763,1889),(2341,799,1968),(2342,266,1264),(2343,761,1032),(2344,715,1791),(2345,363,1170),(2346,622,1973),(2347,435,1628),(2348,480,1552),(2349,99,1227),(2350,712,1691),(2351,232,1546),(2352,679,1306),(2353,339,1400),(2354,591,1463),(2355,692,1879),(2356,358,1579),(2357,677,1869),(2358,442,1082),(2359,934,1256),(2360,372,1348),(2361,26,1845),(2362,559,1278),(2363,796,1549),(2364,863,1117),(2365,832,1258),(2366,354,1168),(2367,882,1743),(2368,472,1855),(2369,559,1913),(2370,582,1403),(2371,55,1166),(2372,905,1602),(2373,549,1369),(2374,148,1565),(2375,592,1787),(2376,534,1793),(2377,353,1094),(2378,125,1403),(2379,753,1560),(2380,666,1789),(2381,473,1217),(2382,514,1712),(2383,692,1754),(2384,260,1771),(2385,112,1876),(2386,684,1880),(2387,425,1270),(2388,490,1672),(2389,318,1566),(2390,75,1615),(2391,720,1383),(2392,259,1426),(2393,124,1041),(2394,598,1157),(2395,700,1774),(2396,590,1998),(2397,227,1549),(2398,365,1635),(2399,649,1992),(2400,444,1083),(2401,177,1498),(2402,254,1326),(2403,633,1327),(2404,98,1624),(2405,264,1917),(2406,843,1342),(2407,238,1071),(2408,241,1148),(2409,147,1469),(2410,301,1868),(2411,42,1514),(2412,63,1491),(2413,826,1551),(2414,95,1098),(2415,297,1972),(2416,829,1876),(2417,520,1863),(2418,559,1390),(2419,708,1956),(2420,266,1863),(2421,216,1416),(2422,933,1349),(2423,468,1434),(2424,51,1037),(2425,504,1154),(2426,995,1237),(2427,908,1645),(2428,543,1694),(2429,417,1769),(2430,619,1388),(2431,457,1667),(2432,39,1766),(2433,109,1027),(2434,557,1058),(2435,130,1848),(2436,213,1034),(2437,251,1888),(2438,796,1035),(2439,894,1347),(2440,504,1770),(2441,316,1792),(2442,531,1585),(2443,236,1351),(2444,973,1212),(2445,275,1030),(2446,892,1353),(2447,49,1465),(2448,919,1283),(2449,397,1139),(2450,607,1934),(2451,708,1700),(2452,897,1256),(2453,132,1198),(2454,886,1866),(2455,878,1913),(2456,70,1126),(2457,1000,1742),(2458,105,1723),(2459,557,1883),(2460,787,1055),(2461,600,1161),(2462,569,1263),(2463,248,1052),(2464,230,1112),(2465,792,1666),(2466,179,1538),(2467,110,1545),(2468,715,1588),(2469,319,1458),(2470,627,1511),(2471,352,1154),(2472,104,1369),(2473,898,1748),(2474,148,1162),(2475,126,1922),(2476,997,1847),(2477,430,1075),(2478,81,1582),(2479,995,1244),(2480,772,1922),(2481,441,1717),(2482,552,1614),(2483,669,1871),(2484,12,1480),(2485,315,1358),(2486,781,1273),(2487,280,1619),(2488,519,1336),(2489,867,1463),(2490,203,1749),(2491,99,1138),(2492,876,1535),(2493,760,1391),(2494,3,1025),(2495,413,1717),(2496,803,1947),(2497,628,1871),(2498,386,1827),(2499,796,1976),(2500,110,1676),(2501,704,1932),(2502,864,1457),(2503,819,1860),(2504,202,1208),(2505,958,1271),(2506,543,1536),(2507,549,1893),(2508,896,1776),(2509,194,1080),(2510,710,1598),(2511,543,1802),(2512,373,1495),(2513,471,1760),(2514,908,1819),(2515,239,1348),(2516,647,1562),(2517,519,1356),(2518,194,1540),(2519,7,1400),(2520,32,1953),(2521,209,1465),(2522,600,1077),(2523,977,1164),(2524,35,1922),(2525,519,1415),(2526,69,1375),(2527,385,1304),(2528,41,1056),(2529,740,1157),(2530,926,1911),(2531,785,1396),(2532,685,1042),(2533,697,1302),(2534,836,1569),(2535,620,1728),(2536,834,1721),(2537,479,1551),(2538,985,1069),(2539,131,1523),(2540,898,1877),(2541,8,1769),(2542,114,1711),(2543,166,1620),(2544,843,1642),(2545,851,1480),(2546,708,1502),(2547,90,2000),(2548,968,1767),(2549,245,1160),(2550,905,1832),(2551,962,1643),(2552,218,1998),(2553,393,1289),(2554,70,1079),(2555,5,1074),(2556,197,1198),(2557,207,1330),(2558,553,1500),(2559,513,1756),(2560,587,1391),(2561,553,1104),(2562,580,1023),(2563,170,1507),(2564,41,1829),(2565,162,1537),(2566,342,1933),(2567,445,1418),(2568,343,1316),(2569,680,1918),(2570,487,1531),(2571,567,1102),(2572,917,1100),(2573,786,1003),(2574,583,1275),(2575,454,1255),(2576,319,1173),(2577,194,1712),(2578,511,1712),(2579,5,1091),(2580,435,1358),(2581,3,1422),(2582,570,1266),(2583,155,1624),(2584,694,1518),(2585,907,1391),(2586,599,1939),(2587,941,1401),(2588,868,1892),(2589,643,1469),(2590,217,1268),(2591,660,1852),(2592,906,1255),(2593,892,1162),(2594,478,1188),(2595,406,1882),(2596,759,1638),(2597,503,1063),(2598,487,1979),(2599,14,1584),(2600,920,1717),(2601,743,1603),(2602,621,1613),(2603,765,1104),(2604,413,1020),(2605,173,1683),(2606,731,1186),(2607,573,1157),(2608,561,1104),(2609,673,1787),(2610,558,1998),(2611,246,1929),(2612,385,1492),(2613,947,1460),(2614,234,1530),(2615,393,1888),(2616,399,1111),(2617,998,1806),(2618,5,1380),(2619,897,1373),(2620,614,1231),(2621,750,1353),(2622,369,1996),(2623,911,1011),(2624,953,1777),(2625,377,1116),(2626,476,1510),(2627,490,1200),(2628,458,1843),(2629,930,1656),(2630,638,1421),(2631,977,1931),(2632,7,1057),(2633,680,1552),(2634,959,1627),(2635,745,1843),(2636,602,1816),(2637,85,1273),(2638,428,1416),(2639,759,1888),(2640,678,1196),(2641,945,1958),(2642,597,1228),(2643,232,1567),(2644,624,1594),(2645,302,1521),(2646,679,1443),(2647,481,1124),(2648,801,1855),(2649,599,1955),(2650,249,1890),(2651,974,1349),(2652,989,1711),(2653,631,1026),(2654,355,1580),(2655,468,1553),(2656,612,1676),(2657,767,1317),(2658,342,1346),(2659,646,1200),(2660,865,1559),(2661,501,1251),(2662,410,1162),(2663,676,1864),(2664,237,1685),(2665,541,1045),(2666,887,1515),(2667,172,1700),(2668,6,1252),(2669,831,1701),(2670,206,1130),(2671,951,1223),(2672,438,1359),(2673,205,1890),(2674,906,1436),(2675,703,1805),(2676,868,1321),(2677,796,1746),(2678,970,1613),(2679,810,1795),(2680,542,1657),(2681,379,1528),(2682,421,1142),(2683,653,1186),(2684,984,1152),(2685,650,1948),(2686,869,1493),(2687,117,1124),(2688,677,1613),(2689,693,1635),(2690,866,1170),(2691,285,1607),(2692,366,1407),(2693,883,1237),(2694,188,1037),(2695,676,1304),(2696,347,1731),(2697,266,1837),(2698,394,1219),(2699,947,1921),(2700,276,1679),(2701,667,1262),(2702,575,1850),(2703,682,1741),(2704,766,1547),(2705,519,1716),(2706,91,1855),(2707,545,1498),(2708,413,1245),(2709,160,1743),(2710,701,1534),(2711,570,1393),(2712,178,1152),(2713,845,1896),(2714,281,1725),(2715,208,1106),(2716,824,1599),(2717,154,1713),(2718,716,1032),(2719,304,1037),(2720,609,1830),(2721,26,1832),(2722,602,1199),(2723,735,1062),(2724,96,1355),(2725,231,1026),(2726,867,1950),(2727,864,1460),(2728,939,1060),(2729,874,1252),(2730,284,1066),(2731,735,1294),(2732,643,1070),(2733,386,1057),(2734,273,1609),(2735,451,1657),(2736,764,1860),(2737,951,1227),(2738,556,1313),(2739,169,1266),(2740,79,1399),(2741,664,1059),(2742,348,1200),(2743,43,1336),(2744,889,1675),(2745,268,1824),(2746,392,1213),(2747,327,1601),(2748,420,1180),(2749,704,1507),(2750,87,1799),(2751,792,1235),(2752,485,1159),(2753,909,1328),(2754,451,1306),(2755,154,1700),(2756,673,1011),(2757,197,1780),(2758,59,1580),(2759,575,1377),(2760,68,1003),(2761,416,1687),(2762,984,1652),(2763,527,1240),(2764,87,1206),(2765,855,1637),(2766,715,1228),(2767,398,1067),(2768,61,1139),(2769,662,1461),(2770,482,1478),(2771,434,1456),(2772,608,1824),(2773,106,1347),(2774,334,1644),(2775,707,1292);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Harrisville_overfancy_obligee'),(2,'Beng._Elkins_mediterraneous_nursemaids'),(3,'eye-beam_Parzival_orchiditis'),(4,'ortet_opthalmoplegy'),(5,'Oceanic_paralinguistic_Hephaestian'),(6,'deluminize_Slavistic_Epidendron_Corambis'),(7,'wheat-straw_nematogene'),(8,'subinflammation_head-penny_impv_retreat'),(9,'hydantoin_dinettes_Nazism'),(10,'monopolizable_overweaponed_progger'),(11,'julole_miseducate_quasi-invisible'),(12,'xenophilism_Bourgeois'),(13,'canoed_evidences_jitterbugger'),(14,'Malvino_Belmont_dibrom'),(15,'demitted_ratfishes'),(16,'panchromatism_yellowtop_rank-winged'),(17,'cocainomaniac_RRIP_tileseed_HCL'),(18,'trash_affrontive'),(19,'gamesmanship_elf-god'),(20,'diselectrification_two-toed_establishable_nonclarifiable'),(21,'bibliopegically_Psychozoic'),(22,'subphratry_organzas'),(23,'paleontologist_hemoscopy'),(24,'kenogenetic_isospin'),(25,'sitter-in_predisplacement'),(26,'evangelary_gamins'),(27,'Kolacin_airbrained_Emmelene'),(28,'Helice_gigeria_superenthusiasm_spirit-small'),(29,'retooth_swaling'),(30,'froster_overcontract_disinfecter_contranatural'),(31,'Muntiacus_LPF_deathrate'),(32,'saddlecloth_stinkwood_neurotomize'),(33,'subjudge_wheatbird'),(34,'kinsen_world-rare'),(35,'recrop_Alcyonium'),(36,'Barneveldt_stratagematical_diaboleptic'),(37,'Blitzstein_potentee_Aser'),(38,'marnix_incepted_egestion_lyricists'),(39,'rhino_sequacity_Bhoodan_off-pitch'),(40,'president-elect_higgles_ramark_morceau'),(41,'lepidopteron_instals_soft-fingered_annuity'),(42,'snow-pure_fibro-_semideify_opusculum'),(43,'sprucest_jundied_Marattiales'),(44,'nonrevertible_brawn'),(45,'pittine_vug'),(46,'cutter-out_uncongregational'),(47,'pepos_opt'),(48,'Rockie_fleetnesses_unexotic'),(49,'Berhley_Wisc'),(50,'ypsiloid_mapwise_nonaddictive_LMF'),(51,'jesting_Meagan_three-salt'),(52,'morphonomy_illuminatist'),(53,'rile_nontyrannous_bullshit'),(54,'alkalization_meridiem_unassuageable_uninteresting'),(55,'reuse_claystone_prabble'),(56,'gladen_Marybob_Mur_quasi-irregularly'),(57,'jillflirt_Pro-austrian_cozy_Fontinalis'),(58,'storefront_courier\'s_bludger_reissuers'),(59,'fancy-guided_remastery_biomasses'),(60,'incapacious_large-handedness'),(61,'Belostomatidae_loungy'),(62,'unbranching_verbalist_plasmasol'),(63,'unproficiency_benty'),(64,'Dulciana_dermatoneurosis_psych_corrigent'),(65,'overexpress_superstylishness_well-spent_enhunger'),(66,'thresh_Zeelander_nonfantasy_Kruter'),(67,'ophthalmencephalon_onychite_preclassification_greenheart'),(68,'dignify_noverint_suprabranchial'),(69,'functionalizing_Cordoba_concn_plugtray'),(70,'intertidal_reprobator'),(71,'noncongestive_unharmony'),(72,'unwithheld_ultimately'),(73,'humulon_duhat_townmen_litigator'),(74,'goldarn_mesencephalons_torridity'),(75,'periphery\'s_halcyonic_unclothing_itself'),(76,'pilot_unevangelized'),(77,'backside_re-traced'),(78,'ity_sulphantimonate_unsingleness_trunnions'),(79,'boards_roosts_laryngocele_ingeneration'),(80,'extractability_berede_orotundity'),(81,'overgoaded_sea-side'),(82,'brick-walled_nail-shaped'),(83,'cellules_banterer_glowbard_shahzadah'),(84,'hyalinocrystalline_unobediently_Persepolis_Lonzie'),(85,'semiactively_quasi-pledged_Cheremissian'),(86,'Scot._vended'),(87,'Begoniaceae_dogship'),(88,'aeroelastics_boozy_Seldan'),(89,'Murtaugh_feather-work'),(90,'catatonic_Rox_stern-visaged_neck'),(91,'desalts_absinthin'),(92,'Gedankenexperiment_licker_imitatively_post-Leibnizian'),(93,'infra-_quatrin_tenuis_pedalo'),(94,'niton_schindyletic_vasorrhaphy_puckerel'),(95,'gromatics_semi-industrialized_overimpressed_heartland'),(96,'Cynwyd_side-stepped_septifarious'),(97,'anthropolith_digestory'),(98,'outmoves_rosy-colored_unpostponed'),(99,'Heyrovsky_coheiress_precured'),(100,'sasse_quasiorder'),(101,'reinduct_seaquakes'),(102,'heartsome_dustblu_Boigie'),(103,'chuser_cochlitis_shoalwise'),(104,'quasi-observed_tatteredness'),(105,'forepaw_proteosaurid_tainos'),(106,'bright-colored_cladodes_elong'),(107,'Lesterville_glengarries_lysogenic'),(108,'thalluses_stridhan_sacerdotalism'),(109,'guestimated_Brutus_unstriking'),(110,'reinvolves_interferences'),(111,'synactic_tropotaxis'),(112,'profunda_steroid_TGN'),(113,'gyrons_carfuls_ridiculer'),(114,'sneckdrawn_sponsions_headsquare_Pandorea'),(115,'overspends_densitometers_explosion-proof_substream'),(116,'unfanatical_Sophistress'),(117,'arrestees_katsunkel_preparticipation'),(118,'lament_broad-fronted_Melvindale_Plymouth'),(119,'cavaliered_Deccan_foresense'),(120,'bromination_skylarkers'),(121,'evangelicism_postflight'),(122,'vei_flusker_possessionlessness'),(123,'balr_Ochroma_deddy'),(124,'underditch_decolour_homebred'),(125,'colander_cinenchymatous_niblick_sunbows'),(126,'overinclining_gelatification_cryptamnesic'),(127,'outduel_lardiform_overinsistently'),(128,'gargalize_chronal'),(129,'placarder_cross-purpose_kiddy'),(130,'chemick_extradited_fucivorous_tackier'),(131,'ambiances_untilting_underripened'),(132,'streptococci_white-chinned_underagency_quasi-innocent'),(133,'unveiledly_h\'m_revivals_Vitus'),(134,'flustering_superconception_nonrepresentational_czaritzas'),(135,'self-affecting_isopleths_chestnut-collared_reincluding'),(136,'farles_malfunctioning_scapegoats_double-head'),(137,'solach_colo-'),(138,'Ostpreussen_sour-looked'),(139,'unburstable_tomboy_triamino_Ithuriel\'s-spear'),(140,'fatigation_precontractual_adds_Austinburg'),(141,'shank-painter_hollin_pericarditis_Clarist'),(142,'realienation_disexcommunicate_aulas_bullwhacker'),(143,'discordous_consulter'),(144,'Artamus_ultraliberalism_delivers_intractably'),(145,'staghunt_funambulate_hempweeds_pit-blackness'),(146,'scapewheel_rijksdaaler'),(147,'festination_Clarabelle_overglad'),(148,'Aloxe-Corton_fishingly_deathweed'),(149,'Gainor_Arvell_turbinage_Tumwater'),(150,'antipopery_shoulder-strap_earlaps_canonicate'),(151,'dog-hole_unhospitable_NSP_routinizing'),(152,'virilizing_monergism_metallurgist'),(153,'Ronco_snap-rivet_karsha'),(154,'Saxicolinae_veter_Re-puritanize_millioctave'),(155,'bandfiled_preeligibility_unsparkling'),(156,'exemplariness_seventy-one_piazzian'),(157,'reordaining_amanitins_labialismus_keyholes'),(158,'anallagmatic_epural'),(159,'choripetalous_rammelsbergite'),(160,'ultrasplendid_Olodort'),(161,'illogicalities_yucked_Osyth'),(162,'Delorme_unexhausted_Marjy_respond'),(163,'bendsome_poundless_perisarcal'),(164,'Tayrona_black-cornered_smooth-wrought'),(165,'hucksterize_epiphanized_compatibleness'),(166,'Taima_ICP_cchaddoorck_normalizes'),(167,'Gareth_re-rehearsal_adjuror_unmammonized'),(168,'zymolyis_canescence_detruding'),(169,'Stalinism_uncasked'),(170,'ghaist_groomsman'),(171,'arithmomancy_Bihar'),(172,'ingenue_hollowing_calando'),(173,'caphar_outsummed_eucti_sportsman'),(174,'claybanks_Tenochtitlan_pitiedness'),(175,'germiparity_epiderm_obliquities'),(176,'tendentious_homoeography'),(177,'ill-smelling_schorl-rock_cuissen'),(178,'spitfire_emballonurine'),(179,'stagers_Gertie_carpognia_unparalleledly'),(180,'uncatenated_duckhouse'),(181,'stigmatypy_amadan'),(182,'Meaghan_preclosure_Bozeman_clearing\'s'),(183,'iodogallicin_unoecumenic'),(184,'reemergences_bouquetiere_nonhazardousness_unseeingness'),(185,'furyl_\'twill_biasing'),(186,'enterochlorophyll_alcoholic\'s'),(187,'Meuser_wonners_stomach-weary_Anthropidae'),(188,'nonresisting_BMOC_thoracicoabdominal_dumbs'),(189,'unscientificness_leucospheric_spellingdown'),(190,'didactics_palynology_ovisac_bannet'),(191,'determinations_cotland'),(192,'preobviousness_triliteralism_devotee\'s'),(193,'degrease_prophages_rebusing_periodontosis'),(194,'vaporiness_oversophistication_Echinozoa_venturers'),(195,'incoherencies_telegraphic_re-enthronize_subspecies'),(196,'Scholastic_half-nelson_lumbricales_leaner'),(197,'quarender_rash-levied_cramp\'s'),(198,'Maritime_egualmente_Curren'),(199,'phallorrhagia_perendinant_tranqs_alternators'),(200,'unbeholdable_presavagery_zees_dead-color'),(201,'shoor_bedquilts_oolemma_rattlebrains'),(202,'flavedo_cleanable_toxalbumic_Cryptophyceae'),(203,'encompasses_onomancy'),(204,'malie_bandyball_tripylean'),(205,'sinusoidally_AMIChemE_Kaylor'),(206,'irritator_postgracile_nonlepidopteral'),(207,'queuer_fabella_oxalonitril'),(208,'penitency_maledicting_vertebrobasilar'),(209,'coffee-planting_backy'),(210,'toforn_baboonish'),(211,'Palatine_nephrolysis'),(212,'cashbox_weem'),(213,'comprehense_pickedly'),(214,'parchment-spread_ninety-hour'),(215,'Melinis_uninspirable'),(216,'SLIP_coactively_hydrosulphuric'),(217,'Post-napoleonic_Ariege'),(218,'harebells_alforja_committor_Corinthians'),(219,'pinnatisected_Pseudo-chilean'),(220,'Aushar_Vlissingen_Cypria_loathsomeness'),(221,'stamindia_incognizability'),(222,'unambiguous_Humeston_drawtubes_garlopa'),(223,'politicalization_towboat'),(224,'rental_nonwoody_disapproval_Geisenheimer'),(225,'corporative_perineurium_pedros'),(226,'leed_Alitta'),(227,'halloth_balalaikas'),(228,'liegeless_undoweled_mascle_RHV'),(229,'zinc_high-ups_Duffie_uncondensational'),(230,'Cosyra_true-speaking_derats_thirlage'),(231,'septemviral_ore-crushing'),(232,'underbutler_Zoffany'),(233,'thesmothetes_corroborated_depictive'),(234,'cycloolefinic_muriate_Harviell'),(235,'antiquities_AWL'),(236,'repatriate_unflorid'),(237,'Bootid_overhot'),(238,'anatomic_overslaugh_lallygagged_nonfanatically'),(239,'vilipend_thiochrome_stromatolite_sulphosol'),(240,'Isanti_directoral_fuseless_brooked'),(241,'towy_citrons'),(242,'antiflatulent_drowsed_decadi'),(243,'crystallometry_jimmying'),(244,'apotheosizing_exsurge_carvel-built'),(245,'sauteing_monosyllabize_unshrived_Zoroastrism'),(246,'idiosyncratically_he-heather_valency_Sheboygan'),(247,'trinocular_Candolle'),(248,'castigates_ardennite_oriconic_ingotman'),(249,'thronize_Pennales'),(250,'Elidad_homoiothermic'),(251,'constituencies_swimmingly_Ranatra'),(252,'destuff_synaxarist_pyoctanin_postmesenteric'),(253,'recoverableness_sanctity_resistant'),(254,'integrodifferential_pulsojets'),(255,'shire-moot_bas-fond_rebranched_vegetation'),(256,'solecising_Gargan'),(257,'bimarginate_allochromatic'),(258,'swelly_frills_afterimage_Polycletus'),(259,'metaphrastical_Antalya'),(260,'reabsorption_first-bred'),(261,'dim-sheeted_antidyscratic_molecule\'s_priorates'),(262,'ovate-leaved_invect'),(263,'palmito_oho_pole-dried'),(264,'paijama_engineered'),(265,'undrab_interpour_foretop_stemmeries'),(266,'sollaria_Enalda'),(267,'flounderingly_megatherian'),(268,'Tanis_relicti_risibleness'),(269,'self-limited_paleology_jerkish'),(270,'hemispheric_presentations_odd-come-shortly'),(271,'scruplesomeness_counterruin_expected'),(272,'delis_noncontinuousness'),(273,'preparticipation_retinite'),(274,'winterwards_Stettin_sniper-scope'),(275,'impertinence_brings'),(276,'zigzags_unresearched_platea'),(277,'timaliine_Glenarbor'),(278,'Epigaea_Beng.'),(279,'prod._novelet_denti-'),(280,'logics_Dettmer_overpartialness'),(281,'culus_evidently_oronooko'),(282,'Wesleyville_primordia_self-convicted'),(283,'eulogize_prophethood_Merrie_trammon'),(284,'rucked_revisory'),(285,'commeasuring_crabeater'),(286,'scrimpness_limonene_slipforming_furuncles'),(287,'machzors_kashers'),(288,'unsultry_microfungus'),(289,'red-making_gabbed_dufter'),(290,'leucemic_gorfly_tempt_Harstad'),(291,'Shepley_tear-dimmed_microdetector'),(292,'compartment_trunnions_unobeying_lawing'),(293,'defenestrate_jateorhizine_illiberal'),(294,'reattribute_Nette_Pottersville'),(295,'oleos_Zyrenian_unintentness'),(296,'praesidium_Rothberg'),(297,'potlucks_anesthetics'),(298,'semi-ironically_averter_whackers'),(299,'quadrilocular_Quantz'),(300,'granites_bolters_kafta_Regularia'),(301,'logiest_untrochaic_all-arranging'),(302,'bullwhipped_unrulable_glass-lined'),(303,'self-repulsive_markworthy_picciotto_wolvish'),(304,'jobo_reelections_hillberry'),(305,'automaticity_willy-mufty_blackening'),(306,'tic-polonga_punned_bennel_vice-regalize'),(307,'knock-on_vinet_trugmallion_SDL'),(308,'nonpersistency_ornithichnite'),(309,'verminicide_frank-tenement_gudebrother_Stubbs'),(310,'woodhole_groschen_tinternell'),(311,'autoheader_exsuscitate_lute-fashion'),(312,'unspecterlike_misshaping'),(313,'cabildos_jarina'),(314,'pre-escort_RICS_phonophorous'),(315,'spells_dezincs_athericeran'),(316,'proroyal_weren\'t'),(317,'antiman_Herzl_mesoplastron'),(318,'cyllosis_lamellary'),(319,'inwalls_Khem_diastases'),(320,'rothermuck_Pedaliaceae_Chemesh_moneylender'),(321,'tendour_handbreadth_h.a._Adama'),(322,'randing_trencherwise_yellow-vented_annuities'),(323,'bell-wether_luges_somnolencies_deemphasized'),(324,'glumella_unfamiliarity_fishergirl'),(325,'LSD-25_lexicological'),(326,'OK_ambitty'),(327,'nonnews_estrangedness'),(328,'rhizo-_electly'),(329,'adread_versemongery_pyoplania'),(330,'tame-grown_enantioblastic_Chesapeake_Kohen'),(331,'wokas_crappit-head_rebaptized_NTSC'),(332,'biophysiological_bebeerine'),(333,'toenailed_Vespertilioninae_F-shaped'),(334,'yerva_loquently'),(335,'polymorphisms_pertinaciousness_POF_Breesport'),(336,'Eveless_unpitiably'),(337,'viciousness_stenotypy_uncementing'),(338,'perdrix_melanorrhea_preenclosure_ginney'),(339,'palpating_child-bearing_jib-headed'),(340,'unbeholdable_hang-choice_Podophthalmia_Elul'),(341,'Non-irish_Salangi_box-nailing_arteriodiastasis'),(342,'piraguas_thickest'),(343,'Soult_menu_unhalved'),(344,'preally_auramine_Trichilia'),(345,'archminister_landage'),(346,'vacationless_Batchelder_overgilds_manducable'),(347,'irrationalise_red-up_pegmatophyre'),(348,'dysodontiasis_Lepidosteus'),(349,'postsign_ascertainableness'),(350,'induplication_Leonids'),(351,'pourers_heptahedrdra_Heppman'),(352,'underclass_Paluxy_Margarodinae_peyotls'),(353,'self-compatible_shammashim'),(354,'faction_imbues'),(355,'Swiftown_SDU_imitational'),(356,'nitrocellulosic_orthopedical_impasses'),(357,'metalinguistic_Glenlyn'),(358,'uneugenically_Ioannides'),(359,'spleenishness_phoniatric_loyalest_Dartmouth'),(360,'siphunculate_reseminate_protozoal'),(361,'simplices_interjectionalise_valleywise'),(362,'glucosidic_fluttered'),(363,'phonism_cyclotron_quasi-stylishly_clotheshorses'),(364,'brandade_ungreyed_prickly-lobed_set-up'),(365,'demobs_allantoinuria_enantobiosis'),(366,'unequatorial_hypercholesterinemia'),(367,'Mentmore_Aquone'),(368,'engyscope_vallecular_nontemporarily'),(369,'self-strong_marketably_retinophoral_shiftable'),(370,'sporadial_Natt'),(371,'sporulate_fiery-kindled'),(372,'nondepravities_neutered'),(373,'neuratrophic_confect_trashiest_jacent'),(374,'cooey_globelet_harbingers-of-spring_insusceptibility'),(375,'scramjet_underivative_typeform_Wehrmacht'),(376,'craizey_bugler_downligging_cyclothymic'),(377,'adjugate_Madelena_pylangial'),(378,'shutdown\'s_anti-Platonism'),(379,'hen-harrier_lavant_Ikey_erzahler'),(380,'hot-air-heat_outlancing'),(381,'Fjare_preindebted_cheeses_endocannibalism'),(382,'overmerciful_tarnishment'),(383,'shoofly_Anglo-austrian_money-spelled_Graustark'),(384,'Pratte_s.a.'),(385,'polyphone_monodactyle'),(386,'spectrobolometric_Vassalboro'),(387,'trouss_overzeal'),(388,'buat_dichroscopic_Toomsboro'),(389,'outparish_shinty'),(390,'Haitink_disinvite_deafer'),(391,'klaftern_fatlings_homologizing_diduce'),(392,'upsidaisy_cowed'),(393,'burrgrailer_unsated'),(394,'fostress_packthread_callosum_Conejos'),(395,'sepaled_thrill-pursuing_gaining_zamorine'),(396,'bausond_purpose'),(397,'canal-bone_unmiraculous'),(398,'white-livered_ceruleum_FB'),(399,'servility_time-discolored_Nickieben_cloudful'),(400,'re-resent_ill-pleased_suburban'),(401,'dumdums_cloakless'),(402,'Worsley_Conal_dribblets_transcendentalists'),(403,'ornithophobia_caponiers_kolas'),(404,'gawkhammer_starch-sized_overthriftily_half-reasoning'),(405,'meaningness_spacewalk'),(406,'divorceable_Patrai'),(407,'Eddystone_Rockie_lionizers'),(408,'supercontribution_inoculates_abune'),(409,'Belgophile_No_warmhearted_tragopans'),(410,'large-finned_B.L.'),(411,'hornfels_becarpets_titmouse_furiousity'),(412,'eyl_fizzwater_breakbone'),(413,'disburdened_theosopheme'),(414,'deutoplasm_rock-roofed_thiocyanogen_thumb-sucking'),(415,'phacolite_hemoscopy_pyroguaiacin_rheumatism-root'),(416,'uncurable_microarchitects_numeral\'s_weasel-faced'),(417,'faint-spoken_trophology'),(418,'misgrows_Hejazi_unteethed_Alco'),(419,'foreverness_hafis_Compitalia'),(420,'foulings_MTB_handarm_late-lost'),(421,'Proctor_fastnacht'),(422,'dopesheet_francas'),(423,'truck_phonologists_dodecaphonist'),(424,'hen-hawk_ethnolinguistic_conjoints_sea-cock'),(425,'glassen_th-'),(426,'galimatias_acetaldehyde'),(427,'overfeel_rhinarium_luxuriantness'),(428,'vehement_meathead_mokum'),(429,'thought-kindled_wardrober'),(430,'hydroextractor_underruns_phonematic'),(431,'syncarps_Marguerite'),(432,'androgynous_cathetusti_Khojent'),(433,'reshoulder_ARO_untightness'),(434,'Tuxedo_frill-barking'),(435,'postmyxedematous_noneclectically_petulancy'),(436,'butter-toothed_rough-ridged_kobellite_mortised'),(437,'crimson-lined_unpent'),(438,'terpolymer_prereceiver_nonatomic'),(439,'hatboxes_panegyricize'),(440,'Thun_instr'),(441,'mousquetaire_clitoridotomy_orals_lushest'),(442,'geo-_handicrafsmen_twice-whipped_oversorrowed'),(443,'ruddinesses_rabietic_radiophones'),(444,'crouching_meals_jasy'),(445,'Hydnora_Veneto'),(446,'aspires_perfectest_lionism_penelopine'),(447,'viricide_cabstands'),(448,'Trematoda_schemozzle'),(449,'bullamacow_choristic'),(450,'niduli_Hurley_Cutlor_unsonable'),(451,'disspirit_spirantizing'),(452,'torulas_self-resourcefulness_cinnamoyl_Dermestes'),(453,'odoom_tridermic_Ornithorhynchidae'),(454,'ageless_earth-delving_scientificophilosophical_brachiolaria'),(455,'hemiageusia_crepidomata_disfavoring'),(456,'quotational_kinaesthetically_dikaryotic_unadept'),(457,'represcribed_deflate'),(458,'wastabl_cliquism'),(459,'exceeded_Dillsburg'),(460,'situating_rock-crested_Dopp_demoness'),(461,'scranning_Listerine_ranket_shilf'),(462,'vanadous_missioner_highheartedly_stade'),(463,'callans_estats'),(464,'oligomerization_Jer_excathedral'),(465,'crustedly_festers_skyish'),(466,'teaboxes_Anlage'),(467,'myohaematin_light-legged_levelman'),(468,'outlet\'s_crafted_testamentary_unaccomplishable'),(469,'Calais_unlooped_piassavas_authorship'),(470,'unrated_incavo_suspicion'),(471,'epicedium_etaerio'),(472,'daydreamy_budgeree'),(473,'alternateness_forasmuch'),(474,'Ayubite_lancely_withy_dim-seen'),(475,'horror_coroneted'),(476,'semimineralized_ombrophilic'),(477,'starchedness_lulling'),(478,'six-pounder_Sara-Ann_inedible'),(479,'ploughstaff_HBO'),(480,'HDX_engallant_outtowering'),(481,'dissatisfying_protomagister'),(482,'ogonium_trencherman_princessdom_unisexual'),(483,'nor\'wester_demono-_phytoecologist'),(484,'mintmaster_Cyclostomi_ballads'),(485,'Pegasidae_bushranger'),(486,'undrew_featherwing_promises_Cis-reformation'),(487,'pentacarbon_artou_Zahedan_imbroglios'),(488,'bimah_Dalradian_chaja_irideremia'),(489,'reversionary_pseudodipteral'),(490,'charmedly_Dorking'),(491,'thin-sown_horsehoof_nonprossing'),(492,'jazzy_sternocleidomastoid_gold-inlaid'),(493,'Lucretia_suavities_Pleurocera_withen'),(494,'filicoid_soul-rending_canes_earldom'),(495,'reprehend_Berlinda'),(496,'isarithm_thunder-girt'),(497,'inapprehensiveness_Sand'),(498,'Asphalius_prancy'),(499,'mesorrhinian_strumas'),(500,'scutages_stylizing'),(501,'dimethyl_dog-bitten_archegoniate_flocklike'),(502,'unmilitant_entrances_Tympanuchus'),(503,'donatary_reantagonized'),(504,'unrestable_venturine_abscise_misculture'),(505,'Cosma_gonal_satisfiable'),(506,'subintroductory_thickety_lichenizing_odometry'),(507,'watercoloring_cannibal\'s'),(508,'metrectasia_Resa_outcroppings'),(509,'nontangentially_zappy_tranquillized_insulinase'),(510,'three-bushel_swardy'),(511,'griffithite_buggeries'),(512,'harridans_Snoddy'),(513,'Gnosticise_explicable'),(514,'hamuli_earthmen'),(515,'hypogea_sld_sensu'),(516,'Bouche_heart-hardened'),(517,'reappraised_barbascos_quantitive_vessels'),(518,'deInvincible_invisible'),(519,'sUp3RScriptyK1D'),(520,'angiosclerosis_well-forged_Morgenthaler_reaccelerating'),(521,'solvating_eye-distracting'),(522,'patricians_postcommissural_nonserviceably_sandclub'),(523,'mashru_asperates_Normalie_Olomouc'),(524,'parquetage_Autoharp_ruffs_Budenny'),(525,'stiltiness_galactoscope'),(526,'Augean_checker-brick_sloetree_Hepsiba'),(527,'gemmer_cheval_meader'),(528,'mucoviscoidosis_yak_pupillometry'),(529,'allassotonic_nonconversance_turgoid'),(530,'coromell_scincoid'),(531,'chirurgy_telegraphing'),(532,'procoracoidal_colocephalous'),(533,'woundableness_Siegel_inhabit'),(534,'Herrenvolker_nonannihilable_Phryganea'),(535,'eighteens_coven_unsanctimonious_satisfyingly'),(536,'accompliceship_Gorgonia'),(537,'cyme_acreable'),(538,'inofficial_tyrannoid_morganatically'),(539,'self-colour_whitesmith'),(540,'deep-sea_art'),(541,'fisheye_wt_woven'),(542,'Nahane_unsacked_grillers_crux\'s'),(543,'Dyna_doctrinable_nursingly'),(544,'unneutralizing_predelegate_innuendoed'),(545,'half-alike_glucosidically_Ochozath_full-haired'),(546,'leuchaemia_Masticura_moy'),(547,'tubae_photofilm_Brno'),(548,'Pebworth_bastard-cut_uranion'),(549,'indiscreetness_Nummulitidae_norkyn_sanghs'),(550,'tuna_murph_unordinateness_perspective\'s'),(551,'conformable_ultracentralizer_distinctest'),(552,'undoings_rapidness'),(553,'cherup_feists'),(554,'Francophilism_lirella'),(555,'superdemonstration_headring_brawnedness_cetonian'),(556,'intersectant_disjects_Arab'),(557,'scrotitis_vituperates'),(558,'Catholic_Tristania'),(559,'bold-facedly_asteroid_awhile'),(560,'Battenburg_Benito'),(561,'shakil_mesophyllic_rhinosporidiosis'),(562,'unbenevolentness_compels'),(563,'crassilingual_necrotically_overwroth'),(564,'larikin_stabilisation_splenomegalia'),(565,'Phoenixlike_ghebeta_Lagos'),(566,'Indo-malayan_bedtimes_Adah'),(567,'rete_ectocornea_extubation_dawdy'),(568,'ditrigonally_Wimbledon_disenroll'),(569,'Cassirer_pseudofilarian_Woodward_Leban'),(570,'flush-plated_leapfrogging'),(571,'glidewort_nonvocationally_subsacral'),(572,'villously_Sofiya'),(573,'pseudodivine_Kloman_haversacks_arising'),(574,'turpify_heptagons_wrestable'),(575,'inactivate_ambiency_multidenticulate'),(576,'desexualize_infra-axillary_bellies_impregns'),(577,'hypercholia_rebukeable_negliges_epicotyl'),(578,'anthoxanthin_notchers_fee-farm_Jaye'),(579,'shorer_hyoidan_crotaline'),(580,'sheriff\'s_bournous_clumproot_disorganised'),(581,'Caseyville_unpublic_oxamate'),(582,'muncher_Waukomis_iatrochemical_Cerritos'),(583,'enticeable_tuart_involucel'),(584,'quarter-inch_Elaeagnaceae_cadmium_ceramiaceous'),(585,'showily_Idabel'),(586,'bepuffed_caeremoniarius_maieutical_Aladinist'),(587,'open-housed_acronically_cross-leggedly_parly'),(588,'outbluffs_orbiculate'),(589,'money-changer_Archaic_moonsail_huzzahed'),(590,'snake-haired_copelidine_rheophoric_anti-intermediary'),(591,'Liddle_preenlightenment_endopleural'),(592,'hizz_naysay_globate_Cahnite'),(593,'rattles_sunspottery_unregistered'),(594,'ultroneousness_Maeve_windtight_outgate'),(595,'Smelterville_Non-venetian'),(596,'susurr_canopies_mannonic'),(597,'guard-rail_hyalomere'),(598,'shandies_suppedaneous'),(599,'extraoral_handlings'),(600,'lakelet_bronchogenic_virtuouslike_oracler'),(601,'albertype_engraphically_sportless'),(602,'ill-achieved_subdevil_crawly'),(603,'what-d\'ye-call-\'em_vatmaking'),(604,'quaternity_eulogisation'),(605,'Hockenheim_flesher_nephrogonaduct_acari'),(606,'ablepsia_PTP_bacteriophobia'),(607,'engine-sizer_ketoxime_cane-phorus_byeworkman'),(608,'Rosaline_dt\'s_full-plumed'),(609,'nonpersevering_abacinate'),(610,'noetics_Lona'),(611,'grunions_croaks'),(612,'walled_diplophonia_Heyworth_semicarbazone'),(613,'tomcatting_seggiola'),(614,'subrail_lomata_half-earnestly_fingerprinted'),(615,'remargin_nonorthographically'),(616,'Friedensburg_nomas_poplitei'),(617,'tonsils_excogitated_L/P'),(618,'maltman_diaphoretical_semilogarithmic'),(619,'Fleisig_manganblende_astrogated_metamorphosian'),(620,'tubesmith_own-root'),(621,'trim-looking_Borromean_humoured_long-borne'),(622,'guillochee_radices_Lyle_queerest'),(623,'rudented_monoculous_clipsheet_leeching'),(624,'Diann_balers_tabuli_subgelatinously'),(625,'irrigation_ontologize_frustum'),(626,'outearns_gumbolike_reapprehension_dodecane'),(627,'indignatory_transuranic'),(628,'fibry_Neotropic_trusteeing'),(629,'cedar-colored_attice_yealing'),(630,'Daney_oversees_doggers'),(631,'Narcobatus_tyste_plaitwork_telt'),(632,'metricating_emplastic'),(633,'Navarrese_Araucano_shoupeltin'),(634,'coal-fired_kvinter'),(635,'recapitalization_upcountry'),(636,'presphygmic_Putana_Christ-professing'),(637,'hepta-_regovern_individualize_outflew'),(638,'cocircular_Alithea_superficies'),(639,'boomerangs_headframe_Simona_splurging'),(640,'prepunching_bullnecked_brainy'),(641,'belt_butterfats_nonintent'),(642,'melled_claros'),(643,'diacoele_V-mail_zoonosology'),(644,'ore-extracting_nonbasing_eurygnathism_slyly'),(645,'fluocerite_luxuriates'),(646,'morceau_napron_Vaccinium'),(647,'quasi-intimate_aupaka'),(648,'synergistical_renegado'),(649,'unqualifying_yobi_sangho'),(650,'Tbi_prefactor_unsocialising'),(651,'diastereoisomerism_Choapas'),(652,'conjoin_semimature_hydrovane'),(653,'harpagon_Scouse'),(654,'Doddsville_hutting_Rhaptopetalaceae_coadmires'),(655,'exogastrically_intermingled_Melipona_treatises'),(656,'papish_clubfooted_mycetogenous_gestening'),(657,'nontransgressive_tortricine_ghosthood_raku'),(658,'straight-shaped_monesia_subducting_uredospore'),(659,'overnormalized_tuebor'),(660,'wrestlings_burking'),(661,'self-heterodyne_seppa_flatfishes'),(662,'metrize_cross-slide'),(663,'Theodor_forestlands_tenontomyotomy'),(664,'Teodoro_instantiation\'s_hyposensitize'),(665,'metallograph_neoplasma_azotize_nonliberal'),(666,'Pro-mongolian_mini-specs'),(667,'diphthongous_micropsia'),(668,'laryngitises_stone-edged'),(669,'marginoplasty_avellane'),(670,'postmastership_archbishopric_tox-'),(671,'tenorites_dailiness_angelito'),(672,'entrecotes_mantras_scler-'),(673,'silentio_pelargic'),(674,'blackwashing_Baring'),(675,'unchangedness_matzoth_engrossingly_besra'),(676,'enshrouded_headkerchief_Cohasset'),(677,'rebuffing_triakid_moss-covered'),(678,'raising_lascarine_unperformability_rivalled'),(679,'cornstarch_woodshedded_presignified_devests'),(680,'two-capsuled_vignetter_terse_unconspired'),(681,'antiquer_monosaccharose'),(682,'Thor-Delta_beatnik\'s'),(683,'stonecrop_induction'),(684,'swanmarking_accessibility'),(685,'realigning_Bondie'),(686,'friborg_untarred_beforetime'),(687,'backaching_Venu_nonbibulousness'),(688,'curucui_trigintennial_DMU_Messianize'),(689,'lawn-sleeved_subshrubby_faddishly'),(690,'teleoroentgenogram_periodontium'),(691,'Pelagian_Chaucerism_subindicating_dummyism'),(692,'planner_squashiness_planchets'),(693,'ALI_investing'),(694,'nereidean_rapture-moving'),(695,'barfly_anattos'),(696,'gladder_malleinization_archlexicographer_zootomical'),(697,'singlet_grimacer_tumoured_white-tail'),(698,'rust-worn_prespiracular_shortcoming_multispiral'),(699,'flicking_Syryenian_disship_Bastille'),(700,'clawback_beamer_reentries_blowsy'),(701,'jerfalcon_abdaria_roentgenopaque_monkey-tailed'),(702,'subgyrus_carbohydrate_hydro-'),(703,'betassel_gill-netter_aludel'),(704,'rameal_diffractive_tailored_exploitable'),(705,'whitewasher_surmullets'),(706,'Ferdiad_orography_schorlomite'),(707,'semiweekly_quintefoil_suboctave'),(708,'septillionth_star-paved_Eudoxian_encolumn'),(709,'annunciatory_archiheretical'),(710,'iron-hearted_tallow-white'),(711,'plum-sized_grivets_nutrice_winkingly'),(712,'Roane_rheotrope_developmentally'),(713,'antihemagglutinin_nonexcepting_highest-ranking'),(714,'Thessalus_variableness_overinvested_Moabite'),(715,'unhubristic_predividing'),(716,'first-rately_swalingly_euryzygous'),(717,'galact-_rhagionid'),(718,'fletchings_canyons_tribally_rhein-berry'),(719,'Changchun_diminutiveness_ochlocratic'),(720,'Leigh_CNMS_pentose'),(721,'molassied_Sabbatical_solgel'),(722,'antimilitarism_Desoto'),(723,'narrow-laced_creature_APJ_Curtisville'),(724,'mesorrhin_freeze-out_Scandaroon'),(725,'Rikari_Tamilic_oscillates_partisan\'s'),(726,'pelvises_Francaix_electromeric'),(727,'thermetograph_righto_embolization'),(728,'pigeon-toed_can-polishing_hatherlite'),(729,'made-to-measure_zooming'),(730,'siva-siva_circumfulgent_oxalic_passivity'),(731,'Wakamba_reencouraging_fiddleneck'),(732,'strangerlike_osseously_cratometric'),(733,'Rebbecca_muckluck_stored'),(734,'rejoneador_hews'),(735,'Kirkwood_nonpronunciation_scabbiest_rumpy'),(736,'Marcionist_quiniretin_psychodelic'),(737,'nondialectal_unsowed'),(738,'vernalisation_undignifiedly_circularizing'),(739,'fracturable_Vulpeculid_prepossessing'),(740,'surplician_fugard_negatived'),(741,'lifelessness_ahmedi_Spam_small-brained'),(742,'collimated_rei'),(743,'obcordate_esophagomycosis_taxmen'),(744,'roan_paraffinoid_tapesium_uncrib'),(745,'well-charted_tetrachordal'),(746,'espaliering_fiants'),(747,'tiewigged_Mauchi_estacade'),(748,'crucibles_phycochromaceae_brachysclereid'),(749,'haemostasia_spermogenesis'),(750,'meered_night-crow'),(751,'barbecueing_expergefacient_isodynamous'),(752,'abody_Laurentians_self-deserving'),(753,'haberdasher_Canaveral_parorexia'),(754,'dichasium_ectosome'),(755,'Vientiane_yirr'),(756,'pill-taking_analav_angularia'),(757,'Frangulaceae_Bayly_ansated'),(758,'humble-bee_milder_awanting'),(759,'Diablo_ratchel_ashfall'),(760,'tyring_unrancorous'),(761,'Prionopinae_hypotaxic_undished_disintertwine'),(762,'carapato_trammer_rabanna'),(763,'prefamiliarity_nonvolubly_overforged_individuate'),(764,'overcontentious_chroma_wampee'),(765,'litigators_establishes'),(766,'elucidatory_Pro-alaskan_Marxism'),(767,'forhooy_alowe_wheezingly'),(768,'inerringly_Alyssum_headliners_Finno-Ugric'),(769,'scalariform_spare-time_luggers'),(770,'Paixhans_drouthy'),(771,'peonage_ooid_subforeman'),(772,'ausgespielt_dihydrocupreine_apiarist_swishy'),(773,'gold-embossed_infamed'),(774,'pedophile_taradiddle_physitheistic_outerwear'),(775,'mizzenmasts_pleomazia'),(776,'stonewood_self-revelation_submitochondrial'),(777,'flagellations_amarth'),(778,'glamorous_labiovelarizing_geraniols_bulbs'),(779,'leadableness_Arleen_shellpad'),(780,'dictyopteran_Laelius_reconnoiters_AMATPS'),(781,'apesthetic_repenalize'),(782,'keeps_sweet-singing_steatosis_rapeseed'),(783,'easters_poll-parroty'),(784,'Schaghticoke_contranatural'),(785,'lapidescence_Lissamphibia_decuples_pedimentum'),(786,'carassows_Robigalia'),(787,'uneleemosynary_onymal'),(788,'unglaze_consequences'),(789,'Gulf_raisonne'),(790,'Anti-entente_CPU'),(791,'shabbos_centralest'),(792,'dissonance_fiord_fangot_Aquarian'),(793,'quitclaims_meubles_gutted'),(794,'synochous_blousier_pneumathaemia_bylawman'),(795,'Schell_unlathed_Kamillah_ink-black'),(796,'Halonna_foolhardiness_Carry_caponized'),(797,'leasings_Kylertown_rebating'),(798,'investigated_Sassan'),(799,'Lydell_Ogbomosho_chickened'),(800,'marsupialian_whisht_acanthopterous_Moluccan'),(801,'yacata_macroelement'),(802,'trumperies_antimoniated_abcissa_circiter'),(803,'degumming_manoc'),(804,'persulphuric_unparallelness'),(805,'curacies_irradiator_prohuman_horse-box'),(806,'tusker_pneumoventriculography_uncitable_trichocarpous'),(807,'Mid-victorian_Carlism_fieldstrip_unhook'),(808,'distressfulness_filemot_tachoscope_macrophage'),(809,'Cheshire_Hindustani'),(810,'electioneers_chlormethane'),(811,'hay-scented_horridly'),(812,'almsmen_endamaging'),(813,'Orji_conceity_BFDC'),(814,'zoochemical_remittable_misapplier_Kurzawa'),(815,'Alcimedon_expansionists_MOTOS_gorglin'),(816,'pyralids_CMDS_amated_bodysurfs'),(817,'twofer_rackfuls'),(818,'Gyropilot_retia_kitling_Erythronium'),(819,'senso_sensibilities_broached_parians'),(820,'Indo-malaysian_shtchee'),(821,'pulas_labile_gastrogenital'),(822,'ostearthrotomy_asem_abduces_Broz'),(823,'biolite_homothermous_diplomates_leadenheartedness'),(824,'eradicant_indoles_lignone_lithotritist'),(825,'ferriprussic_manitos_eremite_addicted'),(826,'Gideon_Nero\'s-crown'),(827,'aquapuncture_hematine_proctodea'),(828,'Turcophile_by-cock_nonvalue'),(829,'Daugherty_Jap._nondiazotizable'),(830,'wind-grass_mesolecithal_calamitoid_nonheathen'),(831,'brutify_uteropexia_Vic-en-Bigorre'),(832,'subject-object_basilicalike_outway'),(833,'consimilarity_best-conducted_fuirdays'),(834,'queered_notidanian_preextract'),(835,'transferee_isoindole'),(836,'Bergeman_stromatous'),(837,'nonsignature_brochantite_hygric'),(838,'quasi-established_spettle_rugulose'),(839,'rebelove_deposals_trancedly_chiropterygious'),(840,'seacock_backaching'),(841,'glanderous_Hauptmann'),(842,'spatterwork_wurlies_ministerialist_self-consideration'),(843,'cogence_retainability_octoglot_crabbers'),(844,'acanthine_ardennite'),(845,'pseudodont_bamboozlement'),(846,'GU_many-seeded_zonuroid_smogless'),(847,'sucket_jujutsus'),(848,'reteamed_neocortex'),(849,'wide-accepted_jimbang'),(850,'Pythagorizer_Dianemarie_eriometer'),(851,'basophilia_eliquation_engouee_Cynara'),(852,'florican_youp'),(853,'amidships_superuniversal_Ocypete'),(854,'unlinking_anthelion_prescriptionist'),(855,'oxazin_octoroons'),(856,'beriberis_tongueman'),(857,'chiastoneural_unspeakableness'),(858,'reproachably_pyloruses'),(859,'bulbuls_O\'-_Pentacrinidae'),(860,'antigrammatical_Liard'),(861,'santonine_BSCom_seminonflammable_tump-line'),(862,'pasgarde_volcanizate'),(863,'talliable_side_unbracedness_pectinogen'),(864,'evil-fashioned_Jollenta_pulingly_Stevy'),(865,'room_shadblow'),(866,'families_occulted'),(867,'conditionalist_AP'),(868,'Sno-Cat_attid_Wu-lu-mu-ch\'i'),(869,'vitrail_single-member_papyraceous'),(870,'overanalytical_rolling-pin'),(871,'Anglim_flavonoid_Mid-may'),(872,'teethes_Ententophil_thirty-four_yearners'),(873,'high-lying_itzebu'),(874,'butyls_archpriestship_Iredell'),(875,'rotatodentate_hiyakkin_security'),(876,'outhumored_omental_chylify'),(877,'mood\'s_sackmaker'),(878,'oxamid_overween'),(879,'warplike_Yanan_ictuate'),(880,'choreography_syssarcosic'),(881,'defecates_push-button_limmers_stunningly'),(882,'Cassiopeid_cunenei'),(883,'noiseproof_Gibby'),(884,'accrementitial_adiaphoristic_nonspecifiable_histing'),(885,'spivery_Donar'),(886,'flummoxes_overhated_Kavita'),(887,'styfziekte_thermosiphon_Septemberist_gem-bespangled'),(888,'antler_malloseismic_short-bobbed_discontinuations'),(889,'aleucaemic_dispersedelement_Cloisonnist'),(890,'tonlet_disengaged'),(891,'mid-volley_interppoliesh_Miltona'),(892,'Whippleville_oxyphonia_spindliness'),(893,'outpourer_synclinorial_pintadera'),(894,'suralimentation_full-throated_hempweed'),(895,'Khitan_recoins_macaboy'),(896,'nonpros_aegirine_biternately'),(897,'anticonventionalist_Kamina'),(898,'uninventful_leucins_cambiums_deep-sighted'),(899,'peepholes_impoliticness_friendlies'),(900,'Wanhsien_Atka_hauflin'),(901,'carboxypeptidase_spider-webby'),(902,'scalped_lentamente_Cervicapra_all-stars'),(903,'untrammeledness_combusted_tympanomandibular_aumbries'),(904,'quasi-virtuous_thereaway'),(905,'subacrodrome_doublet\'s'),(906,'Orling_Jonas_onocrotal_canephor'),(907,'fishpool_simples_Coeymans'),(908,'Signorelli_havening_preregal'),(909,'yarraman_Lenwood_subversively_overborrowing'),(910,'adscripted_politize_pre-excellence_metatarsus'),(911,'Sasserides_ocean-going'),(912,'diplocephalous_tryma'),(913,'nubblier_Neengatu_RCO'),(914,'cephalosome_joys'),(915,'clapperdudgeon_lip-blushing_splanchnologist'),(916,'electrum_Mucker_boardwalks'),(917,'unforgetfulness_bristle-stalked_petit-maftre_piteous'),(918,'Salangia_porphyrinuria_hales'),(919,'undergirds_pro-orthodoxical_paleopsychology'),(920,'maltreatment_undisestablished'),(921,'bibliographically_sillies_undone_amargosa'),(922,'warpaths_scabiophobia_perphenazine'),(923,'Franek_prosapy_subpredicate'),(924,'parachronism_doubloon_requisition'),(925,'visitable_Erlin_Madill_speeding-place'),(926,'epigrammatize_rate-fixing_inimitative_digladiation'),(927,'pharyngealization_pennons_Cadogan'),(928,'sampling_Rabassa_warsler_Assur'),(929,'hewettite_personalist_unintended'),(930,'Terri_malpraxis_reitemizing'),(931,'pro-ostracum_Rousseauite'),(932,'Tayler_nippers'),(933,'mould_becurry'),(934,'palmitate_humours'),(935,'instilment_Yumas'),(936,'Tigerton_extrasomatic_consent_deft-fingered'),(937,'lackerer_unstandardized_sawbills_Devan'),(938,'conked_mosslike_hagio-'),(939,'Berstine_correlativeness_ignifuge'),(940,'diplomatically_baffling_repawn_consubstantiate'),(941,'counterenthusiasm_Trikora_heterokinesis'),(942,'blasty_whelphood_unplenished_aesthesics'),(943,'directorially_Tomi_slum\'s'),(944,'cannonades_agatize'),(945,'sirree_quasi-consequentially_sealess_Ussher'),(946,'illegal_damasse_Adlerian_six-headed'),(947,'lg._boarwood_anti-Bible'),(948,'nonassessable_Davene_McBrides'),(949,'rentability_antiquarium_preaccomplishment_malgr'),(950,'phosphosilicate_harmal_challoth'),(951,'unpriority_hymenopttera_noncaustic'),(952,'Hermite_Birchism_jellylikeness_eulogizers'),(953,'ceromancy_Japans'),(954,'world-helping_schoolboyism_banket'),(955,'Hourihan_jeffersonians'),(956,'compone_secularized_prevaluing_influents'),(957,'whirrs_unopaque_goelism_bluntest'),(958,'self-dependence_fine-tricked_submarginate'),(959,'schoolless_Silvia_Flatto'),(960,'predictably_flicked_goodwives_straggled'),(961,'eight-cylinder_Hackney'),(962,'whippers-in_lecithin_ferganite'),(963,'Sutersville_close-tongued_Ibycter'),(964,'darwesh_autostethoscope'),(965,'superromantic_aminotransferase'),(966,'detruck_Muphrid_otherguise_presuperficiality'),(967,'Anti-nordic_Cutcheon'),(968,'malander_excruciating'),(969,'haffat_beclamor_Liao_graftage'),(970,'nauseates_Rivesville_ogreisms'),(971,'millibar_unsped'),(972,'misgivinglying_NUI_Gaulish_Romescot'),(973,'thirty-ninth_hastatosagittate_Lamson_wifing'),(974,'flat-iron_Burgoyne'),(975,'verbum_faithfully_botch_adjoiner'),(976,'Lady_bubbliness_unattackable_thanks'),(977,'Midgarth_ochidore_pediculid'),(978,'fairishness_korakan'),(979,'bitartrate_Knik'),(980,'gob_assidually'),(981,'characterful_middleway'),(982,'carboluria_buck-one_affluent_creatines'),(983,'vapourous_opai_Lycomedes_Gyrodactylus'),(984,'chizz_semicadence_kilhig'),(985,'unpracticality_logrolled_drinkproof'),(986,'DPhil_outwriting_rusty-branched_snafflebit'),(987,'tungstenic_numerose_well-damped_half-successful'),(988,'limpingness_inequities_catfaced_record-player'),(989,'demultiplexed_winful_EV'),(990,'freshest_propacifism'),(991,'splurger_compressibly_tinglers_Fasciolaria'),(992,'sable-robed_thoracicohumeral_cecopexy'),(993,'Tombean_misinference_ribbon-bordering'),(994,'half-willful_nimblenesses_fore-rank_CID'),(995,'gastrodermis_Swoyersville_glimmery'),(996,'cowgram_nordcaper_viragin_overdecorate'),(997,'literature\'s_EMI'),(998,'dairt_notelessly'),(999,'unshatterable_netman'),(1000,'dissuasory_despondently_replays_CDA'),(1001,'bluffing_would');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-10 17:53:39
